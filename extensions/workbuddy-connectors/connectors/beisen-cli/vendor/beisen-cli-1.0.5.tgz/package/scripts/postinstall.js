#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const packageRoot = path.join(__dirname, "..");
const isSourceCheckout = fs.existsSync(path.join(packageRoot, ".git"));
const skipDownload = process.env.BEISEN_CLI_SKIP_DOWNLOAD === "1";
const forceInstall = process.env.BEISEN_CLI_FORCE_INSTALL === "1";

if (skipDownload || (isSourceCheckout && !forceInstall)) {
  console.log("Skipping beisen-cli binary download in source/CI environment");
  process.exit(0);
}

const installer = path.join(packageRoot, "dist", "install.js");
if (!fs.existsSync(installer)) {
  console.error("Missing dist/install.js. The npm package was not built correctly.");
  process.exit(1);
}

try {
  execFileSync(process.execPath, [installer], { stdio: "inherit" });
} catch (error) {
  process.exit(error.status || 1);
}
