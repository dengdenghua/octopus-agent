# beisen-cli

北森官方命令行工具，为企业员工、HR、管理者和 AI 助手提供统一的北森业务访问入口。

通过 `beisen-cli`，用户可以在终端或支持 AI Skills 的智能助手中使用审批、招聘、面试、员工档案、考勤休假、组织架构、企业知识和办事入口等服务。

## 核心能力

- **统一入口**：通过一个命令访问多个北森业务域。
- **AI 辅助**：安装配套的北森 AI Skills 后，可让智能助手理解需求并调用相应能力。
- **安装简单**：一条命令完成 CLI 和 AI 辅助能力的安装。
- **账号安全**：通过北森账号授权访问数据，实际可用范围以用户权限为准。

## 支持的业务

| 业务域 | 主要能力 |
|---|---|
| 审批中心 | 查询我的待办、我的已办以及流程进度 |
| 招聘 | 搜索职位、查看职位详情、推荐候选人、查询申请和人才库 |
| 面试 | 查询招聘进展、面试官待办和面试分析 |
| 员工档案 | 查询员工基本信息、任职信息、教育经历和工作履历等 |
| 考勤休假 | 查询假期余额、考勤、排班、加班、出差和休假记录等 |
| 组织架构 | 查询组织、负责人和编制信息 |
| 企业知识 | 检索企业制度、政策、流程和知识文档 |
| 办事入口 | 根据用户需求推荐相应的北森业务办理入口 |

具体可用能力取决于所在企业的北森产品配置和当前账号权限。

## 安装与快速开始

### 环境要求

- Node.js `22.20.0` 或更高版本
- npm 或 npx
- macOS、Linux 或 Windows

可以通过以下命令检查当前版本：

```bash
node --version
npm --version
```

### 一键安装

推荐在交互式终端中执行：

```bash
npx beisen-cli install
```

安装向导会完成 CLI 安装、北森 AI 辅助能力安装，并引导用户登录北森账号。

### 手动安装

也可以先全局安装，再运行安装向导：

```bash
npm install -g beisen-cli
beisen-cli install
```

### 验证安装

```bash
beisen-cli version
beisen-cli auth status
```

能够正常输出版本号，说明 CLI 已安装成功。

## 登录北森账号

首次使用时执行：

```bash
beisen-cli auth login
```

命令会输出授权地址。请在浏览器中打开该地址，并按照页面提示完成北森账号授权。

授权完成后，可以检查登录状态：

```bash
beisen-cli auth status
```

状态为 `valid` 时即可开始使用。

退出当前账号：

```bash
beisen-cli auth logout
```

## 常用命令

| 命令 | 说明 |
|---|---|
| `beisen-cli version` | 查看当前版本 |
| `beisen-cli install` | 运行安装向导或升级 AI 辅助能力 |
| `beisen-cli auth status` | 查看登录状态 |
| `beisen-cli auth login` | 登录北森账号 |
| `beisen-cli auth logout` | 退出当前账号 |
| `beisen-cli --help` | 查看全部命令帮助 |
| `beisen-cli <业务域> --help` | 查看指定业务域的帮助 |


## 在 AI 助手中使用

安装向导会自动安装与 CLI 配套的北森 AI Skills。安装完成并登录后，可以直接向支持 Skills 的 AI 助手描述需求，例如：

- “帮我查询当前待处理的审批。”
- “查一下公司的年假制度。”
- “查询我的假期余额。”
- “帮我找一下出差申请入口。”

AI 助手会根据用户意图选择相应的北森能力。执行前请关注助手展示的操作内容，涉及敏感数据或重要操作时应再次确认。

如需重新安装或升级北森 AI Skills，请执行：

```bash
beisen-cli install
```

## 支持的平台

- macOS
- Linux
- Windows

安装设备需要能够正常访问 npm 和北森 CLI 服务。

## 版本升级

升级到最新正式版本：

```bash
npm install -g beisen-cli@latest
beisen-cli install
```

安装指定版本：

```bash
npm install -g beisen-cli@<版本号>
```


## 常见问题

### Node.js 版本不满足要求

请将 Node.js 升级到 `22.20.0` 或更高版本，然后重新执行：

```bash
npx beisen-cli@latest install
```

### 执行命令时提示找不到 `beisen-cli`

请重新全局安装并打开新的终端窗口：

```bash
npm install -g beisen-cli
beisen-cli version
```

### 安装过程中提示下载或完整性校验失败

请检查当前网络后重新安装。若问题持续存在，请勿跳过校验或手工替换安装文件，建议联系北森 CLI 维护团队。

### 登录未完成或授权已经超时

请重新执行登录，并在提示的有效期内完成浏览器授权：

```bash
beisen-cli auth login
```

## 使用反馈

如果遇到安装、登录或命令执行问题，请联系北森 CLI 维护团队。提交问题前，请先移除授权信息和敏感业务数据。
