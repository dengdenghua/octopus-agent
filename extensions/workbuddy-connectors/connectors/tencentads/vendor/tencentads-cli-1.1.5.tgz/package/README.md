# tencentads-cli

通用腾讯广告 API CLI 工具 — 封装鉴权与 API 调用。

## 安装

```bash
npm install -g tencentads-cli
```

npm 会根据当前操作系统自动安装对应平台的子包（`optionalDependencies`）：

| 子包 | 平台 |
|------|------|
| `tencentads-darwin-x64` | macOS Intel |
| `tencentads-darwin-arm64` | macOS Apple Silicon |
| `tencentads-linux-x64` | Linux x64 |
| `tencentads-linux-arm64` | Linux ARM64 |
| `tencentads-windows-amd64` | Windows x64 |
| `tencentads-windows-arm64` | Windows ARM64 |

## CLI 使用

### `tencentads`（当前版本，Go 二进制）

```bash
# 登录鉴权
tencentads auth login

# 查看鉴权状态
tencentads auth status

# 退出登录
tencentads auth logout

# 查看帮助
tencentads help
```

### `tencentads-cli`（旧版，不再升级）

`tencentads-cli` 为早期 Node.js 版本，保留以兼容现有集成，不再接受新功能更新。


## 环境要求

- Node.js >= 18.0.0

## License

[MIT](./LICENSE)
