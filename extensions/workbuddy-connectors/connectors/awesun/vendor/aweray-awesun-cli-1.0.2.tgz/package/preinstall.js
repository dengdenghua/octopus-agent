/*
 * Copyright (c) 2026 Oray Inc. All rights reserved.
 *
 * No Part of this file may be reproduced, stored
 * in a retrieval system, or transmitted, in any form, or by any means,
 * electronic, mechanical, photocopying, recording, or otherwise,
 * without the prior consent of Oray Inc.
 *
 * @Author: liuchanghuang1<liuchanghuang1@oray.com>
 * @Date: 2026-05-21
 * @LastEditors: liuchanghuang1<liuchanghuang1@oray.com>
 * @LastEditTime: 2026-05-21 18:21:59
 * @FileName: preinstall.js
 * @Description: []
 */

const os = require("os");
const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");


function stopService() {
  try {
    console.log("Stopping awesun-cli service...");
    execSync(`awesun-cli stop-daemon`, {
      stdio: "ignore",
      timeout: 3000,
    });
    return true;
  } catch (_) {
    return false;
  }
}

function forceKill() {
  try {
    if (process.platform === "win32") {
      execSync(`taskkill /F /IM awesun-cli.exe /T`, {
        stdio: "ignore",
        timeout: 3000,
      });
    } else {
      execSync(`pkill -x awesun-cli || true`, {
        stdio: "ignore",
        timeout: 3000,
      });
    }
    console.log("Force killed awesun-cli.");
  } catch (_) {}
}

function cleanBinaries() {
  try {
    const binDir = path.join(os.homedir(), ".awesun-cli")
    if (!fs.existsSync(binDir)) {
      return;
    }
    fs.rmSync(binDir, { recursive: true, force: true });
    console.log("Clean awesun-cli resource successful.")
  } catch (_) {}
}

(function main() {
  const stopped = stopService();
  if (!stopped) {
    console.log("Graceful stop failed, force killing...");
    forceKill();
  }
  cleanBinaries();
})();
