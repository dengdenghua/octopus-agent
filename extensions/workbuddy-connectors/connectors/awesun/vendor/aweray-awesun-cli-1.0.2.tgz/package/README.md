# AweSun CLI

AweSun CLI is the official command-line tool for managing and accessing devices through AweSun remote desktop services.

## Features

- Account login and logout
- Device management (list, search, add, update, delete, grant permissions)
- Remote session management (desktop, file, SSH, port forwarding)
- Desktop control (mouse, keyboard, text input)
- File transfer (upload/download, directory listing)
- Port forwarding configuration
- Wake-on-LAN
- Background daemon service management
- Cross-platform support

## Installation

Install globally using npm:

```bash
npm install -g @aweray/awesun-cli
```

## Supported Platforms

| Platform | Architectures |
|----------|---------------|
| macOS    | Intel (x86_64), Apple Silicon (arm64) |
| Linux    | x86_64, arm64 |
| Windows  | x64, x86, arm64 |

## Quick Start

### Login

```bash
# QR code login (opens a browser for QR authentication)
awesun-cli login --qrcode

# QR code login (print URL instead of opening browser)
awesun-cli login --qrcode --url

# Username/password login
awesun-cli login --user <username>
```

### List Devices

```bash
awesun-cli device ls
```

### Connect to a Remote Device

```bash
awesun-cli session connect --remote-id <remote-id> --type desktop
```

### Logout

```bash
awesun-cli logout
```

### Stop Background Service

```bash
awesun-cli stop-daemon
```

## Command Reference

### Global Options

| Option | Short | Description |
|--------|-------|-------------|
| `--output` | `-o` | Output format: `table`, `json`, `yaml`, `wide` |
| `--verbose` | `-v` | Verbose mode (enable debug logging) |
| `--help` | `-h` | Show help |

### Account Management

```bash
# Login
awesun-cli login --user <username>
awesun-cli login --qrcode

# Login (print URL instead of opening browser)
awesun-cli login --qrcode --url

# Check login status
awesun-cli login status

# Logout (use --clean to clear all credentials)
awesun-cli logout [--clean]
```

### Device Management

```bash
# List devices
awesun-cli device ls [--limit N] [--page P]

# Search devices
awesun-cli device search <keyword> [--limit N] [--page P]

# Get device info
awesun-cli device info <remote-id>

# Add a device
awesun-cli device add --name <name> --desc <desc>

# Update a device
awesun-cli device update <remote-id> --name <name> --desc <desc>

# Remove a device
awesun-cli device rm <remote-id>

# Manage device access permissions
awesun-cli device grant \
  [--remote-id ID] \
  [--password|-p pwd] \
  [--username|-u user] \
  [--remove] \
  [--remove-all] \
  [--file PATH]

# Shutdown remote device
awesun-cli device shutdown <remote-id> [--password|-p pwd] [--username|-u user]

# Restart remote device
awesun-cli device restart <remote-id> [--password|-p pwd] [--username|-u user]

# Wake-on-LAN
awesun-cli device wakeup <remote-id>
```

> **Note**: `shutdown`/`restart` without password will prompt for access password; with `--username` will prompt for system password.

### Session Management

```bash
# List sessions
awesun-cli session ls [--type TYPE]

# Connect to a remote device
awesun-cli session connect \
  --type <desktop|file|ssh|cmd|forward> \
  (--remote-id ID | --fastcode CODE) \
  [--username USER]

#   --fastcode: prompts for access password
#   --remote-id: prompts for access password by default
#   --remote-id + --username: prompts for system password

# Check session status
awesun-cli session status <session-id>

# Disconnect a session
awesun-cli session disconnect <session-id>

# Execute a command in a session
awesun-cli session exec <session-id> <command> [args...]

# Take a screenshot
awesun-cli session screenshot <session-id> [--output PATH]
```

### Desktop Control

```bash
# Mouse click
awesun-cli desktop mouse click <session-id> \
  --x X --y Y \
  [--button left|right|middle] \
  [--clicks N]

# Mouse move
awesun-cli desktop mouse move <session-id> --x X --y Y

# Mouse scroll
awesun-cli desktop mouse scroll <session-id> \
  --x X --y Y \
  --direction up|down \
  --count N

# Mouse drag
awesun-cli desktop mouse drag <session-id> \
  --path "x1,y1,x2,y2,..." \
  --button B \
  [--hold-keys KEYS]

# Type text
awesun-cli desktop type <session-id> <text> [--delay MS]

# Paste text
awesun-cli desktop paste <session-id> <text>

# Key combo (e.g. Ctrl+Alt+Del)
awesun-cli desktop key combo <session-id> --keys K1,K2,... [--delay MS]

# Key press/release
awesun-cli desktop key press <session-id> --keys K1,K2,... [--press down|up]
```

### File Management

```bash
# List directory contents
awesun-cli file ls <session-id> [--path PATH] [--limit N] [--keyword KEY]

# Create directory
awesun-cli file mkdir <session-id> --path PATH --name NAME

# Remove file or directory (-r for recursive)
awesun-cli file rm <session-id> --path PATH [-r]

# Rename/move file
awesun-cli file mv <session-id> --path PATH --new-name NAME

# Transfer files (upload/download)
awesun-cli file transfer <session-id> \
  --type up|down \
  --local PATH \
  --remote PATH \
  [--override]

# Check transfer status
awesun-cli file transfer status <session-id> [--transfer-id ID]

# Cancel a transfer
awesun-cli file transfer cancel <session-id> [--transfer-id ID]
```

### Port Forwarding

```bash
# Configure port forwarding channels
awesun-cli forward config <session-id> --channels JSON
```

### SSH

```bash
# Get SSH connection address
awesun-cli ssh address <session-id>
```

### Utility

```bash
# Stop the background daemon service
awesun-cli stop-daemon

# Clear configuration cache
awesun-cli config clean-cache
```

### Interactive Mode

```bash
awesun-cli --interact
# or
awesun-cli -i
```

## Examples

### Login and Connect to a Device

```bash
# Login
awesun-cli login --user myaccount

# List devices
awesun-cli device ls

# Connect to desktop
awesun-cli session connect --remote-id 12345 --type desktop

# Take a screenshot
awesun-cli session screenshot <session-id> --output ~/Desktop/screenshot.png
```

### File Transfer

```bash
# Connect file session
awesun-cli session connect --remote-id 12345 --type file

# List remote files
awesun-cli file ls <session-id> --path /home/user/documents

# Download a file
awesun-cli file transfer <session-id> \
  --type down \
  --remote /home/user/documents/report.pdf \
  --local ./report.pdf

# Upload a file
awesun-cli file transfer <session-id> \
  --type up \
  --local ./photo.jpg \
  --remote /home/user/Pictures/photo.jpg
```

### Remote Desktop Control

```bash
# Connect desktop session
awesun-cli session connect --remote-id 12345 --type desktop

# Move mouse to position (100, 200)
awesun-cli desktop mouse move <session-id> --x 100 --y 200

# Left click at (100, 200)
awesun-cli desktop mouse click <session-id> --x 100 --y 200

# Type text
awesun-cli desktop type <session-id> "Hello, World!"

# Send Ctrl+Alt+Del
awesun-cli desktop key combo <session-id> --keys 17,18,46
```

### SSH Access

```bash
# Connect SSH session
awesun-cli session connect --remote-id 12345 --type ssh

# Get SSH address
awesun-cli ssh address <session-id>
```

## Logs

Log files are stored in:

### macOS / Linux

```text
~/awesun-cli/log/
```

### Windows

```text
%USERPROFILE%\awesun-cli\log\
```

## Notes

- During installation, the package automatically downloads the appropriate native binary for your operating system and architecture.
- The CLI runs a background daemon service for session management. The service starts automatically on demand and can be stopped with `awesun-cli stop-daemon`.
- No manual setup is required after installation.
- Enable verbose mode (`-v` or `--verbose`) for debug-level logging to diagnose issues.

## License

Copyright (c) 2026 Oray Inc. All rights reserved.