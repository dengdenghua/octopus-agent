/*
 * Copyright (c) 2026 Oray Inc. All rights reserved.
 *
 * No Part of this file may be reproduced, stored
 * in a retrieval system, or transmitted, in any form, or by any means,
 * electronic, mechanical, photocopying, recording, or otherwise,
 * without the prior consent of Oray Inc.
 *
 * @Author: liuchanghuang1<liuchanghuang1@oray.com>
 * @Date: 2026-05-09
 * @LastEditors: liuchanghuang1<liuchanghuang1@oray.com>
 * @LastEditTime: 2026-05-09 11:25:00
 * @FileName: install.js
 * @Description: []
 */

const fs = require("fs");
const path = require("path");
const https = require("https");
const http = require("http");
const { execSync } = require("child_process");

const CDN_BASE_URL = process.env.AWESUN_CLI_CDN_URL || "https://d-cdn.oray.com/sunlogin/cli";
const COMMIT_SHA = process.env.AWESUN_CLI_COMMIT_SHA || "9b9fe178";

function getPlatform() {
  const platform = process.platform;
  const arch = process.arch;

  const platformMap = {
    win32: "windows",
    darwin: "macos",
    linux: "linux",
  };

  const os = platformMap[platform];
  if (!os) {
    console.error(`Unsupported platform: ${platform}`);
    process.exit(1);
  }

  const archMap = {
    windows: {
      x64: "x64",
      arm64: "arm64",
      ia32: "x86",
    },
    macos: {
      x64: "x86_64",
      arm64: "arm64",
    },
    linux: {
      x64: "x86_64",
      arm64: "aarch64",
    },
  };

  const cpu = archMap[os] && archMap[os][arch];
  if (!cpu) {
    console.error(`Unsupported arch: ${arch} for ${os}`);
    process.exit(1);
  }

  return { os, cpu, isWindows: platform === "win32" };
}

function download(url, dest) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith("https") ? https : http;

    const doDownload = (downloadUrl) => {
      client
        .get(downloadUrl, (res) => {
          if (
            res.statusCode >= 300 &&
            res.statusCode < 400 &&
            res.headers.location
          ) {
            doDownload(res.headers.location);
            return;
          }

          if (res.statusCode !== 200) {
            reject(new Error(`Download failed: HTTP ${res.statusCode}`));
            return;
          }

          const stream = fs.createWriteStream(dest);
          res.pipe(stream);
          stream.on("finish", () => {
            stream.close(resolve);
          });
          stream.on("error", reject);
        })
        .on("error", reject);
    };

    doDownload(url);
  });
}

function unzipWindows(archivePath, binDir) {
  // Expand-Archive requires PowerShell 5.0+ (Win10+ default).
  // Fall back through .NET ZipFile (.NET 4.5+) → COM Shell.Application (any Windows).
  const psEsc = (s) => `'${s.replace(/'/g, "''")}'`;

  const script = [
    `$zip = ${psEsc(archivePath)}`,
    `$dest = ${psEsc(binDir)}`,
    // 1. Try Expand-Archive (PS 5.0) — best, synchronous
    `if (Get-Command Expand-Archive -ErrorAction SilentlyContinue) {`,
    `  Expand-Archive -Path $zip -DestinationPath $dest -Force`,
    `  exit 0`,
    `}`,
    // 2. Try .NET System.IO.Compression.ZipFile (.NET 4.5) — synchronous
    `try {`,
    `  Add-Type -AssemblyName System.IO.Compression.FileSystem`,
    `  [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $dest)`,
    `  exit 0`,
    `} catch {}`,
    // 3. Fall back to COM Shell.Application — async, need polling
    `$shell = New-Object -ComObject Shell.Application`,
    `$zipItems = $shell.NameSpace($zip)`,
    `$shell.NameSpace($dest).CopyHere($zipItems.Items(), 16)`,
    // Poll until file count matches (async CopyHere)
    `$count = $zipItems.Items().Count`,
    `for ($i = 0; $i -lt 30; $i++) {`,
    `  if ((Get-ChildItem $dest -Recurse -File).Count -ge $count) { exit 0 }`,
    `  Start-Sleep -Milliseconds 500`,
    `}`,
    `exit 1`,
  ].join("; ");

  try {
    execSync(`powershell -NoProfile -Command "${script}"`, {
      stdio: "inherit",
      timeout: 120000,
    });
  } catch (err) {
    throw new Error(`Unzip failed: ${err.message}`);
  }
}

function recreateSymlink(target, linkPath, isDir = false) {
  try {
    if (fs.existsSync(linkPath)) {
      fs.rmSync(linkPath, { recursive: true, force: true });
    }

    fs.symlinkSync(target, linkPath, isDir ? "dir" : "file");
  } catch (err) {
    console.error(`Create symlink failed: ${linkPath}`, err.message);
    process.exit(1);
  }
}

async function main() {
  const pkg = JSON.parse(
    fs.readFileSync(path.join(__dirname, "package.json"), "utf8")
  );
  const version = pkg.version;

  if (!version || version === "0.0.0") {
    console.error("Invalid version in package.json:", version);
    process.exit(1);
  }

  const { os, cpu, isWindows } = getPlatform();
  const ext = isWindows ? ".zip" : ".tgz";
  const shaSuffix = COMMIT_SHA ? `-${COMMIT_SHA}` : "";
  const filename = `awesun-cli-${version}-${os}-${cpu}${shaSuffix}${ext}`;
  // const downloadUrl = `${CDN_BASE_URL}/${version}/${filename}`;
  const downloadUrl = `${CDN_BASE_URL}/${filename}`;

  const binDir = path.join(require("os").homedir(), ".awesun-cli");
  if (!fs.existsSync(binDir)) {
    fs.mkdirSync(binDir, { recursive: true });
  }

  const archivePath = path.join(binDir, filename);
  const binaryName = isWindows ? "awesun-cli.exe" : "awesun-cli";

  let binaryPath;
  if (os === "macos") {
    binaryPath = path.join(
      binDir,
      "AweSunCli.app",
      "Contents",
      "MacOS",
      binaryName
    );
  } else {
    binaryPath = path.join(binDir, binaryName);
  }

  const versionFile = path.join(binDir, ".version");
  if (fs.existsSync(binaryPath) && fs.existsSync(versionFile)) {
    const installedVersion = fs.readFileSync(versionFile, "utf8").trim();
    if (installedVersion === `${version}-${os}-${cpu}${shaSuffix}`) {
      console.log(`awesun-cli v${version} already installed, skipping download.`);
      return;
    }
  }

  console.log(`Downloading awesun-cli v${version} for ${os}-${cpu}...`);
  console.log(`URL: ${downloadUrl}`);

  try {
    await download(downloadUrl, archivePath);
    console.log("Download complete.");

    if (isWindows) {
      unzipWindows(archivePath, binDir);
    } else {
      execSync(`tar xzf '${archivePath}' -C '${binDir}'`, {
        stdio: "inherit",
      });
    }

    if (!isWindows) {
      fs.chmodSync(binaryPath, 0o755);

      // macOS 创建软链接：bin/awesun-cli -> AweSunCli.app/Contents/MacOS/awesun-cli
      // bin/plugins -> AweSunCli.app/Contents/MacOS/plugins
      // bin/libawesun-cli-plugincontainer.dylib -> AweSunCli.app/Contents/MacOS/libawesun-cli-plugincontainer.dylib
      if (os === "macos") {
        recreateSymlink(
          path.join("AweSunCli.app", "Contents", "MacOS", "awesun-cli"),
          path.join(binDir, "awesun-cli")
        );

        recreateSymlink(
          path.join("AweSunCli.app", "Contents", "MacOS", "plugins"),
          path.join(binDir, "plugins"),
          true
        );

        recreateSymlink(
          path.join(
            "AweSunCli.app",
            "Contents",
            "MacOS",
            "libawesun-cli-plugincontainer.dylib"
          ),
          path.join(binDir, "libawesun-cli-plugincontainer.dylib")
        );
      }
    }

    if (fs.existsSync(archivePath)) {
      fs.unlinkSync(archivePath);
    }

    fs.writeFileSync(versionFile, `${version}-${os}-${cpu}${shaSuffix}`);

    console.log(`awesun-cli v${version} installed successfully.`);
  } catch (err) {
    console.error("Installation failed:", err.message);
    console.error(
      "You can manually download from: " + downloadUrl
    );
    process.exit(1);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
