#!/usr/bin/env node
/*
 * Copyright (c) 2026 Oray Inc. All rights reserved.
 *
 * No Part of this file may be reproduced, stored
 * in a retrieval system, or transmitted, in any form, or by any means,
 * electronic, mechanical, photocopying, recording, or otherwise,
 * without the prior consent of Oray Inc.
 *
 * @Author: liuchanghuang1<liuchanghuang1@oray.com>
 * @Date: 2026-05-09
 * @LastEditors: liuchanghuang1<liuchanghuang1@oray.com>
 * @LastEditTime: 2026-05-09 11:25:37
 * @FileName: run.js
 * @Description: []
 */

const { spawn } = require("child_process");
const path = require("path");

const isWindows = process.platform === "win32";
const binaryName = isWindows ? "awesun-cli.exe" : "awesun-cli";
const binaryPath = path.join(require("os").homedir(), ".awesun-cli", binaryName);

const child = spawn(binaryPath, process.argv.slice(2), {
  stdio: "inherit",
  env: process.env,
});

child.on("exit", (code) => {
  process.exit(code || 0);
});
