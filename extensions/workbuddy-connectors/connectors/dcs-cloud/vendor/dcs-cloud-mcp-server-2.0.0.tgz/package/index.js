#!/usr/bin/env node
// DCS Cloud MCP Server (v2: bootstrap-only)
//
// This MCP server handles ONLY bootstrap for the WorkBuddy Connector:
//   1. Download the dcs CLI binary for the current platform from GitHub
//      Releases (SHA256-verified, auto-updated to the latest release).
//   2. Log in with the Personal Access Token (PAT) the user pasted into the
//      WorkBuddy form (passed via the DCS_PAT env var, never argv).
// The single `dcs_setup` tool returns the binary path + version + login
// status. The host AI then runs dcs commands DIRECTLY in its terminal —
// login state persists in ~/.dcs/config.yaml and is shared with any dcs
// process of the same user, so no further MCP round-trips are needed.
// The 20 former wrapper tools were removed: the CLI is the API now
// (see skills/SKILL.md for the usage contract).

import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import path from "node:path";
import os from "node:os";
import fs from "node:fs";
import crypto from "node:crypto";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------
// dcs binary is downloaded on first run from GitHub Releases (per platform) and
// cached under ~/.workbuddy/connectors/dcs-cloud/bin. Override the release base
// via DCS_RELEASE_BASE if you publish to a different tag.
const DCS_RELEASE_BASE =
  process.env.DCS_RELEASE_BASE ||
  "https://github.com/BGIResearch/dcs_cli/releases/download/v1.1.0";

// Per-platform download assets from GitHub Releases. Mac picks the asset by
// CPU arch (Intel = amd64, Apple Silicon = arm64) so it runs natively without
// Rosetta. Override the release base via DCS_RELEASE_BASE.
const PLATFORM_ASSET = {
  win32: { url: `${DCS_RELEASE_BASE}/dcs.exe`, name: "dcs.exe" },
  linux: { url: `${DCS_RELEASE_BASE}/dcs-linux-amd64`, name: "dcs-linux-amd64" },
  darwin:
    process.arch === "arm64"
      ? { url: `${DCS_RELEASE_BASE}/dcs-darwin-arm64`, name: "dcs-darwin-arm64" }
      : { url: `${DCS_RELEASE_BASE}/dcs-darwin-amd64`, name: "dcs-darwin-amd64" },
};

const BIN_CACHE_DIR = path.join(os.homedir(), ".workbuddy", "connectors", "dcs-cloud", "bin");
const VERSION_FILE = path.join(BIN_CACHE_DIR, ".version");

let DCS_BIN = null;

// ---------------------------------------------------------------------------
// Version check: query GitHub API for latest release tag
// ---------------------------------------------------------------------------
async function fetchLatestVersion() {
  try {
    const res = await fetchWithRetry(
      "https://api.github.com/repos/BGIResearch/dcs_cli/releases/latest",
      { retries: 2, baseDelayMs: 300 }
    );
    const data = await res.json();
    return data?.tag_name || null;
  } catch (e) {
    // If API fails, fall back to current hardcoded version
    console.error(`[dcs-cloud] Failed to check latest version: ${e.message}`);
    return null;
  }
}

function getCachedVersion() {
  try {
    if (fs.existsSync(VERSION_FILE)) {
      return fs.readFileSync(VERSION_FILE, "utf-8").trim();
    }
  } catch {}
  return null;
}

function saveCachedVersion(version) {
  try {
    fs.writeFileSync(VERSION_FILE, version, "utf-8");
  } catch (e) {
    console.error(`[dcs-cloud] Failed to save version file: ${e.message}`);
  }
}

// Retry a fetch with exponential backoff. Transient network blips shouldn't
// permanently block binary download / checksum verification.
async function fetchWithRetry(url, { retries = 3, baseDelayMs = 500 } = {}) {
  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, { redirect: "follow" });
      if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`);
      return res;
    } catch (e) {
      lastErr = e;
      if (attempt < retries) {
        const delay = baseDelayMs * Math.pow(2, attempt);
        await new Promise((r) => setTimeout(r, delay));
      }
    }
  }
  throw new Error(`fetch failed after ${retries + 1} attempts (${url}): ${lastErr}`);
}

// Fetch ${DCS_RELEASE_BASE}/SHA256SUMS and parse into Map<assetName, sha256Hex>.
// Format per line: "<64-hex-hash>  <filename>" (GNU coreutils; tolerate 1-2 spaces,
// optional leading "*" binary-mode marker, blank/comment lines).
async function fetchSha256Sums() {
  const url = `${DCS_RELEASE_BASE}/SHA256SUMS`;
  const res = await fetchWithRetry(url);
  const text = await res.text();
  const map = new Map();
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const m = trimmed.match(/^([0-9a-fA-F]{64})\s+\*?(.+)$/);
    if (m) map.set(m[2], m[1].toLowerCase());
  }
  return map;
}

// Download the dcs binary for the current platform if not already cached.
// Verifies the SHA256 against the release's SHA256SUMS before writing to disk;
// a mismatch (tampering / corruption) is refused — the buffer never lands on
// disk and is never executed. Cached binaries are trusted after first verify
// (same model as npm/cargo).
//
// Auto-update: checks GitHub API for latest release version; if newer than
// cached version, deletes old binary and re-downloads.
async function ensureDcsBinary() {
  if (DCS_BIN) return DCS_BIN;
  const p = PLATFORM_ASSET[process.platform];
  if (!p) {
    throw new Error(`Unsupported platform: ${process.platform}. Supported: win32, linux, darwin.`);
  }

  // Check for updates from GitHub API
  const latestVersion = await fetchLatestVersion();
  const cachedVersion = getCachedVersion();

  // If we have a new version (or no cached version info), force re-download
  const shouldUpdate = latestVersion && (!cachedVersion || latestVersion !== cachedVersion);
  const target = path.join(BIN_CACHE_DIR, p.name);

  if (shouldUpdate && fs.existsSync(target)) {
    console.log(`[dcs-cloud] Updating dcs ${cachedVersion || "unknown"} → ${latestVersion}`);
    try {
      fs.unlinkSync(target);
      console.log(`[dcs-cloud] Removed old binary for update`);
    } catch (e) {
      console.error(`[dcs-cloud] Failed to remove old binary: ${e.message}`);
    }
  }

  if (fs.existsSync(target)) {
    DCS_BIN = target;
    return DCS_BIN;
  }
  fs.mkdirSync(BIN_CACHE_DIR, { recursive: true });

  // 1) Download binary into an in-memory buffer (with retry).
  const res = await fetchWithRetry(p.url);
  const buf = Buffer.from(await res.arrayBuffer());

  // 2) Fetch + parse SHA256SUMS (with retry; exhausting retries throws = fail-closed).
  const sums = await fetchSha256Sums();
  const expected = sums.get(p.name);
  if (!expected) {
    throw new Error(
      `SHA256SUMS does not contain an entry for "${p.name}". Refusing to execute unverified binary.`
    );
  }

  // 3) Verify hash. On mismatch: do NOT write, do NOT chmod, do NOT cache.
  const actual = crypto.createHash("sha256").update(buf).digest("hex");
  if (actual !== expected) {
    throw new Error(
      `dcs binary SHA256 mismatch for ${p.name}: expected ${expected}, got ${actual}. ` +
      `Possible tampering or corrupted download. Refusing to execute.`
    );
  }

  // 4) Verified: persist to disk + chmod + cache.
  await fs.promises.writeFile(target, buf);
  if (process.platform !== "win32") fs.chmodSync(target, 0o755);

  // Save version info for future update checks
  const currentVersion = latestVersion || DCS_RELEASE_BASE.match(/\/v[\d.]+/)?.[0]?.slice(1) || "unknown";
  saveCachedVersion(currentVersion);
  console.log(`[dcs-cloud] Downloaded dcs ${currentVersion} (${p.name})`);

  DCS_BIN = target;
  return DCS_BIN;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
// Sanitize subprocess output before folding it into an error message that gets
// returned to the AI: (1) redact anything that looks like a PAT or bearer token,
// (2) truncate to keep error messages bounded. dcs CLI errors occasionally echo
// the token or internal URLs; without this they'd be sent to the LLM.
const REDACT_PATTERNS = [
  /dcs_pat_[A-Za-z0-9_\-]+/g,        // DCS Personal Access Token (dcs_pat_ prefix)
  /Bearer\s+[A-Za-z0-9_\-\.=]+/g,    // HTTP bearer tokens
  /--token\s+\S+/g,                  // any leaked --token <value> argv echo
];
const MAX_ERR_LEN = 500;
function sanitizeOutput(s) {
  let out = s == null ? "" : String(s);
  for (const re of REDACT_PATTERNS) out = out.replace(re, "***REDACTED***");
  if (out.length > MAX_ERR_LEN) out = out.slice(0, MAX_ERR_LEN) + "...(truncated)";
  return out;
}

// Default per-subprocess timeout (ms). Guards against the dcs CLI hanging on
// network issues or deadlocks — without this, a stuck child would block the
// MCP server forever (mcp.json's timeout only covers the MCP protocol layer,
// not the spawned subprocess). Override per-call via opts.timeout.
const DEFAULT_CMD_TIMEOUT_MS = 30000;

function runCmd(bin, args, opts = {}) {
  return new Promise((resolve) => {
    const child = spawn(bin, args, {
      stdio: ["ignore", "pipe", "pipe"],
      shell: false,
      env: { ...process.env, ...(opts.env || {}) },
      ...opts.spawnOpts,
    });
    let stdout = "";
    let stderr = "";
    let settled = false;
    const timeout = opts.timeout ?? DEFAULT_CMD_TIMEOUT_MS;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      // SIGTERM first; escalate to SIGKILL after a 2s grace period if it survives.
      try { child.kill("SIGTERM"); } catch {}
      setTimeout(() => {
        if (!child.killed) {
          try { child.kill("SIGKILL"); } catch {}
        }
      }, 2000);
      resolve({
        code: -1,
        stdout,
        stderr: `command timed out after ${timeout}ms: ${bin} ${args.join(" ")}`,
        timedOut: true,
      });
    }, timeout);
    // Keep the timer from keeping the event loop alive if the process exits fast.
    timer.unref?.();
    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(result);
    };
    child.stdout.on("data", (d) => (stdout += d.toString()));
    child.stderr.on("data", (d) => (stderr += d.toString()));
    child.on("error", (e) => finish({ code: -1, stdout, stderr: String(e) }));
    child.on("close", (code) => finish({ code, stdout, stderr }));
  });
}

// ---- auth status (dcs has no `auth status`; use `config show` token_status) ----
async function dcsAuthStatus() {
  try {
    if (!DCS_BIN) await ensureDcsBinary();
    const { code, stdout } = await runCmd(DCS_BIN, ["config", "show", "--output", "json", "--no-history"]);
    if (code !== 0) return false;
    const status = JSON.parse(stdout.trim())?.data?.token_status;
    return !!status && status !== "none";
  } catch {
    return false;
  }
}

// Login via DCS_PAT env var. We deliberately do NOT pass --token <PAT>: that
// would put the PAT in the child process argv, leaking it via `ps` / process
// explorers / audit logs. The dcs CLI reads DCS_PAT from env when no token
// argument is supplied (per `dcs auth login --help`: "No PAT arg -> reads
// DCS_PAT env var"). runCmd already inherits process.env into the child, so
// DCS_PAT is visible to dcs without ever touching argv.
async function dcsLogin() {
  if (!DCS_BIN) await ensureDcsBinary();
  const { code, stdout, stderr } = await runCmd(DCS_BIN, [
    "auth", "login", "--output", "json", "--no-history",
  ]);
  if (code !== 0) {
    throw new Error(`dcs auth login failed: ${sanitizeOutput(stderr || stdout)}`.trim());
  }
}

// ---- one-time bootstrap ----
// bootstrapped: login succeeded at least once; skip re-auth on subsequent calls.
// bootstrapError: only caches NON-retryable errors (e.g. DCS_PAT env not set),
// since a missing env var won't change without a process restart. Login failures
// (wrong PAT, network blip) are NOT cached so the user can correct the PAT in
// the WorkBuddy form and retry within the same session without restarting.
let bootstrapped = false;
let bootstrapError = null;
async function ensureAuth() {
  if (bootstrapError) throw bootstrapError;
  if (bootstrapped) return;
  if (await dcsAuthStatus()) {
    bootstrapped = true;
    return;
  }
  const pat = process.env.DCS_PAT;
  if (!pat) {
    bootstrapError = new Error(
      "DCS_PAT is not set. Please create a Personal Access Token in DCS Cloud and paste it into the WorkBuddy connector form."
    );
    throw bootstrapError;
  }
  // Intentionally NOT caching login errors: if dcsLogin throws, bootstrapped
  // stays false and the next call retries — so a corrected PAT takes effect
  // without restarting the server.
  await dcsLogin();
  bootstrapped = true;
}

// ---------------------------------------------------------------------------
// MCP Server
// ---------------------------------------------------------------------------
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";

// The only tool. After it succeeds, the AI runs the dcs CLI directly in its
// terminal for ALL operations — login state lives in ~/.dcs/config.yaml and is
// shared with any dcs process of the same user.
const TOOLS = [
  {
    name: "dcs_setup",
    description:
      "Bootstrap the dcs CLI: download/update the platform binary (SHA256-verified, " +
      "auto-updates to the latest GitHub release) and log in with the configured PAT. " +
      "Returns the binary path, version, and login status. After this succeeds, run " +
      "dcs commands directly in the terminal (always append --output json --no-history).",
    inputSchema: { type: "object", properties: {}, required: [] },
    handler: async () => {
      await ensureDcsBinary();
      await ensureAuth();
      const p = PLATFORM_ASSET[process.platform];
      const binPath = path.join(BIN_CACHE_DIR, p.name);
      return {
        ok: true,
        bin_path: binPath,
        version: getCachedVersion() || "unknown",
        logged_in: true,
        usage:
          `Run "<bin_path> <subcommand> --output json --no-history" in the terminal for all ` +
          `DCS Cloud operations. Quote the path if it contains spaces (Windows: ` +
          `& "C:\\...\\dcs.exe" project ls --output json --no-history).`,
      };
    },
  },
];

function toContent(result) {
  let text;
  if (result === null || result === undefined) text = "(no output)";
  else if (typeof result === "string") text = result;
  else text = JSON.stringify(result, null, 2);
  return { content: [{ type: "text", text }] };
}

async function main() {
  // Pre-download the dcs binary at startup so dcs_setup responds fast.
  try {
    await ensureDcsBinary();
  } catch (e) {
    console.error(`[dcs-cloud-mcp] binary download failed: ${e.message}`);
    // Continue starting the server; dcs_setup will surface a clear error.
  }
  const server = new Server(
    { name: "dcs-cloud-mcp-server", version: "2.0.0" },
    { capabilities: { tools: {} } }
  );
  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: TOOLS.map((t) => ({ name: t.name, description: t.description, inputSchema: t.inputSchema })),
  }));
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args } = request.params;
    const tool = TOOLS.find((t) => t.name === name);
    if (!tool) return { content: [{ type: "text", text: `Unknown tool: ${name}` }], isError: true };
    try {
      const result = await tool.handler(args || {});
      return toContent(result);
    } catch (e) {
      return { content: [{ type: "text", text: `Error: ${e.message || String(e)}` }], isError: true };
    }
  });
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("[dcs-cloud-mcp] ready (bootstrap-only mode)");
}

main().catch((e) => {
  console.error("[dcs-cloud-mcp] fatal:", e);
  process.exit(1);
});
