/**
 * 调用 /oauth2/device/authorization 端点获取 device_code / user_code 等。
 * Miaoda 平台的设备授权端点（占位，需与平台确认实际路径）。
 */
export async function requestDeviceCode(cfg, signal) {
  const form = new URLSearchParams();
  form.set('client_id', cfg.clientId);
  form.set('scope', cfg.scope || 'profile:read apps:read apps:write');
  const endpoint = `${cfg.platformUrl.replace(/\/+$/, '')}/oauth2/device/authorization`;
  const headers = {'Content-Type': 'application/x-www-form-urlencoded'};

  if (cfg.debug) {
    console.log(`[DEBUG] POST ${endpoint} body=${form.toString()}`);
  }

  const resp = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: form.toString(),
    signal
  });
  const body = await resp.text();
  if (cfg.debug) {
    console.log(`[DEBUG] status=${resp.status} body=${body}`);
  }
  if (resp.status !== 200) {
    throw new Error(`status=${resp.status} body=${body}`);
  }
  const out = JSON.parse(body);
  if (!out.interval || out.interval <= 0) {
    out.interval = 5; // RFC 8628 默认 5 秒
  }
  return out;
}
