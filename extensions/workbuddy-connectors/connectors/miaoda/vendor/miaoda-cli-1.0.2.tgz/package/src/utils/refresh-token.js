import {saveToken} from './save-token.js';

/**
 * 使用 refresh_token 刷新 access_token。
 * 成功后自动更新 ~/.miaoda/token 文件并返回新的 access_token。
 */
export async function refreshAccessToken(store) {
  if (!store.refresh_token) {
    throw new Error('no refresh_token');
  }
  const platformUrl = store.platform_url || 'https://www.miaoda.cn';
  const clientId =
    store.client_id || process.env.OAUTH2_CLIENT_ID || 'miaoda_cli';
  const tokenUrl = `${platformUrl.replace(/\/+$/, '')}/oauth2/token`;

  const form = new URLSearchParams();
  form.set('grant_type', 'refresh_token');
  form.set('refresh_token', store.refresh_token);
  form.set('client_id', clientId);

  const nowSec = Math.floor(Date.now() / 1000);
  const resp = await fetch(tokenUrl, {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: form.toString()
  });
  if (resp.status !== 200) {
    const body = await resp.text();
    throw new Error(`refresh token failed: status=${resp.status} body=${body}`);
  }
  const tok = await resp.json();
  const newStore = {
    access_token: tok.access_token,
    expires_at: nowSec + tok.expires_in,
    refresh_token: tok.refresh_token || store.refresh_token,
    platform_url: store.platform_url,
    client_id: store.client_id,
    login_host: store.login_host
  };
  saveToken(newStore);
  return tok.access_token;
}
