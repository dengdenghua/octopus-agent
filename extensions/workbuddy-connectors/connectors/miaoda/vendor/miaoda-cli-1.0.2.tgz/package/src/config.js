// Interactive prompt helper used by `chat --prompt-generate`.
import readline from 'node:readline';

/**
 * 向 stdin/stdout 提示并等待用户输入一行。
 * @param {string} question
 * @returns {Promise<string>}
 */
export function prompt(question) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise(resolve => {
    rl.question(question, answer => {
      rl.close();
      resolve(answer);
    });
  });
}
