/** 脱敏展示长 token */
export function maskToken(tok) {
  if (!tok || tok.length <= 12) {
    return tok;
  }
  return `${tok.slice(0, 8)}...${tok.slice(-4)}`;
}
