// Exit codes shared across commands — mirrors the CNB skill's convention
// so downstream automation (WorkBuddy) can branch on process.exitCode consistently.
export const EXIT_CODE = {
  OK: 0,
  GENERIC_ERROR: 1,
  AUTH_REQUIRED: 1 // 未登录 / 登录已过期且无法刷新 —— 与 cnb-skill 保持一致，统一退出码 1
};
