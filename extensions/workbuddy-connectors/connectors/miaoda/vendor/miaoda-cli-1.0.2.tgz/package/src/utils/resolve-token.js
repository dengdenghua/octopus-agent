import {resolveTokenSource} from './resolve-token-source.js';
import {refreshAccessToken} from './refresh-token.js';
import {EXIT_CODE} from '../exit-code.js';

/**
 * 获取有效的 access_token。
 *
 * 优先使用环境变量 MIAODA_TOKEN（不检查过期）。
 * 否则从 ~/.miaoda/token 读取，若已过期则尝试用 refresh_token 刷新；
 * 刷新失败或无 refresh_token 时终止进程并提示用户重新登录。
 */
export async function resolveToken() {
  const result = await resolveTokenSource();
  if (result.source === 'none') {
    console.error(
      result.reason ||
        '未找到有效的登录凭证，请先执行 `miaoda login` 进行授权。'
    );
    process.exit(EXIT_CODE.AUTH_REQUIRED);
  }

  // 环境变量来源直接返回，不做过期检查
  if (
    result.source === 'workbuddy' ||
    result.source === 'codebuddy_env' ||
    result.source === 'env'
  ) {
    return result.access_token;
  }

  // 文件来源 - 检查过期
  const store = result.store;
  const nowSec = Math.floor(Date.now() / 1000);

  // 未过期，直接返回
  if (nowSec < store.expires_at) {
    return result.access_token;
  }

  // 已过期，尝试 refresh
  if (store.refresh_token) {
    try {
      return await refreshAccessToken(store);
    } catch (err) {
      console.error(`Token 已过期，刷新失败: ${err.message}`);
      console.error('请重新执行 `miaoda login` 进行授权。');
      process.exit(EXIT_CODE.AUTH_REQUIRED);
    }
  }
  console.error(
    'Token 已过期且无 refresh_token，请重新执行 `miaoda login` 进行授权。'
  );
  process.exit(EXIT_CODE.AUTH_REQUIRED);
}
