import fs from 'node:fs';
import {getPendingAuthPath} from './pending-auth-path.js';

/** 删除设备授权的待授权状态文件；文件不存在时静默返回 false */
export function clearPendingAuth() {
  const pendingPath = getPendingAuthPath();
  if (!fs.existsSync(pendingPath)) {
    return false;
  }
  try {
    fs.unlinkSync(pendingPath);
    return true;
  } catch {
    return false;
  }
}
