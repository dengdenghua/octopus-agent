import fs from 'node:fs';
import {getTokenPath} from './token-path.js';

/** 读取已保存的 token */
export function loadToken() {
  const tokenPath = getTokenPath();
  if (!fs.existsSync(tokenPath)) {
    return null;
  }
  try {
    return JSON.parse(fs.readFileSync(tokenPath, 'utf-8'));
  } catch {
    return null;
  }
}
