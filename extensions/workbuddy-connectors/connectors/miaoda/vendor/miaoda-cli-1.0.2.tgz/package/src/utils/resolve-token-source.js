import {getTokenEnvKey} from './get-token-env-key.js';
import {isWorkBuddySandbox} from './is-workbuddy-sandbox.js';
import {loadToken} from './load-token.js';
import {loadPendingAuth} from './load-pending-auth.js';

/**
 * 统一判断 token 来源，不退出进程、不自动刷新。
 *
 * 优先级：
 * 1. WorkBuddy 沙箱环境 → 远程接口获取
 * 2. MIAODA_TOKEN_FOR_CODEBUDDY 环境变量
 * 3. MIAODA_TOKEN 环境变量
 * 4. 文件 token（~/.miaoda/token）
 */
export async function resolveTokenSource() {
  // WorkBuddy 沙箱环境，从远程接口获取 token
  if (isWorkBuddySandbox()) {
    const tokenURL = process.env[getTokenEnvKey()];
    if (!tokenURL) {
      return {
        source: 'none',
        reason: `未找到环境变量 ${getTokenEnvKey()}，无法在 WorkBuddy 沙箱环境中获取 token。`
      };
    }
    try {
      const resp = await fetch(tokenURL, {
        method: 'GET',
        headers: {Accept: 'application/json'}
      });
      if (!resp.ok) {
        return {
          source: 'none',
          reason: `从 WorkBuddy 获取 token 失败，HTTP 状态码: ${resp.status} ${resp.statusText}`
        };
      }
      const body = await resp.json();
      if (body?.code !== 0 || !body?.data?.access_token) {
        return {
          source: 'none',
          reason: `从 WorkBuddy 获取 token 失败，响应内容异常: ${JSON.stringify(body)}`
        };
      }
      return {source: 'workbuddy', access_token: body.data.access_token};
    } catch (err) {
      return {
        source: 'none',
        reason: `从 WorkBuddy 获取 token 失败: ${err?.message || err}`
      };
    }
  }

  // 环境变量优先 CodeBuddy
  if (process.env.MIAODA_TOKEN_FOR_CODEBUDDY) {
    if (
      !process.env.MIAODA_NPC_SLUG &&
      process.env.MIAODA_NPC_NAME === 'CodeBuddy'
    ) {
      return {
        source: 'codebuddy_env',
        access_token: process.env.MIAODA_TOKEN_FOR_CODEBUDDY
      };
    }
  }

  // 环境变量优先，不做过期判断
  if (process.env.MIAODA_TOKEN) {
    return {source: 'env', access_token: process.env.MIAODA_TOKEN};
  }

  // 文件 token
  const store = loadToken();
  if (!store || !store.access_token) {
    // 存在未完成的设备授权时，引导用户执行 status 完成轮询
    if (loadPendingAuth()) {
      return {
        source: 'none',
        reason:
          '设备授权尚未完成，请在浏览器完成授权后执行 `miaoda status` 完成登录。'
      };
    }
    return {source: 'none'};
  }
  return {source: 'file', access_token: store.access_token, store};
}
