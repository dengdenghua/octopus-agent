import {loadToken} from './load-token.js';

/**
 * 获取 API 域名。
 *
 * 优先级：
 * 1. 如果设置了环境变量 MIAODA_TOKEN（即非 OAuth 登录），使用 MIAODA_API_ENDPOINT 或默认值
 * 2. 如果是 OAuth 登录（token 文件中有 login_host），使用登录时记录的域名
 * 3. 兜底使用 MIAODA_API_ENDPOINT 或默认值 https://www.miaoda.cn
 */
export function resolveApiDomain() {
  const defaultDomain =
    process.env.MIAODA_API_ENDPOINT || 'https://www.miaoda.cn';

  // 如果使用环境变量 token，直接走 MIAODA_API_ENDPOINT
  if (process.env.MIAODA_TOKEN_FOR_CODEBUDDY || process.env.MIAODA_TOKEN) {
    return defaultDomain;
  }

  // OAuth 登录场景：优先使用登录时记录的域名
  const store = loadToken();
  if (store?.login_host) {
    return store.login_host;
  }
  return defaultDomain;
}
