export function isWorkBuddySandbox() {
  return !!process.env.AGENTOS_RUNTIME_ID;
}
