// connector name 由 WorkBuddy 与 CLI 团队约定，CLI 写死
const CONNECTOR_NAME = 'miaoda-app';

export function getTokenEnvKey() {
  // miaoda-app → WORKBUDDY_TOKEN_URL_MIAODA_APP
  return `WORKBUDDY_TOKEN_URL_${CONNECTOR_NAME.toUpperCase().replace(/-/g, '_')}`;
}
