import fs from 'node:fs';
import path from 'node:path';
import {getPendingAuthPath} from './pending-auth-path.js';

/**
 * 持久化设备授权的待授权状态到 ~/.miaoda/pending-auth。
 *
 * WorkBuddy 规范下 `login` 进程返回后会被 kill，无法在 login 里长时间轮询，
 * 因此把 device_code 等信息落盘，交由后续的 `status` 命令继续轮询换取 token。
 */
export function savePendingAuth(pending) {
  const pendingPath = getPendingAuthPath();
  const dir = path.dirname(pendingPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, {recursive: true});
  }
  fs.writeFileSync(pendingPath, JSON.stringify(pending, null, 2), {
    mode: 0o600
  });
}
