import fs from 'node:fs';
import {getTokenPath} from '../utils/token-path.js';
import {loadToken} from '../utils/load-token.js';
import {clearPendingAuth} from '../utils/clear-pending-auth.js';
import {EXIT_CODE} from '../exit-code.js';

/**
 * `miaoda logout` — 删除本地保存的 access_token 以及未完成的设备授权记录
 * （对齐 cnb-skill 的实现）。
 */
export function registerLogoutCommand(program) {
  program
    .command('logout')
    .description('退出登录，删除本地保存的 access_token')
    .option('--debug', '打印调试信息', false)
    .helpOption('-h, --help', '显示帮助文档')
    .action(async opts => {
      const tokenPath = getTokenPath();
      const token = loadToken();
      // 未完成的设备授权记录一并清理，避免下次 status 继续轮询旧的 device_code
      const pendingCleared = clearPendingAuth();
      if (!token) {
        console.log(
          pendingCleared
            ? '已清理未完成的授权请求，当前未登录。'
            : '当前未登录，无需退出。'
        );
        return;
      }
      if (opts.debug) {
        console.log(`Token 文件路径: ${tokenPath}`);
        console.log(`Platform URL : ${token.platform_url}`);
        console.log(`Client ID    : ${token.client_id}`);
      }
      try {
        fs.unlinkSync(tokenPath);
        console.log('已成功退出登录。');
      } catch (err) {
        console.error(`退出登录失败: ${err.message}`);
        process.exit(EXIT_CODE.GENERIC_ERROR);
      }
    });
}
