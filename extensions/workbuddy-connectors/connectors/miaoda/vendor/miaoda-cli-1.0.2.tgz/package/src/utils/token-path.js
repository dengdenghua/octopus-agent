import path from 'node:path';
import os from 'node:os';

/** Miaoda token 存储路径 */
export function getTokenPath() {
  return path.join(os.homedir(), '.miaoda', 'token');
}
