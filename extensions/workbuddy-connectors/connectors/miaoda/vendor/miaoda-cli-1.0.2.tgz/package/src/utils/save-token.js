import fs from 'node:fs';
import path from 'node:path';
import {getTokenPath} from './token-path.js';

/** 持久化 token 到 ~/.miaoda/token */
export function saveToken(store) {
  const tokenPath = getTokenPath();
  const dir = path.dirname(tokenPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, {recursive: true});
  }
  fs.writeFileSync(tokenPath, JSON.stringify(store, null, 2), {mode: 0o600});
}
