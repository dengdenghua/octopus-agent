import {requestDeviceCode} from '../utils/request-device-code.js';
import {tryOpenBrowser} from '../utils/open-browser.js';
import {loadToken} from '../utils/load-token.js';
import {savePendingAuth} from '../utils/save-pending-auth.js';
import {maskToken} from '../utils/mask-token.js';
import {EXIT_CODE} from '../exit-code.js';

const DEFAULT_PLATFORM_URL =
  process.env.MIAODA_PLATFORM_URL || 'https://www.miaoda.cn';

/**
 * `miaoda login` — OAuth2 Device Authorization Grant 登录的第一阶段。
 *
 * WorkBuddy 规范下 login 命令返回后进程会立即被 kill，因此这里 **不做轮询**：
 *   1. requestDeviceCode → 拿 device_code / user_code / verification_uri_complete
 *   2. 打印授权链接，尝试自动打开浏览器
 *   3. savePendingAuth    → 把 device_code 等落盘到 ~/.miaoda/pending-auth
 *   4. 立即退出；由 `miaoda status` 继续轮询 /oauth2/token 并保存 token
 *
 * 退出码：成功 0；失败 1（与 cnb-skill login.js 的 process.exit(1) 保持一致）。
 */
export function registerLoginCommand(program) {
  program
    .command('login')
    .description(
      '通过 OAuth2 设备授权流登录秒哒 (Miaoda)，生成授权链接（授权完成后执行 `miaoda status` 完成登录）'
    )
    .option(
      '--client-id <string>',
      'OAuth2 client_id',
      process.env.OAUTH2_CLIENT_ID || 'workbuddy-cli'
    )
    .option(
      '--platform-url <string>',
      '平台地址 ' + DEFAULT_PLATFORM_URL + '）',
      process.env.MIAODA_PLATFORM_URL || DEFAULT_PLATFORM_URL
    )
    .option('--no-browser', '禁止自动打开浏览器，仅打印授权链接', false)
    .option('--debug', '打印调试信息', false)
    .helpOption('-h, --help', '显示帮助文档')
    .action(async opts => {
      const cfg = {
        clientId: opts.clientId,
        platformUrl: opts.platformUrl,
        debug: opts.debug
      };

      const ac = new AbortController();
      process.on('SIGINT', () => ac.abort());
      process.on('SIGTERM', () => ac.abort());

      // Logged in且未过期，直接返回，避免重复走设备授权流程
      const existing = loadToken();
      if (existing && existing.expires_at > Math.floor(Date.now() / 1000)) {
        console.log(
          'Logged in，无需重复授权。如需重新登录，请先执行 `miaoda logout`。'
        );
        return;
      }

      if (cfg.debug) {
        console.log(
          '========== OAuth2 Device Authorization Grant 登录 =========='
        );
        console.log(`Platform URL : ${cfg.platformUrl}`);
        console.log(`Client ID    : ${cfg.clientId}`);
        console.log(
          '-----------------------------------------------------------'
        );
      }

      try {
        // 步骤 1：获取 device_code + user_code
        const devResp = await requestDeviceCode(cfg, ac.signal);
        const authUrl = devResp.verification_uri_complete;

        // 步骤 2：落盘待授权状态，交给 status 命令继续轮询
        savePendingAuth({
          device_code: devResp.device_code,
          user_code: devResp.user_code,
          verification_uri: devResp.verification_uri,
          verification_uri_complete: authUrl,
          interval: devResp.interval,
          expires_at:
            Math.floor(Date.now() / 1000) + (devResp.expires_in || 600),
          platform_url: cfg.platformUrl,
          client_id: cfg.clientId
        });

        console.log(`\n请打开以下链接完成授权：\n  ${authUrl}\n`);

        // commander 的 --no-browser 会把 opts.browser 置为 false
        if (opts.browser !== false) {
          tryOpenBrowser(authUrl);
          console.log('(已尝试自动打开浏览器，若未打开请手动复制上方链接)');
        }
        if (cfg.debug) {
          console.log('[Debug] 设备注册详情：');
          console.log(
            `  verification_uri          : ${devResp.verification_uri}`
          );
          console.log(
            `  verification_uri_complete : ${devResp.verification_uri_complete}`
          );
          console.log(`  user_code                 : ${devResp.user_code}`);
          console.log(
            `  device_code               : ${maskToken(devResp.device_code)}`
          );
          console.log(`  expires_in                : ${devResp.expires_in}s`);
          console.log(`  interval                  : ${devResp.interval}s`);
        }

        console.log(
          '浏览器授权完成后，请执行 `miaoda status` 完成登录并保存凭证。'
        );
      } catch (err) {
        console.error(`\n登录失败: ${err.message}`);
        process.exit(EXIT_CODE.GENERIC_ERROR);
      }
    });
}
