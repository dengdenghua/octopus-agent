// Miaoda Platform HTTP API client — Node.js port of scripts/miaoda_api.py
import {randomUUID} from 'node:crypto';

const VERSION = '1.0.0';
const CLIENT = 'node-cli';
const MIAODA_RECHARGE_URL = 'https://www.miaoda.cn';

function authHeaders(apiKey) {
  return {
    'Authorization': `Bearer ${apiKey}`,
    'Content-Type': 'application/json',
    'User-Agent': `miaoda-cli/${CLIENT}-${VERSION}`,
    'x-space-id': 'personal'
  };
}

function warnInsufficientCredits(message) {
  if (!message) {
    return;
  }
  const kws = [
    '秒点不足',
    '秒点余额不足',
    'Insufficient Credits',
    'out of credits'
  ];
  if (kws.some(k => message.includes(k))) {
    process.stderr.write(
      `[秒点不足] 您的秒点余额不足，无法继续操作。\n请前往秒哒官网充值：${MIAODA_RECHARGE_URL}\n`
    );
  }
}

async function request(
  url,
  {method = 'GET', body, headers, timeout = 30000} = {}
) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeout);
  try {
    const resp = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal
    });
    if (!resp.ok) {
      const text = await resp.text().catch(() => '');
      throw new Error(
        `HTTP ${resp.status} ${resp.statusText}: ${text.slice(0, 500)}`
      );
    }
    return await resp.json();
  } finally {
    clearTimeout(t);
  }
}

function raiseForApiError(body) {
  if (body.status !== 0) {
    const msg = body.msg || body.message || JSON.stringify(body);
    throw new Error(`API error (status=${body.status}): ${msg}`);
  }
  return body;
}

// --- List Apps ---
const STRIP_KEYS = new Set([
  'avatar',
  'mobileCover',
  'hasAppHost',
  'hasBackend'
]);
const BRIEF_KEEP = new Set([
  'appId',
  'name',
  'type',
  'appFocus',
  'host',
  'updatedAt'
]);

export async function listApps(
  baseUrl,
  apiKey,
  {name = '', page = 1, size = 12, brief = false} = {}
) {
  const url = `${baseUrl.replace(/\/+$/, '')}/api/v1/app/list`;
  const body = await request(url, {
    method: 'POST',
    headers: authHeaders(apiKey),
    body: {
      name,
      page,
      size,
      sort: {direction: 'desc', property: 'updatedAt'}
    }
  });

  const result = raiseForApiError(body);
  const data = result.data || {};
  let items = data.items ?? data.list ?? [];
  if (brief) {
    items = items.map(it =>
      Object.fromEntries(Object.entries(it).filter(([k]) => BRIEF_KEEP.has(k)))
    );
  } else {
    for (const it of items) {
      for (const k of STRIP_KEYS) {
        delete it[k];
      }
    }
  }
  if ('items' in data) {
    data.items = items;
  } else if ('list' in data) {
    data.list = items;
  }
  return result;
}

// --- App Detail ---
export async function getAppDetail(baseUrl, apiKey, appId) {
  const url = `${baseUrl.replace(/\/+$/, '')}/api/v1/app/bootstrap/${appId}`;
  const body = await request(url, {headers: authHeaders(apiKey)});
  const result = raiseForApiError(body);
  const data = result.data || {};
  for (const k of ['hasBackend', 'hasAppHost', 'sandboxUrl']) {
    delete data[k];
  }
  return result;
}

// --- Chat payload ---
function buildChatPayload({
  text,
  contextId = '',
  appId = null,
  queryMode = 'deep_mode',
  inputFieldType = 'web',
  lang = 'zh',
  userConfirmation = null
}) {
  const paramsMetadata = {
    defaultAgent: 'AdaPro',
    agentConfig: {},
    runtime: 'miaoda',
    queryMode
  };
  if (userConfirmation !== null) {
    paramsMetadata.userConfirmation = userConfirmation;
  } else {
    paramsMetadata.inputFieldType = inputFieldType;
  }

  const payload = {
    jsonrpc: '2.0',
    method: 'message/send',
    id: randomUUID(),
    params: {
      message: {
        parts: [{kind: 'text', text}],
        kind: 'message',
        messageId: randomUUID(),
        role: 'user',
        contextId,
        metadata: {},
        taskId: '',
        lang
      },
      metadata: paramsMetadata
    }
  };
  if (appId) {
    payload.params.metadata.appId = appId;
  }
  return payload;
}

function checkChatResponseForError(chatResult) {
  if ('error' in chatResult) {
    const error = chatResult.error || {};
    const errorMsg = error.message || '';
    const data = error.data || {};
    const bceCode = typeof data === 'object' ? data.bce_error_code || '' : '';
    if (bceCode === 'MethodNotAllowed' || errorMsg.includes('秒点')) {
      warnInsufficientCredits(errorMsg || '秒点不足');
    }
    throw new Error(
      `Chat request failed: ${errorMsg || JSON.stringify(error)}`
    );
  }
  const result = chatResult.result || {};
  const state = result.status?.state || '';
  const isFinal = result.final === true;
  if (state === 'failed' || isFinal) {
    const parts = result.status?.message?.parts || [];
    const textParts = parts
      .filter(p => p.kind === 'text')
      .map(p => p.text || '');
    const errorText = textParts.join(' ').trim() || JSON.stringify(chatResult);
    process.stdout.write(JSON.stringify(chatResult) + '\n');
    warnInsufficientCredits(errorText);
    throw new Error(`Chat request failed: ${errorText}`);
  }
}

function extractIdsFromChatResponse(chatResult, fallbackAppId) {
  try {
    const metadata = chatResult.result?.status?.message?.metadata || {};
    return {
      appId: metadata.appId || fallbackAppId || null,
      conversationId: metadata.conversationId || null
    };
  } catch {
    return {appId: fallbackAppId || null, conversationId: null};
  }
}

export async function chatNoStream(
  baseUrl,
  apiKey,
  {
    text,
    contextId = '',
    appId = null,
    queryMode = 'deep_mode',
    inputFieldType = 'web',
    userConfirmation = null
  }
) {
  const url = `${baseUrl.replace(/\/+$/, '')}/api/v1/conversation/chat`;
  const payload = buildChatPayload({
    text,
    contextId,
    appId,
    queryMode,
    inputFieldType,
    userConfirmation
  });
  const resp = await fetch(url, {
    method: 'POST',
    headers: authHeaders(apiKey),
    body: JSON.stringify(payload)
  });
  if (!resp.ok) {
    throw new Error(
      `HTTP ${resp.status}: ${await resp.text().catch(() => '')}`
    );
  }
  const chatResult = await resp.json();
  checkChatResponseForError(chatResult);
  return chatResult;
}

// --- Trajectory ---
function extractEventId(event) {
  return event?.result?.metadata?.eventId ?? null;
}

function isTerminalEvent(event) {
  const r = event?.result || {};
  const state = r.status?.state || '';
  return (
    state === 'completed' ||
    state === 'input-required' ||
    state === 'failed' ||
    r.final === true
  );
}

function extractTextFromEvent(event) {
  const message = event?.result?.status?.message;
  if (!message) {
    return '';
  }
  const parts = message.parts || [];
  return parts
    .filter(p => p.kind === 'text')
    .map(p => p.text || '')
    .join('');
}

function extractPrdActionFromEvents(events) {
  for (const event of events) {
    const artifact = event?.result?.artifact;
    if (!artifact || typeof artifact !== 'object') {
      continue;
    }
    for (const part of artifact.parts || []) {
      const data = part?.data;
      if (data && typeof data === 'object' && data.type === 'prdAgentAction') {
        return data;
      }
    }
  }
  return null;
}

function hasGenerateAppButton(prdAction) {
  for (const action of prdAction.actions || []) {
    if (action?.event?.name === 'generateApp') {
      return true;
    }
  }
  return false;
}

export async function fetchTrajectoryOnce(
  baseUrl,
  apiKey,
  appId,
  lastEventId = -1,
  timeout = 10000
) {
  const url = new URL(
    `${baseUrl.replace(/\/+$/, '')}/api/v1/conversation/trajectory`
  );
  url.searchParams.set('appId', appId);
  url.searchParams.set('lastEventId', String(lastEventId));
  url.searchParams.set('stream', 'false');

  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeout);
  let body;
  try {
    const resp = await fetch(url, {
      headers: authHeaders(apiKey),
      signal: controller.signal
    });
    if (!resp.ok) {
      throw new Error(
        `HTTP ${resp.status}: ${await resp.text().catch(() => '')}`
      );
    }
    body = await resp.json();
  } finally {
    clearTimeout(t);
  }

  let events;
  if (Array.isArray(body)) {
    events = body;
  } else if (body && typeof body === 'object') {
    const data = body.data ?? body;
    if (Array.isArray(data)) {
      events = data;
    } else if (data && typeof data === 'object') {
      events = data.events || [data];
    } else {
      events = [body];
    }
  } else {
    events = [];
  }

  let maxEventId = lastEventId;
  let isTerminal = false;
  for (const event of events) {
    const eid = extractEventId(event);
    if (eid !== null && eid > maxEventId) {
      maxEventId = eid;
    }
    if (isTerminalEvent(event)) {
      isTerminal = true;
    }
  }
  return {events, maxEventId, isTerminal};
}

export async function pollTrajectory(
  baseUrl,
  apiKey,
  appId,
  {lastEventId = -1, pollInterval = 2000, fetchTimeout = 10000, onEvent} = {}
) {
  let textOutput = '';
  let prdAction = null;
  let currentLastId = lastEventId;

  while (true) {
    const {events, maxEventId, isTerminal} = await fetchTrajectoryOnce(
      baseUrl,
      apiKey,
      appId,
      currentLastId,
      fetchTimeout
    );
    for (const event of events) {
      if (onEvent) {
        onEvent(event);
      }
      textOutput += extractTextFromEvent(event);
    }
    const action = extractPrdActionFromEvents(events);
    if (action) {
      prdAction = action;
    }
    currentLastId = maxEventId;
    if (isTerminal) {
      break;
    }
    await new Promise(r => setTimeout(r, pollInterval));
  }
  return {textOutput, prdAction};
}

const INVALID_CONTEXT = new Set(['', 'null', 'undefined', 'none']);

function assertContextIdConsistency(appId, contextId) {
  if (
    appId &&
    INVALID_CONTEXT.has(
      String(contextId ?? '')
        .trim()
        .toLowerCase()
    )
  ) {
    throw new Error(
      `--app-id (${appId}) 已传入但 --context-id 缺失或无效 (got: ${JSON.stringify(contextId)}).\n` +
        '平台将不会修改现有应用，而是创建一个全新应用。\n' +
        '继续/修改现有应用：--app-id <appId> --context-id <conversationId>\n' +
        '从零创建新应用：不要传 --app-id 和 --context-id\n' +
        '恢复丢失的 conversationId：miaoda get-context-id --app-id <appId>'
    );
  }
}

export async function chatStream(
  baseUrl,
  apiKey,
  {
    text,
    contextId = '',
    appId = null,
    queryMode = 'deep_mode',
    inputFieldType = 'web',
    promptGenerate = false,
    pollInterval = 2000,
    fetchTimeout = 10000
  }
) {
  assertContextIdConsistency(appId, contextId);

  const url = `${baseUrl.replace(/\/+$/, '')}/api/v1/conversation/chat`;
  const payload = buildChatPayload({
    text,
    contextId,
    appId,
    queryMode,
    inputFieldType
  });
  const resp = await fetch(url, {
    method: 'POST',
    headers: authHeaders(apiKey),
    body: JSON.stringify(payload)
  });
  if (!resp.ok) {
    throw new Error(
      `HTTP ${resp.status}: ${await resp.text().catch(() => '')}`
    );
  }
  const chatResult = await resp.json();
  checkChatResponseForError(chatResult);

  const {appId: resolvedAppId, conversationId} = extractIdsFromChatResponse(
    chatResult,
    appId
  );
  if (!resolvedAppId) {
    throw new Error(
      '无法从 chat 响应中提取 appId。请检查 context-id / app-id 是否正确，或留空以创建新应用。'
    );
  }
  process.stdout.write(
    JSON.stringify({appId: resolvedAppId, conversationId}) + '\n'
  );

  const {prdAction} = await pollTrajectory(baseUrl, apiKey, resolvedAppId, {
    pollInterval,
    fetchTimeout,
    onEvent: ev => process.stdout.write(JSON.stringify(ev) + '\n')
  });

  let needGenerate = false;
  let requirementType = null;
  if (prdAction) {
    requirementType = prdAction.appInfo?.requirementType ?? null;
    needGenerate = !prdAction.is_generated && hasGenerateAppButton(prdAction);
  }
  process.stdout.write(
    JSON.stringify({
      needGenerateApp: needGenerate,
      requirementType,
      appType: requirementType || 'TASK'
    }) + '\n'
  );

  if (promptGenerate && needGenerate) {
    const {prompt: askUser} = await import('./config.js');
    const answer = (
      await askUser('\n[提示] PRD 已就绪，是否立即生成应用？(y/n): ')
    )
      .trim()
      .toLowerCase();
    if (['y', 'yes', '是'].includes(answer)) {
      process.stdout.write('\n[提交应用]\n');
      await generateAppConfirmation(baseUrl, apiKey, {
        contextId: conversationId || contextId,
        appId: resolvedAppId,
        queryMode,
        watch: true,
        pollInterval,
        fetchTimeout
      });
    }
  }
}

export async function generateAppConfirmation(
  baseUrl,
  apiKey,
  {
    contextId = '',
    appId = null,
    queryMode = 'deep_mode',
    watch = false,
    pollInterval = 2000,
    fetchTimeout = 10000
  } = {}
) {
  assertContextIdConsistency(appId, contextId);

  const url = `${baseUrl.replace(/\/+$/, '')}/api/v1/conversation/chat`;
  const payload = buildChatPayload({
    text: '生成应用',
    contextId,
    appId,
    queryMode,
    userConfirmation: {type: 'generateApp'}
  });
  const resp = await fetch(url, {
    method: 'POST',
    headers: authHeaders(apiKey),
    body: JSON.stringify(payload)
  });
  if (!resp.ok) {
    throw new Error(
      `HTTP ${resp.status}: ${await resp.text().catch(() => '')}`
    );
  }
  const result = await resp.json();
  checkChatResponseForError(result);

  const {appId: resolvedAppId, conversationId} = extractIdsFromChatResponse(
    result,
    appId
  );
  process.stdout.write(
    JSON.stringify({appId: resolvedAppId, conversationId}) + '\n'
  );

  if (watch && resolvedAppId) {
    await pollTrajectory(baseUrl, apiKey, resolvedAppId, {
      pollInterval,
      fetchTimeout,
      onEvent: ev => process.stdout.write(JSON.stringify(ev) + '\n')
    });
  }
  return result;
}

// --- Get context id / conversation history ---
export async function getContextId(
  baseUrl,
  apiKey,
  appId,
  fetchTimeout = 10000
) {
  const {events} = await fetchTrajectoryOnce(
    baseUrl,
    apiKey,
    appId,
    -1,
    fetchTimeout
  );
  let found = null;
  for (const event of events) {
    const r = event.result || {};
    if (r.contextId) {
      found = r.contextId;
      continue;
    }
    const ctx = r.status?.message?.metadata?.conversationId;
    if (ctx) {
      found = ctx;
    }
  }
  return found;
}

export async function getConversationHistory(
  baseUrl,
  apiKey,
  appId,
  {full = false, limit = null, fetchTimeout = 10000} = {}
) {
  const {events} = await fetchTrajectoryOnce(
    baseUrl,
    apiKey,
    appId,
    -1,
    fetchTimeout
  );
  const history = [];
  const maxContent = full ? 100000 : 200;

  for (const event of events) {
    const r = event.result || {};
    const role = r.role || '';
    const eventId = r.metadata?.eventId;
    const state = typeof r.status === 'object' ? r.status?.state || '' : '';

    const parts = r.parts || [];
    const pieces = [];
    let entryType = 'message';

    for (const p of parts) {
      const kind = p.kind || '';
      if (kind === 'text') {
        const t = (p.text || '').trim();
        if (t) {
          pieces.push(t.slice(0, maxContent));
        }
      } else if (kind === 'data') {
        const data = p.data || {};
        const dtype = data.type || '';
        if (dtype === 'filePart') {
          const fname = data.filename || '';
          const ftext = (data.text || '').trim();
          entryType = 'file';
          if (full && ftext) {
            pieces.push(`[file: ${fname}] ${ftext.slice(0, maxContent)}`);
          } else {
            pieces.push(`[file: ${fname}]`);
          }
        } else if (dtype === 'extension') {
          pieces.push(`[style: ${data.extension?.name || ''}]`);
        } else if (dtype === 'userConfirmation') {
          entryType = 'action';
          pieces.push(`[confirm: ${data.type || ''}]`);
        } else if (dtype === 'file_edit_action') {
          entryType = 'action';
          pieces.push(
            `[${data.action_name || data.action || ''}: ${data.path || ''}]`
          );
        } else if (dtype === 'cmd_run_observation') {
          entryType = 'action';
          pieces.push(`[cmd: ${data.observation || ''}]`);
        }
      }
    }

    const content = pieces.join(' ').trim();
    if (role === 'user' || role === 'agent') {
      if (content) {
        history.push({eventId, role, type: entryType, content});
      }
    } else if (state && state !== 'working') {
      history.push({
        eventId,
        role: 'system',
        type: 'status',
        content: `state=${state}`
      });
    }
  }

  if (limit !== null && limit > 0) {
    return history.slice(-limit);
  }
  return history;
}

// --- Publish ---
export async function publishApp(
  baseUrl,
  apiKey,
  appId,
  {
    appEnv = 'PRODUCE',
    enableWeappMiniProgram = true,
    isReleaseAppSquare = false
  } = {}
) {
  const url = `${baseUrl.replace(/\/+$/, '')}/api/v1/app/release`;
  const body = await request(url, {
    method: 'POST',
    headers: authHeaders(apiKey),
    body: {appId, appEnv, enableWeappMiniProgram, isReleaseAppSquare},
    timeout: 120000
  });
  if (body.status !== 0) {
    const msg = body.msg || body.message || '';
    warnInsufficientCredits(msg);
    throw new Error(`Publish failed (status=${body.status}): ${msg}`);
  }
  return body;
}

export async function getPublishStatus(baseUrl, apiKey, releaseId) {
  const url = `${baseUrl.replace(/\/+$/, '')}/api/v1/app/release/status/${releaseId}`;
  return await request(url, {headers: authHeaders(apiKey), timeout: 120000});
}

export async function publishAndWait(
  baseUrl,
  apiKey,
  appId,
  {appEnv = 'PRODUCE', pollInterval = 3000, maxWait = 300000} = {}
) {
  const result = await publishApp(baseUrl, apiKey, appId, {appEnv});
  const releaseId = result.data?.releaseId;
  if (!releaseId) {
    throw new Error('publish 响应中没有 releaseId');
  }

  process.stdout.write(
    JSON.stringify({releaseId, status: 'PROCESSING'}) + '\n'
  );
  const start = Date.now();
  while (true) {
    if (Date.now() - start > maxWait) {
      throw new Error(`Publish 超时 ${maxWait}ms (releaseId=${releaseId})`);
    }
    const statusResult = await getPublishStatus(baseUrl, apiKey, releaseId);
    const status = statusResult.data?.status || 'UNKNOWN';
    process.stdout.write(JSON.stringify({releaseId, status}) + '\n');
    if (status === 'SUCCESS') {
      return statusResult;
    }
    if (status === 'FAILED') {
      throw new Error(`Publish FAILED (releaseId=${releaseId})`);
    }
    await new Promise(r => setTimeout(r, pollInterval));
  }
}
