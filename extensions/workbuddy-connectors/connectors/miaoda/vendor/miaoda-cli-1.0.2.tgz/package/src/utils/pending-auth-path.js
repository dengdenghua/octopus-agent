import path from 'node:path';
import os from 'node:os';

/** 设备授权待授权状态（device_code 等）的存储路径 */
export function getPendingAuthPath() {
  return path.join(os.homedir(), '.miaoda', 'pending-auth');
}
