const GRANT_TYPE_DEVICE_CODE = 'urn:ietf:params:oauth:grant-type:device_code';

/** 发起一次 token 轮询请求。 */
export async function doTokenRequest(cfg, tokenUrl, deviceCode, signal) {
  const form = new URLSearchParams();
  form.set('grant_type', GRANT_TYPE_DEVICE_CODE);
  form.set('device_code', deviceCode);
  form.set('client_id', cfg.clientId);
  const headers = {'Content-Type': 'application/x-www-form-urlencoded'};

  if (cfg.debug) {
    console.log(`[DEBUG] POST ${tokenUrl} body=${form.toString()}`);
  }

  const resp = await fetch(tokenUrl, {
    method: 'POST',
    headers,
    body: form.toString(),
    signal
  });
  const body = await resp.text();
  if (cfg.debug) {
    console.log(`[DEBUG] status=${resp.status} body=${body}`);
  }

  if (resp.status === 200) {
    return {token: JSON.parse(body)};
  }
  try {
    const errResp = JSON.parse(body);
    if (errResp.error) {
      return {tokenError: errResp};
    }
  } catch {
    /* fallthrough */
  }
  throw new Error(`unexpected status=${resp.status} body=${body}`);
}
