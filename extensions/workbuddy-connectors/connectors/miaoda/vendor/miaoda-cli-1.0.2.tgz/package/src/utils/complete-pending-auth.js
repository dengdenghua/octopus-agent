import {pollToken} from './poll-token.js';
import {saveToken} from './save-token.js';
import {loadPendingAuth} from './load-pending-auth.js';
import {clearPendingAuth} from './clear-pending-auth.js';
import {maskToken} from './mask-token.js';

/**
 * 消费 `login` 落盘的待授权状态：向 /oauth2/token 发起单次换取请求并持久化结果。
 *
 * WorkBuddy 规范下 `login` 返回后进程会被 kill，所以换取只能由后续命令（status）单次触发，
 * 不在此处循环等待；用户尚未完成浏览器授权时需再次执行 `miaoda status` 重试。
 *
 * @returns {Promise<{status:'none'|'expired'|'ok'|'pending', reason?:string}>}
 *   none    - 没有待授权记录
 *   expired - 待授权记录已过期，已清理，需要重新 login
 *   ok      - 授权完成，token 已写入 ~/.miaoda/token
 *   pending - 用户尚未完成浏览器授权，pending 记录保留，需再次执行 status 重试
 * @throws 授权被拒绝或 device_code 过期等不可恢复错误时抛出
 */
export async function completePendingAuth({signal, debug = false} = {}) {
  const pending = loadPendingAuth();
  if (!pending) {
    return {status: 'none'};
  }

  const nowMs = Date.now();
  const expiresAtMs = (pending.expires_at || 0) * 1000;
  if (expiresAtMs <= nowMs) {
    clearPendingAuth();
    return {
      status: 'expired',
      reason: '设备授权已过期，请重新执行 `miaoda login`。'
    };
  }

  const cfg = {
    clientId: pending.client_id,
    platformUrl: pending.platform_url,
    debug
  };

  const result = await pollToken(cfg, pending, signal, {
    deadline: expiresAtMs
  });
  if (result.pending) {
    return {status: 'pending', reason: result.reason};
  }
  const tok = result.token;

  const nowSec = Math.floor(Date.now() / 1000);
  const store = {
    access_token: tok.access_token,
    expires_at: nowSec + tok.expires_in,
    platform_url: pending.platform_url,
    client_id: pending.client_id,
    login_host: pending.platform_url
  };
  if (tok.refresh_token) {
    store.refresh_token = tok.refresh_token;
  }
  saveToken(store);
  clearPendingAuth();

  if (debug) {
    console.log(`  token_type    : ${tok.token_type}`);
    console.log(`  expires_in    : ${tok.expires_in}`);
    console.log(`  scope         : ${tok.scope || ''}`);
    console.log(`  access_token  : ${maskToken(tok.access_token)}`);
    if (tok.refresh_token) {
      console.log(`  refresh_token : ${maskToken(tok.refresh_token)}`);
    }
  }

  return {status: 'ok'};
}
