import {resolveTokenSource} from '../utils/resolve-token-source.js';
import {refreshAccessToken} from '../utils/refresh-token.js';
import {getTokenPath} from '../utils/token-path.js';
import {loadPendingAuth} from '../utils/load-pending-auth.js';
import {completePendingAuth} from '../utils/complete-pending-auth.js';

const SOURCE_LABEL = {
  workbuddy: 'WorkBuddy 远程获取',
  codebuddy_env: 'MIAODA_TOKEN_FOR_CODEBUDDY 环境变量',
  env: 'MIAODA_TOKEN 环境变量'
};

/**
 * 若存在 `login` 落盘的待授权记录，则在这里发起一次设备授权换取 token 的尝试。
 *
 * WorkBuddy 规范下 login 进程返回即被 kill，无法在 login 内长时间轮询，
 * 因此换取尝试放在 status 命令中执行，且只执行一次（不循环等待）。
 * 用户尚未完成浏览器授权时，需再次手动执行 `miaoda status` 重试。
 *
 * @returns {Promise<boolean>} true 表示已处理完（无论成功或失败）并已打印结论，调用方应直接返回
 */
async function tryCompletePendingAuth(opts) {
  if (!loadPendingAuth()) {
    return false;
  }

  console.log('检测到待完成的设备授权，正在尝试换取 token...');
  try {
    const result = await completePendingAuth({debug: opts.debug});
    if (result.status === 'expired') {
      console.log(`⚠️  ${result.reason}`);
      return true;
    }
    if (result.status === 'ok') {
      console.log('✅ Logged in。');
      if (opts.debug) {
        console.log(`   Token 已保存到 ${getTokenPath()}`);
      }
      return true;
    }
    // pending：用户尚未完成浏览器授权
    console.log(
      '⚠️  尚未完成授权，请在浏览器完成授权后再次执行 `miaoda status`。'
    );
    return true;
  } catch (err) {
    if (opts.debug) {
      console.log(`换取 token 失败: ${err.message}`);
    }
    console.log(`⚠️  设备授权失败: ${err.message}`);
    return true;
  }
}

/**
 * `miaoda status` — 检查当前登录状态，并在需要时完成设备授权流的轮询。
 * 对齐 cnb-skill status.js 的实现：不因未登录而非零退出，仅打印提示。
 */
export function registerStatusCommand(program) {
  program
    .command('status')
    .description('检查当前登录状态（必要时完成设备授权轮询、自动刷新 token）')
    .option('--debug', '打印调试信息', false)
    .helpOption('-h, --help', '显示帮助文档')
    .action(async opts => {
      // 已有有效 token 时不必再走轮询
      const preResult = await resolveTokenSource();
      const hasValidToken =
        preResult.source !== 'none' &&
        (preResult.source !== 'file' ||
          Math.floor(Date.now() / 1000) < preResult.store.expires_at);

      if (!hasValidToken && (await tryCompletePendingAuth(opts))) {
        return;
      }

      const result = hasValidToken ? preResult : await resolveTokenSource();
      if (result.source === 'none') {
        console.log(
          result.reason
            ? `⚠️  ${result.reason}`
            : '⚠️  未登录，请执行 `miaoda login` 进行授权。'
        );
        return;
      }

      // 环境变量 / WorkBuddy 来源，无过期概念
      if (result.source !== 'file') {
        console.log('✅ Logged in。');
        if (opts.debug) {
          console.log(`   Token 来源: ${SOURCE_LABEL[result.source]}`);
        }
        return;
      }

      // 文件来源 - 检查过期
      const tokenPath = getTokenPath();
      const store = result.store;
      if (opts.debug) {
        console.log(`Token 文件路径 : ${tokenPath}`);
        console.log(`Platform URL  : ${store.platform_url || '未知'}`);
        console.log(`Client ID     : ${store.client_id || '未知'}`);
        console.log(
          `Expires At    : ${new Date(store.expires_at * 1000).toLocaleString()}`
        );
      }

      const nowSec = Math.floor(Date.now() / 1000);
      const isExpired = nowSec >= store.expires_at;
      if (!isExpired) {
        console.log('✅ Logged in。');
        return;
      }

      if (store.refresh_token) {
        if (opts.debug) {
          console.log('Token 已过期，尝试使用 refresh_token 刷新...');
        }

        try {
          await refreshAccessToken(store);
          console.log('✅ Logged in。');
          if (opts.debug) {
            console.log('   （Token 已自动刷新）');
          }
        } catch (err) {
          if (opts.debug) {
            console.log(`刷新失败: ${err.message}`);
          }
          console.log('⚠️  未登录，请执行 `miaoda login` 重新授权。');
        }
      } else {
        console.log('⚠️  未登录，请执行 `miaoda login` 重新授权。');
      }
    });
}
