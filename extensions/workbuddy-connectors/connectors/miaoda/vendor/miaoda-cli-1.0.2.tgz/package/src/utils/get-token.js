import {loadToken} from './load-token.js';

/**
 * 同步获取 token（兼容旧调用，不做过期检查）。
 * @deprecated 请使用 resolveToken()
 */
export function getToken() {
  if (process.env.MIAODA_TOKEN) {
    return process.env.MIAODA_TOKEN;
  }
  const store = loadToken();
  return store?.access_token || '';
}
