import {exec} from 'node:child_process';

/**
 * 尝试使用系统默认浏览器打开指定 URL。
 * macOS 使用 open，Linux 使用 xdg-open，Windows 使用 start。
 * 打开失败时静默忽略，不影响主流程。
 */
export function tryOpenBrowser(url) {
  const cmds = {
    darwin: `open "${url}"`,
    linux: `xdg-open "${url}"`,
    win32: `start "" "${url}"`
  };
  const cmd = cmds[process.platform];
  if (!cmd) {
    return;
  }
  exec(cmd, err => {
    if (err) {
      // 打开失败时静默忽略，用户仍可手动复制链接
    }
  });
}
