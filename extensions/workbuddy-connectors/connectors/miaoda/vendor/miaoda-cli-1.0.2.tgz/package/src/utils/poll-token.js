import {doTokenRequest} from './do-token-request.js';

const ERR_AUTHORIZATION_PENDING = 'authorization_pending';
const ERR_SLOW_DOWN = 'slow_down';
const ERR_ACCESS_DENIED = 'access_denied';
const ERR_EXPIRED_TOKEN = 'expired_token';

/**
 * 根据 RFC 8628 Section 3.4/3.5 向 /oauth2/token 端点发起单次换取请求，不做轮询等待。
 *
 * @param {object} cfg          {platformUrl, clientId, debug}
 * @param {object} dev          设备授权响应或落盘的 pending 记录，需含 device_code
 * @param {AbortSignal} signal
 * @param {object} [options]
 * @param {number} [options.deadline]  绝对截止时间（ms），超过则视为过期
 * @returns {Promise<{token?: object, pending?: boolean, reason?: string}>}
 */
export async function pollToken(cfg, dev, signal, options = {}) {
  const deadline =
    options.deadline ?? Date.now() + (dev.expires_in || 600) * 1000;
  if (Date.now() > deadline) {
    throw new Error('device code 已过期');
  }

  const tokenUrl = `${cfg.platformUrl.replace(/\/+$/, '')}/oauth2/token`;
  const result = await doTokenRequest(cfg, tokenUrl, dev.device_code, signal);
  if (result.token) {
    return {token: result.token};
  }

  if (result.tokenError) {
    const errCode = result.tokenError;
    switch (errCode.error) {
      case ERR_AUTHORIZATION_PENDING:
      case ERR_SLOW_DOWN:
        return {pending: true, reason: errCode.error};
      case ERR_ACCESS_DENIED:
        throw new Error(`用户拒绝了授权: ${errCode.error_description || ''}`);
      case ERR_EXPIRED_TOKEN:
        throw new Error(
          `device_code 已过期: ${errCode.error_description || ''}`
        );
      default:
        throw new Error(
          `token 请求失败: ${errCode.error} - ${errCode.error_description || ''}`
        );
    }
  }

  return {pending: true};
}
