import fs from 'node:fs';
import {getPendingAuthPath} from './pending-auth-path.js';

/**
 * 读取设备授权的待授权状态；不存在或内容损坏时返回 null。
 */
export function loadPendingAuth() {
  const pendingPath = getPendingAuthPath();
  if (!fs.existsSync(pendingPath)) {
    return null;
  }
  try {
    const pending = JSON.parse(fs.readFileSync(pendingPath, 'utf8'));
    if (!pending?.device_code) {
      return null;
    }
    return pending;
  } catch {
    return null;
  }
}
