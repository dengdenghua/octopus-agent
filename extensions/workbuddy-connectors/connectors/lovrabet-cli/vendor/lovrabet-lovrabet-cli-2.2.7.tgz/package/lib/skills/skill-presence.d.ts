/**
 * @fileoverview Global Skill install-state resolution, decoupled from the external `skills` CLI.
 *
 * Only reasonably trustworthy signals are used, and "confirmed missing" is kept
 * distinct from "cannot tell":
 * - artifact probe: `<globalSkillsDir>/<name>/SKILL.md`, what consumers actually resolve
 * - install bookkeeping: the `skills` CLI's own `~/.agents/.skill-lock.json`
 *
 * Directory layout is owned by the external tool, so a stale layout assumption must
 * resolve to `unverifiable` (pass through with a reason) rather than `absent` (fail).
 * Only when both the artifact probe and the bookkeeping agree is the skill `absent`.
 */
/** Install bookkeeping file written by the `skills` CLI, relative to HOME. */
export declare const SKILL_LOCK_RELATIVE_PATH: string;
/** Known global Skill directories, relative to HOME, in probe order. */
export declare const GLOBAL_SKILLS_DIR_RELATIVE_PATHS: string[];
/**
 * Install state of a global Skill.
 *
 * `unverifiable` is deliberate: local assumptions were not sufficient to decide, so
 * callers should pass through instead of failing.
 */
export type SkillPresence = {
    state: "present";
    path: string;
} | {
    state: "absent";
    checked: string[];
} | {
    state: "unverifiable";
    reason: string;
};
export interface ResolveSkillPresenceOptions {
    /** Override candidate global Skill directories (isolated environments or tests). */
    globalSkillsDirs?: string[];
    /** Override the `skills` CLI bookkeeping file path. */
    lockFile?: string;
    /** Override HOME. Tests only. */
    home?: string;
}
/**
 * Resolves whether a global Skill is currently discoverable by consumers.
 *
 * @param skillName - Global Skill name (its directory name), e.g. `lovrabet`.
 * @param options - Probe overrides for isolated environments or tests.
 * @returns `present`, `absent`, or `unverifiable`.
 */
export declare function resolveInstalledSkill(skillName: string, options?: ResolveSkillPresenceOptions): SkillPresence;
