/**
 * @fileoverview Management API client using raw `fetch`.
 *
 * Why a separate module from `sdk-client.ts`: the SDK (`@lovrabet/sdk`) is designed
 * for runtime operations (data/SQL/Backend Function execution) and encapsulates the SDK client
 * lifecycle. This module handles authenticated API calls that the SDK does not
 * cover: listing datasets, fetching app lists, querying runtime contracts, etc.
 *
 * Why `X-User-AK` auth: the runtime CLI uses AccessKey authentication exclusively.
 * The AK is set as a module-level variable (`_activeAK`) and read by every request.
 * The `finalize` hook clears it after each command to prevent AK leakage.
 *
 * Design decision: management API paths use `/client/`; narrowly scoped runtime
 * contract lookups may use `/api/` when the backend exposes a non-enumerating endpoint.
 */
import type { Paging } from "../framework/response.js";
/** Sets the active AccessKey used for all subsequent API calls. */
export declare function setActiveAK(ak: string): void;
/** Clears the active AccessKey after command completion. */
export declare function clearActiveAK(): void;
/** Public runtime contract for one known Backend Function endpoint. */
export interface BffEndpointContract {
    appCode: string;
    functionName: string;
    description?: string;
    version?: number;
    gmtModified?: string | number;
}
/**
 * Fetches one known Backend Function endpoint contract by its stable runtime identity.
 * The runtime exposes an AK-authenticated exact endpoint keyed by appCode + functionName.
 * Platform-only fields returned by older backends are intentionally discarded here.
 */
export declare function getBffEndpointContract(appCode: string, functionName: string): Promise<BffEndpointContract>;
/** Metadata for a SQL query returned by the management API. */
export interface SqlQuery {
    id: number;
    tenantCode?: string;
    appCode: string;
    sqlCode: string;
    sqlName: string;
    dbId?: number;
    sqlContent?: string;
    sqlConfig?: string | null;
    params?: string | null;
}
export interface SqlListResult {
    tableData: SqlQuery[];
    paging: Paging;
}
/**
 * Fetches SQL query metadata by `sqlCode`.
 *
 * Why POST with `sqlCode` filter rather than GET with path param: the API's
 * `/client/sql/query` endpoint accepts POST with a filter body. We match the
 * API's convention even though GET would be more RESTful — changing the API
 * is out of scope for this CLI.
 *
 * The response may be either a `SqlListResult` (paginated list) or a single
 * `SqlQuery` object (when the API returns the matched record directly). We
 * handle both shapes.
 */
export declare function getSqlQueryInfo(appCode: string, sqlCode: string): Promise<SqlQuery>;
/** A dataset returned by the list API. */
export interface DatasetItem {
    id: number;
    name: string;
    code: string;
    source?: string;
    description?: string;
    dbtableConfig?: {
        tableName?: string;
        dbId?: number;
        dbName?: string;
        dbType?: string;
        datasetKey?: string;
        pkField?: string;
        allFields?: string;
    };
    [key: string]: any;
}
export interface RuntimeArtifactItem {
    id: number;
    appCode: string;
    artifactType?: string;
    name?: string;
    content?: string;
    compiledContent?: string;
    metadata?: Record<string, unknown>;
    source?: string;
    favorite?: boolean;
    deleted?: number | boolean;
    createTime?: string;
    updateTime?: string;
    [key: string]: unknown;
}
export interface RuntimeArtifactUpsertInput {
    artifactType: "react_module";
    name?: string;
    content: string;
    metadata?: Record<string, unknown>;
    source: "AGENT";
}
export interface PersonalBffItem {
    id: number;
    appCode?: string;
    functionName?: string;
    description?: string;
    scriptType?: string;
    scriptContent?: string;
    config?: Record<string, unknown> | null;
    version?: number | string;
    createUserId?: number | string;
    gmtCreate?: string;
    gmtModified?: string;
    createTime?: string;
    updateTime?: string;
    [key: string]: unknown;
}
export interface PersonalBffUpsertInput {
    functionName?: string;
    description?: string;
    scriptContent?: string;
    sourceSessionId?: string;
}
export interface DatasetSdkUsageResponse {
    markdown?: string;
    [key: string]: unknown;
}
export interface RuntimeFileUploadResponse {
    fileName?: string | null;
    filePath?: string | null;
    fileUrl?: string | null;
    downloadFlag?: boolean;
    fileType?: string | null;
    size?: number | null;
    sourceDir?: string | null;
    [key: string]: unknown;
}
export interface RuntimeFileUrlResponse {
    fileName?: string | null;
    filePath?: string | null;
    fileUrl?: string | null;
    downloadFlag?: boolean;
    longTerm?: boolean;
    expiresInDays?: number | null;
    [key: string]: unknown;
}
export interface RuntimeOcrResponse {
    requestId?: string;
    type?: string;
    scene?: string;
    text?: string;
    lines?: string[];
    kvData?: Record<string, unknown>;
    width?: number;
    height?: number;
    pageNo?: number | null;
    subImageCount?: number | null;
    algoVersion?: string | null;
    kvExcelUrl?: string | null;
    xmlResult?: string | null;
    rawData?: string | null;
    creditsCharged?: number;
    [key: string]: unknown;
}
/** A personal knowledge-base entry returned by the runtime API. */
export interface PersonalKnowledgeBaseItem {
    id: number;
    appCode: string;
    scope?: string;
    userId?: number | string;
    title: string;
    version?: number;
    content?: string;
    ragStatus?: string;
    ragErrorMessage?: string | null;
    createTime?: string;
    updateTime?: string;
    [key: string]: unknown;
}
/** Request body used for personal knowledge-base create/update. */
export interface PersonalKnowledgeBaseUpsertInput {
    title: string;
    content: string;
}
/** One visible public, company, or personal RAG search hit. */
export interface KnowledgeBaseSearchHit {
    scope: "COMPANY" | "PERSONAL" | string;
    title?: string;
    docId: string;
    score: number;
    weightedScore?: number;
    content: string;
    metadata?: Record<string, unknown>;
    [key: string]: unknown;
}
/** A runtime Skill returned by the management API. */
export interface RuntimeSkillFile {
    path: string;
    sha256: string;
    size: number;
}
export interface RuntimeSkillFilesManifest {
    schemaVersion?: number;
    ossPath?: string;
    treeSha256: string;
    zipSha256: string;
    zipSize: number;
    files: RuntimeSkillFile[];
}
export interface RuntimeSkillItem {
    id?: number;
    skillCode: string;
    skillName?: string;
    description?: string;
    example?: string;
    appCode?: string;
    scope?: "personal" | "company" | "builtin" | string;
    tenantCode?: string;
    userId?: number | string;
    version?: string;
    status?: string;
    tags?: string[];
    readonly?: boolean;
    hasUpstreamUpdate?: boolean;
    forkedFromSkillId?: number;
    forkedFromVersion?: string;
    sourceSessionId?: string;
    content?: string;
    files?: RuntimeSkillFilesManifest;
    [key: string]: unknown;
}
export interface RuntimeSkillListResponse {
    appCode: string;
    personal: RuntimeSkillItem[];
    company: RuntimeSkillItem[];
    effective: RuntimeSkillItem[];
}
/** Request body used for personal runtime Skill create/update. */
export interface RuntimeSkillUpsertInput {
    skillCode?: string;
    skillName?: string;
    description?: string;
    content: string;
    tags?: string[];
    version?: string;
    sourceSessionId?: string;
    files?: RuntimeSkillFilesManifest;
    packageBase64?: string;
    diagram?: RuntimeSkillDiagramSubmission;
}
export interface RuntimeSkillDiagramSubmission {
    schemaVersion: 1;
    mermaid: string;
}
export type RuntimeSkillDiagramScope = "personal" | "company";
export interface RuntimeSkillVersionDiagramWriteInput {
    expectedDiagramRevision: number;
    sourceFingerprint: string;
    diagram: RuntimeSkillDiagramSubmission;
}
export interface RuntimeSkillVersionDiagramWriteResult {
    action: "created" | "updated" | "unchanged";
    wouldWrite: boolean;
    namespace: string;
    skillCode: string;
    skillVersion: string;
    sourceFingerprint: string;
    payloadSha256: string;
    currentDiagramRevision: number;
    diagramRevision: number;
    warnings: string[];
}
export interface RuntimeSkillVersionDiagramResult {
    found: boolean;
    namespace: string;
    skillCode: string;
    skillVersion: string;
    sourceFingerprint: string;
    schemaVersion?: number;
    kind?: string;
    title?: string;
    summary?: string;
    warnings: string[];
    mermaid?: string;
    provenance?: {
        producer: string;
        generatorRevision: string;
    };
    mermaidContentFingerprint?: string;
    payloadSha256?: string;
    diagramRevision: number | null;
    expectedDiagramRevision: number;
    updatedAt?: string;
}
export type RuntimeSkillPublishVisibility = "PRIVATE" | "NAMESPACE_ONLY";
export interface RuntimeSkillPublishOptions {
    visibility: RuntimeSkillPublishVisibility;
    confirmWarnings?: boolean;
}
export interface RuntimeSkillPublishValidationInput {
    visibility: RuntimeSkillPublishVisibility;
}
export interface RuntimeSkillPublishValidationResult {
    valid: boolean;
    errors: string[];
    warnings: string[];
    resolvedSlug?: string;
    resolvedVersion?: string;
    diagramValidated?: boolean;
}
/** An app returned by the remote app list API. */
export interface RemoteAppItem {
    id: number;
    appCode: string;
    appName: string;
    appDesc: string | null;
    tenantCode: string;
    appPublishStatus: string;
    appOwnerName: string;
    createTime: string;
    updateTime: string;
    enableI18n: boolean;
    i18nInfo: {
        baseLang: string | null;
        langs: string[] | null;
        nonDomesticAppName: string | null;
    } | null;
    extend: {
        skinColor: string | null;
        enableOpenApi: boolean;
        accessKey: string | null;
    } | null;
}
/** User info returned by `/client/user/loginUserInfo`. */
export interface LoginUserInfo {
    id?: number | string;
    userId?: number | string;
    username?: string;
    nickname?: string;
    name?: string | null;
    userName?: string;
    nickName?: string;
    loginName?: string;
    tenantCode?: string;
    employeeId?: string | null;
    avatar?: string | null;
    mobile?: string | null;
    email?: string | null;
    [key: string]: unknown;
}
export type RuntimeScheduleKind = "CRON" | "ONCE";
export type RuntimeScheduleModel = "kimi/k3" | "deepseek-v4-flash-0731" | "deepseek-v4-pro-0813";
export type RuntimeScheduleTaskStatus = "QUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED";
export type RuntimeScheduleInput = {
    kind: "CRON";
    timezone: "UTC";
    cron: string;
    title: string;
    prompt: string;
    model: RuntimeScheduleModel;
} | {
    kind: "ONCE";
    timezone: "UTC";
    scheduledAt: string;
    title: string;
    prompt: string;
    model: RuntimeScheduleModel;
};
export interface RuntimeScheduleSummary {
    scheduleId: string;
    kind: RuntimeScheduleKind;
    title: string;
    appCode: string;
    timezone: "UTC";
    createdAt: string;
    cron?: string;
    scheduledAt?: string;
    triggeredTaskId?: string;
    triggeredStatus?: RuntimeScheduleTaskStatus;
}
export interface RuntimeSchedulePage {
    items: RuntimeScheduleSummary[];
    nextCursor?: string;
}
export interface RuntimeScheduleRun {
    taskId: string;
    status: "QUEUED";
}
/** Fetches the current user's app list from the remote API. */
export declare function getMyApps(): Promise<RemoteAppItem[]>;
/**
 * Fetches the current login user info for the active AccessKey.
 *
 * Why this call goes through the raw API client: it is a management-style
 * `/client/*` endpoint keyed solely by `X-User-AK`, not an app-scoped SDK call.
 */
export declare function getLoginUserInfo(): Promise<LoginUserInfo>;
export declare const USER_ACCOUNT_BIND_PATH = "/client/user-accounts/bind";
export declare function bindExternalUserAccount(provider: string, accountId: string): Promise<boolean>;
export declare function validateRuntimeSchedule(appCode: string, input: RuntimeScheduleInput): Promise<RuntimeScheduleInput>;
export declare function createRuntimeSchedule(appCode: string, input: RuntimeScheduleInput): Promise<RuntimeScheduleSummary>;
export declare function listRuntimeSchedules(appCode: string, query: {
    kind: RuntimeScheduleKind;
    limit?: number;
    cursor?: string;
}): Promise<RuntimeSchedulePage>;
export declare function getRuntimeSchedule(appCode: string, scheduleId: string): Promise<RuntimeScheduleSummary>;
export declare function deleteRuntimeSchedule(appCode: string, scheduleId: string): Promise<{
    scheduleId: string;
    deleted: true;
}>;
export declare function runRuntimeSchedule(appCode: string, scheduleId: string): Promise<RuntimeScheduleRun>;
/**
 * Lists datasets for an app, optionally filtered by code or name.
 *
 * Why `listDatasets` uses `extractList`: the API response wraps records in
 * `{ tableData: [...] }`. `extractList` handles this so commands don't need
 * to know the envelope structure.
 */
export declare function listDatasets(appCode: string, options?: {
    code?: string;
    name?: string;
}): Promise<DatasetItem[]>;
/**
 * Fetches complete dataset driven data by code.
 *
 * The server endpoint also accepts `id`, but runtime CLI keeps `code` as the
 * public contract because it is stable across environments and visible to users.
 */
export declare function getDatasetDetail(datasetCode: string): Promise<any>;
export declare function getDatasetSdkUsageDoc(datasetCode: string, appCode: string): Promise<string>;
export declare function uploadRuntimeFile(appCode: string, filePath: string): Promise<RuntimeFileUploadResponse>;
export declare function queryRuntimeFileUrl(filePath: string, options?: {
    download?: boolean;
    longTerm?: boolean;
}): Promise<RuntimeFileUrlResponse>;
export declare function recognizeRuntimeOcr(appCode: string, input: {
    url: string;
    type: string;
}): Promise<RuntimeOcrResponse>;
export declare function getRuntimeAppConfigByKey(appCode: string, key: string): Promise<string>;
export type NotificationChannelType = "EMAIL" | "FEISHU" | "DINGTALK" | "WECOM" | "WEBHOOK";
export interface NotificationChannelConfigItem {
    id?: number | string | null;
    appCode?: string | null;
    configName?: string | null;
    configCode?: string | null;
    channelType?: string | null;
    endpointUrl?: string | null;
    channelConfig?: string | null;
    description?: string | null;
    connectTimeout?: number | null;
    readTimeout?: number | null;
    createTime?: string | null;
    updateTime?: string | null;
    [key: string]: unknown;
}
/** Lists app-level notification configs without using the development Cookie flow. */
export declare function listNotificationChannelConfigs(appCode: string, channelType: NotificationChannelType): Promise<NotificationChannelConfigItem[]>;
export declare function listRuntimeArtifacts(appCode: string, options?: {
    artifactType?: string;
    source?: string;
    favorite?: boolean;
}): Promise<RuntimeArtifactItem[]>;
export declare function getRuntimeArtifact(id: number, appCode: string): Promise<RuntimeArtifactItem>;
export declare function createRuntimeArtifact(appCode: string, input: RuntimeArtifactUpsertInput): Promise<RuntimeArtifactItem>;
export declare function updateRuntimeArtifact(id: number, appCode: string, input: RuntimeArtifactUpsertInput): Promise<RuntimeArtifactItem>;
export declare function listPersonalBffs(appCode: string): Promise<PersonalBffItem[]>;
export declare function getPersonalBff(id: number, appCode: string): Promise<PersonalBffItem>;
export declare function createPersonalBff(appCode: string, input: PersonalBffUpsertInput): Promise<PersonalBffItem>;
export declare function updatePersonalBff(id: number, appCode: string, input: PersonalBffUpsertInput): Promise<PersonalBffItem>;
export declare function executePersonalBff(id: number, appCode: string, params: Record<string, any>): Promise<unknown>;
/** Lists the authenticated user's personal knowledge-base entries for an app. */
export declare function listPersonalKnowledgeBaseItems(appCode: string): Promise<PersonalKnowledgeBaseItem[]>;
/** Fetches one personal knowledge-base entry by numeric ID. */
export declare function getPersonalKnowledgeBaseItem(id: number, appCode: string): Promise<PersonalKnowledgeBaseItem>;
/** Creates a personal knowledge-base entry from a title/content payload. */
export declare function createPersonalKnowledgeBaseItem(appCode: string, input: PersonalKnowledgeBaseUpsertInput): Promise<PersonalKnowledgeBaseItem>;
/** Updates a personal knowledge-base entry. The backend requires POST. */
export declare function updatePersonalKnowledgeBaseItem(id: number, appCode: string, input: PersonalKnowledgeBaseUpsertInput): Promise<PersonalKnowledgeBaseItem>;
/** Searches visible company and personal knowledge for the active user/app. */
export declare function searchKnowledgeBase(appCode: string, input: {
    query: string;
    topK?: number;
}): Promise<KnowledgeBaseSearchHit[]>;
export type RuntimeSkillRemoteScope = "all" | "personal" | "company";
/** Fetches one SkillHub native Skill by exact namespace and slug. */
export declare function getRuntimeSkillByCode(appCode: string, skillCode: string): Promise<RuntimeSkillItem | undefined>;
/** Lists SkillHub native Skills with Lovrabet AK auth. */
export declare function listRuntimeSkills(input: {
    appCode: string;
    scope?: RuntimeSkillRemoteScope;
    code?: string;
}): Promise<RuntimeSkillListResponse>;
/** Lists the authenticated user's personal Skills for an app. */
export declare function listPersonalRuntimeSkills(appCode: string): Promise<RuntimeSkillItem[]>;
/** Lists company Skills visible in the app namespace. */
export declare function listCompanyRuntimeSkills(appCode: string): Promise<RuntimeSkillItem[]>;
/** Lists effective business runtime Skills visible to the authenticated user. */
export declare function listVisibleRuntimeSkills(appCode: string): Promise<RuntimeSkillItem[]>;
/** Publishes a private runtime Skill through SkillHub. */
export declare function createPersonalRuntimeSkill(appCode: string, input: RuntimeSkillUpsertInput, options?: {
    confirmWarnings?: boolean;
}): Promise<RuntimeSkillItem>;
/** Updates a personal runtime Skill by republishing it through SkillHub. */
export declare function updatePersonalRuntimeSkill(skillCode: string, appCode: string, input: RuntimeSkillUpsertInput, options?: {
    confirmWarnings?: boolean;
}): Promise<RuntimeSkillItem>;
/** Publishes a company runtime Skill version through SkillHub review flow. */
export declare function publishCompanyRuntimeSkill(appCode: string, input: RuntimeSkillUpsertInput, options?: {
    confirmWarnings?: boolean;
}): Promise<RuntimeSkillItem>;
/** Validates a runtime Skill publish package through SkillHub without creating a version. */
export declare function validateRuntimeSkillPublish(appCode: string, input: RuntimeSkillUpsertInput, validation: RuntimeSkillPublishValidationInput): Promise<RuntimeSkillPublishValidationResult>;
/** Validates a replacement diagram for one exact Skill version without writing it. */
export declare function validateRuntimeSkillVersionDiagram(appCode: string, skillCode: string, version: string, scope: RuntimeSkillDiagramScope, input: RuntimeSkillVersionDiagramWriteInput): Promise<RuntimeSkillVersionDiagramWriteResult>;
/** Creates or replaces the diagram for one exact Skill version. */
export declare function putRuntimeSkillVersionDiagram(appCode: string, skillCode: string, version: string, scope: RuntimeSkillDiagramScope, input: RuntimeSkillVersionDiagramWriteInput): Promise<RuntimeSkillVersionDiagramWriteResult>;
/** Reads the current diagram for one exact Skill version, including an explicit found flag. */
export declare function getRuntimeSkillVersionDiagram(appCode: string, skillCode: string, version: string, scope: RuntimeSkillDiagramScope): Promise<RuntimeSkillVersionDiagramResult>;
/** Downloads a runtime Skill package through SkillHub. */
export declare function downloadRuntimeSkillPackage(scope: "personal" | "company" | "builtin", skillCode: string, appCode: string, version?: string): Promise<Buffer>;
export type RuntimeAppRoleType = "ADMIN" | "USER" | "OWNER" | "CUSTOM";
export interface RuntimeAppRole {
    id: number;
    appCode: string;
    roleName: string;
    roleType: RuntimeAppRoleType;
    permits?: Record<string, string[]>;
    remark?: string;
    extend?: string;
    userCount: number;
    permitCount: number;
    gmtCreate?: string;
    gmtModified?: string;
}
export interface RuntimeRoleUserRef {
    userId: number;
    username?: string;
    nickname?: string;
    status?: string;
}
export interface RuntimeRoleUsers {
    id: number;
    roleName: string;
    roleType: RuntimeAppRoleType;
    userList: RuntimeRoleUserRef[];
    applyUserList?: RuntimeRoleUserRef[];
}
export interface RuntimeAppRoleListOptions {
    roleName?: string;
    currentPage?: number;
    pageSize?: number;
}
export declare function listRuntimeAppRoles(appCode: string, options?: RuntimeAppRoleListOptions): Promise<{
    items: RuntimeAppRole[];
    paging?: Paging;
}>;
export declare function createRuntimeAppRole(input: {
    appCode: string;
    roleName: string;
    remark?: string;
}): Promise<RuntimeAppRole>;
export declare function updateRuntimeAppRole(input: {
    id: number;
    appCode: string;
    roleName?: string;
    remark?: string;
}): Promise<RuntimeAppRole>;
export declare function deleteRuntimeAppRole(id: number): Promise<boolean>;
export declare function listRuntimeRoleUsers(appCode: string): Promise<RuntimeRoleUsers[]>;
export declare function updateRuntimeRoleUsers(appCode: string, roleList: RuntimeRoleUsers[]): Promise<boolean>;
export interface RuntimeAppUser {
    code: string | number;
    userName: string;
    nickName?: string;
    displayName?: string;
    status?: string;
}
export declare function listRuntimeAppUsers(appCode: string): Promise<RuntimeAppUser[]>;
export interface RuntimePermitRole {
    id: number;
    roleType: RuntimeAppRoleType | "ALL" | "SELF" | "PUBLIC";
    roleName: string;
    allowed?: boolean;
}
export interface RuntimeResourcePermit {
    id?: number;
    appCode?: string;
    menuId?: number | null;
    pageId?: number | null;
    resourceCode: string;
    resourceType: string;
    resourceName?: string;
    rolePermit: RuntimePermitRole[] | null;
    dataPermit?: RuntimePermitRole[] | null;
    fieldPermit?: string;
    extend?: string;
}
export interface RuntimePagePermit {
    menuId: number;
    pageId?: number;
    appCode: string;
    datasetCode?: string;
    menuPermit: RuntimeResourcePermit;
    dataCreate?: RuntimeResourcePermit;
    dataUpdate?: RuntimeResourcePermit;
    dataDelete?: RuntimeResourcePermit;
    dataDetail?: RuntimeResourcePermit;
    dataExport?: RuntimeResourcePermit;
    dataPermit?: RuntimeResourcePermit;
}
export interface RuntimeEvaluatedResource {
    resourceType: string;
    resourceCode: string;
    resourceName?: string;
    allowed?: boolean;
    allowedActions?: string[];
    appCode?: string;
    menuType?: string;
    pageId?: number | null;
    pageNodeList?: RuntimeEvaluatedResource[] | null;
}
export interface RuntimeMenuRolePermitNode {
    id: number;
    parentId?: number;
    label: string;
    type?: string;
    path?: string;
    pageId?: number | null;
    permitId?: number | null;
    rolePermit: RuntimePermitRole[] | null;
    children?: RuntimeMenuRolePermitNode[];
}
export interface RuntimeDatasetPermit {
    appCode?: string;
    datasetCode: string;
    datasetName?: string;
    dataPermitList: RuntimeEvaluatedResource[];
}
export interface RuntimeDatasetActionRolePermit {
    permitId?: number | null;
    resourceType: string;
    resourceCode: string;
    resourceName?: string;
    rolePermit: RuntimePermitRole[] | null;
}
export interface RuntimeDatasetRolePermit {
    appCode?: string;
    datasetCode: string;
    datasetName?: string;
    dataPermitList: RuntimeDatasetActionRolePermit[];
}
export declare function listRuntimePermitRoles(appCode: string, options?: {
    needSelf?: boolean;
    needPublic?: boolean;
}): Promise<RuntimePermitRole[]>;
export declare function getRuntimePagePermit(menuId: number): Promise<RuntimePagePermit>;
export declare function saveRuntimePagePermit(input: RuntimePagePermit): Promise<RuntimePagePermit>;
export declare function getRuntimeRoleMenuResources(appCode: string, roleId: number): Promise<RuntimeEvaluatedResource[]>;
export declare function listRuntimeMenuRolePermits(appCode: string): Promise<RuntimeMenuRolePermitNode[]>;
export declare function saveRuntimeMenuRolePermits(appCode: string, permitList: RuntimeResourcePermit[]): Promise<boolean>;
export declare function listRuntimeDatasetPermits(appCode: string, roleId: number): Promise<RuntimeDatasetPermit[]>;
export declare function listRuntimeDatasetRolePermits(appCode: string): Promise<RuntimeDatasetRolePermit[]>;
export declare function saveRuntimeDatasetRolePermits(appCode: string, permitList: RuntimeResourcePermit[]): Promise<boolean>;
