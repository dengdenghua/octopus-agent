import type { RuntimeContext } from "../../framework/types.js";
import type { RuntimeSkillContentScope } from "./push-flow-helpers.js";
import type { SkillValidationIssue } from "./validate.js";
/** Previews a Skill push without creating a remote version. */
export declare function skillPushDryRun(ctx: RuntimeContext): Promise<{
    method: string;
    url: string;
    body: {
        skillCode: string;
        visibility: string;
        valid: boolean;
        errors: string[];
        warnings: string[];
        resolvedSlug: string | undefined;
        resolvedVersion: string | undefined;
        diagramValidated: boolean | undefined;
    };
    description: string;
}>;
/** Executes a personal Skill push or a company review submission. */
export declare function skillPushExecute(ctx: RuntimeContext): Promise<{
    ok: boolean;
    data: {
        alreadyPublished: boolean;
        contentIdentical: boolean;
        diagramSubmitted: boolean;
        warnings?: SkillValidationIssue[] | undefined;
        scope: RuntimeSkillContentScope;
    };
    message: string;
} | {
    ok: boolean;
    data: {
        scope: string;
        reviewState: string;
        submittedForReview: boolean;
        diagramBound: boolean;
        validation: {
            warnings: string[];
        };
    };
    message: string;
} | {
    ok: boolean;
    data: {
        warnings: SkillValidationIssue[];
        validation: {
            warnings: string[];
        };
        diagramBound: boolean;
    };
    message: string;
}>;
