import { lstatSync } from "node:fs";
/** Resolves a managed Skill file path and rejects traversal or symlink writes. */
export declare function resolveManagedFilePath(dir: string, relativePath: string): string;
/** Walks a managed relative path and refuses to write through any symlink. */
export declare function ensureNoSymlinkInManagedPath(root: string, relativePath: string): void;
/** Detects a symlink path even when its target no longer exists. */
export declare function isDanglingSymlink(path: string): boolean;
/** Resolves a symlink target relative to the symlink parent when needed. */
export declare function resolveSymlinkTarget(linkPath: string): string;
/** Checks whether a child path is equal to or nested inside a parent path. */
export declare function isPathInside(child: string, parent: string): boolean;
/** Returns a real path when it exists, otherwise the absolute resolved path. */
export declare function realOrResolved(path: string): string;
/** Reads lstat metadata and returns undefined when the path is absent. */
export declare function lstatIfPresent(path: string): ReturnType<typeof lstatSync> | undefined;
/** Writes UTF-8 content through the same atomic byte-write path. */
export declare function writeTextAtomic(path: string, content: string, mode: number): void;
/** Writes bytes to a temp file and renames it into place atomically. */
export declare function writeBytesAtomic(path: string, content: Buffer, mode: number): void;
/** Writes formatted JSON metadata with owner-readable permissions. */
export declare function writeJsonAtomic(path: string, value: unknown): void;
