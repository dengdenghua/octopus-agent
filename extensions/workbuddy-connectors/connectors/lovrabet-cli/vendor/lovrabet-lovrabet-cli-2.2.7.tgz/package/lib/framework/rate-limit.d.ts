import { type CliError } from "../errors.js";
export interface RateLimitInput {
    status?: unknown;
    errorCode?: unknown;
    message?: unknown;
    retryAfter?: unknown;
}
export declare function createRateLimitError(input: RateLimitInput): CliError | undefined;
export declare function readRetryAfter(headers: unknown): string | undefined;
export declare function readRetryAfterSeconds(body: unknown): string | undefined;
