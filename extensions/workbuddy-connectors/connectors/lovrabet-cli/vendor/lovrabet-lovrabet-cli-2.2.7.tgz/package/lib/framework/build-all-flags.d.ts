/**
 * @fileoverview Builds the effective flag list for a command with runtime defaults.
 *
 * Delegates to the framework's `buildAllFlagsBase`, injecting `DEFAULT_COMMAND_OUTPUT_FORMAT`
 * ("compress") as the default `--format` value. This is the only runtime-specific
 * customization needed — the framework handles the rest.
 *
 * Why not re-implement here: the built-in flag injection logic (dry-run, format, yes)
 * is framework-owned. We only configure the format default so the framework uses
 * compress instead of json for commands that don't declare their own default.
 */
import type { CommandDefinition, FlagDef } from "../framework/types.js";
/**
 * Builds the complete flag list for a command definition.
 *
 * Injects:
 * - `--dry-run` (if `def.dryRun` is defined)
 * - `--format` (unless `def.hasFormat === false`) with default `"compress"`
 * - `--yes` (if `def.risk === "high-risk-write"`)
 *
 * @param def - The command definition.
 * @returns Complete flag array (command flags + framework-injected flags).
 */
export declare function buildAllFlags(def: CommandDefinition): FlagDef[];
