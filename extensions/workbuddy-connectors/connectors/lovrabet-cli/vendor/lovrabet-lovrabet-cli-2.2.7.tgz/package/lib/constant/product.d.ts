/**
 * @fileoverview Product and distribution constants for downstream forks.
 *
 * This is the first file to edit when rebranding or self-hosting Lovrabet
 * Runtime CLI. Other constant modules re-export or derive from these values so
 * command code does not need to know where product identity is defined.
 *
 * Package metadata still lives in `package.json`; keep `name` and `bin` aligned
 * with `npmPackageName` and `cliBinName` when publishing a branded fork.
 */
/** Product-level customization surface for branded or self-hosted builds. */
export declare const PRODUCT_CONFIG: {
    /** Executable binary name in package.json `bin`. */
    readonly cliBinName: "lovrabet";
    /** Human-readable CLI name shown in help, schema, and diagnostics. */
    readonly cliDisplayName: "Lovrabet Runtime CLI";
    /** Published npm package used by `update`. */
    readonly npmPackageName: "@lovrabet/lovrabet-cli";
    /** Published CLI Built-in Skill source consumed by `npx skills add`. */
    readonly skillSource: "lovrabet/lovrabet-cli";
    /**
     * Internal CodeUp Git source that installs the same global Skill as `skillSource`.
     *
     * Used to recognize internal installs when verifying install state; it is not an
     * install target for published flows.
     */
    readonly internalSkillSource: "git@codeup.aliyun.com:yuntoo/open/lovrabet-runtime-cli.git";
    /**
     * Global Skill directory name produced by installing `skillSource`.
     *
     * Not derivable from `skillSource` (`lovrabet/lovrabet-cli` installs `lovrabet`),
     * so it is declared explicitly instead of inferred from the repo slug.
     */
    readonly globalSkillName: "lovrabet";
    /** Npm registry base URL used for update dist-tag resolution. */
    readonly npmRegistryBaseUrl: "https://registry.npmjs.org";
    /** Main environment variable prefix, without trailing underscore. */
    readonly envPrefix: "LOVRABET";
    /** Compatibility environment prefixes checked after `envPrefix`. */
    readonly legacyEnvPrefixes: readonly ["RABETBASE"];
    /** Config file names, in lookup order. */
    readonly configFileNames: readonly [".lovrabet.json", ".lovrabetrc"];
    /** Config file name used for new writes. */
    readonly newConfigFileName: ".lovrabet.json";
    /** Per-user home directory name used for caches. */
    readonly homeDirName: ".lovrabet";
    /** Project log file name. */
    readonly logFileName: ".lovrabet-runtime.log";
    /** Request source header value for backend telemetry/rate limiting. */
    readonly invokeSource: "cli:lovrabet-runtime";
    /** Human-readable AccessKey management product name. */
    readonly userCenterDisplayName: "Lovrabet User Center";
    /** Env var suffix for skipping `npx skills add`. */
    readonly skipNpxSkillsEnvSuffix: "SKIP_NPX_SKILLS";
    /** Default service domains. Config file overrides still take precedence. */
    readonly domains: {
        readonly production: {
            readonly user: "https://user.lovrabet.com";
            readonly api: "https://api.lovrabet.com";
            readonly runtime: "https://runtime.lovrabet.com";
            readonly skillhub: "https://skills.lovrabet.com";
        };
        readonly nonProduction: {
            readonly user: "https://user-daily.lovrabet.com";
            readonly api: "https://daily-api.lovrabet.com";
            readonly runtime: "https://daily-runtime.lovrabet.com";
            readonly skillhub: "https://skills-daily.lovrabet.com";
        };
    };
    /** User center path for creating an AccessKey. */
    readonly accessKeyCreatePath: "/user/ak";
};
/**
 * Returns the environment variable name for this product.
 *
 * @param name - Suffix without prefix, for example `ACCESS_KEY`.
 * @returns Full environment variable name, for example `LOVRABET_ACCESS_KEY`.
 */
export declare function productEnvName(name: string): string;
/**
 * Returns all supported environment variable names for a suffix.
 *
 * @param name - Suffix without prefix, for example `ACCESS_KEY`.
 * @returns Primary env var name followed by compatibility aliases.
 */
export declare function productEnvNames(name: string): string[];
/**
 * Reads a product-scoped environment variable with legacy fallback.
 *
 * @param name - Suffix without prefix, for example `ACCESS_KEY`.
 * @returns First matching environment variable value.
 */
export declare function productEnv(name: string): string | undefined;
