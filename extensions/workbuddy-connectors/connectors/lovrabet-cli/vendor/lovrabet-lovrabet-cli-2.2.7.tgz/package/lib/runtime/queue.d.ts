/**
 * 串行执行会访问进程级 CLI 认证和 SDK client 状态的阶段，避免并发调用间串用。
 * 调用方的人工确认可能无限期等待，必须在进入本队列前完成。
 *
 * 本文件只提供这一个队列函数，因此本函数注释同时说明了文件职责。
 */
export declare function runSerialized<T>(task: () => Promise<T>): Promise<T>;
