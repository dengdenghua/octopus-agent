/**
 * 本文件负责把 CLI 命令定义和执行结果转换为稳定的 Lovrabet 写入成功事件。
 * 事件只保留前端展示所需的最小字段，避免把命令参数或敏感业务数据写入 metadata。
 */
import type { CommandDefinition, CommandResult } from "../framework/types.js";
import type { LovrabetStructuredMetadata } from "../runtime/types.js";
/**
 * 将命令的 service 与多段 command 规范化为稳定的点分 operation。
 */
export declare function canonicalLovrabetOperation(definition: Pick<CommandDefinition, "service" | "command">): string;
/**
 * 仅为成功执行的 write 或 high-risk-write 命令生成 v1 结构化事件。
 *
 * read、dry-run 和失败结果均不产生完成事件；专属 subject 由命令定义按白名单提取。
 */
export declare function createLovrabetWriteMetadata(definition: CommandDefinition, operation: string, result: CommandResult, dryRun: boolean): LovrabetStructuredMetadata | undefined;
