/**
 * @fileoverview Database resolver for SQL detail display.
 *
 * Why a separate module: `sql detail` shows the database name alongside the SQL
 * metadata, but the database name is only available from the dataset list API
 * (which includes `dbtableConfig.dbName`). Rather than importing `listDatasets`
 * into `sql/exec.ts`, we centralize the dbName resolution here so both
 * `sql detail` and any future command that needs dbName can use it.
 *
 * Design decision: `getDbName` silently returns `undefined` on error.
 * Why: the AK that gives access to SQL queries may not have permission to
 * list datasets. In that case, `sql detail` should still show the dbId
 * number rather than crashing. The caller (`sql detail`) handles the
 * `undefined` case by falling back to showing the raw dbId.
 *
 * The cache is keyed by `appCode` because different apps have different
 * datasets and thus different database names.
 */
/** A resolved database entry from the dataset list. */
export interface DbEntry {
    dbId: number;
    dbName: string;
}
/**
 * Lists all databases accessible to an app (from dataset metadata).
 * Results are cached per app to avoid repeated API calls.
 */
export declare function listDatabases(appCode: string): Promise<DbEntry[]>;
/**
 * Resolves a database ID to its display name.
 *
 * @returns The dbName if found; `undefined` if not found (e.g. permission denied).
 *
 * Why return undefined instead of throwing: callers (like `sql detail`) should
 * degrade gracefully and show the dbId number when the name can't be resolved.
 * This matches the principle that permission errors on auxiliary data should
 * not block the primary operation.
 */
export declare function getDbName(appCode: string, dbId: number): Promise<string | undefined>;
