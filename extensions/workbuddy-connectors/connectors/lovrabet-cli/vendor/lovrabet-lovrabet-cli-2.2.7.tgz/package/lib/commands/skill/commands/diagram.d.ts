import type { CommandDefinition } from "../../../framework/types.js";
export declare const diagramValidateCommand: CommandDefinition;
export declare const diagramPushCommand: CommandDefinition;
export declare const diagramShowCommand: CommandDefinition;
