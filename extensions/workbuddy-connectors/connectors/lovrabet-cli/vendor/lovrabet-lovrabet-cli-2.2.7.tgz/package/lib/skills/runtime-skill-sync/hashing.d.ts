import type { LocalSkillFile, RuntimeSkillFile } from "./types.js";
/** Computes the stable content hash used by metadata and change detection. */
export declare function contentHash(content: string): string;
/** Hashes a local Skill file entry regardless of whether it is text or bytes. */
export declare function fileHash(file: LocalSkillFile): string;
/** Computes a SHA-256 digest for raw package or file bytes. */
export declare function bufferSha256(buffer: Buffer): string;
/** Builds the deterministic tree hash for a normalized Skill manifest. */
export declare function fileTreeHash(files: RuntimeSkillFile[]): string;
