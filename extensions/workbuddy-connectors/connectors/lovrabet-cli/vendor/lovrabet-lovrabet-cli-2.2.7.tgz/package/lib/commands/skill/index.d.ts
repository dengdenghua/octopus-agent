/**
 * @fileoverview Runtime business Skill command definitions.
 *
 * `skill install` is the consumer-facing business Skill installer. CLI runtime
 * built-in Skill setup lives under `cli-skill install`.
 */
import type { CommandDefinition } from "../../framework/types.js";
/** Declarative definitions for the `skill` service. */
export declare const skillDefinitions: CommandDefinition[];
