/**
 * 本文件集中复用 CLI framework 类型，并补充 Lovrabet Runtime 所需的上下文和写入事件扩展。
 *
 * Why re-export from `@lovrabet/cli-framework` here: the framework types are
 * the canonical definitions. This file brings them into the `lovrabet-runtime-cli`
 * namespace and augments them with the extra properties (`accessKey`, `envName`,
 * `selectedAppName`) that the runtime-specific adapter injects into `RuntimeContext`.
 *
 * Design decision: `RuntimeContextExtras` intentionally does NOT include `cookie`.
 * The runtime CLI uses AccessKey auth only (no session cookies), so `cookie` is
 * always an empty string. Excluding it from extras forces callers to be explicit
 * rather than accidentally relying on a value that will never be set.
 */
export type { ArgDef, FlagDef, CommandResult, DryRunResult, OutputFormat, OutputEnvelope, Risk, } from "@lovrabet/cli-framework";
import type { CommandDefinition as CoreCommandDefinition, CommandResult, CommandResult as CoreCommandResult, RuntimeContext as CoreRuntimeContext } from "@lovrabet/cli-framework";
export { 
/** @see @lovrabet/cli-framework */
riskLevelOrder, 
/** @see @lovrabet/cli-framework */
normalizeLegacyOutputFormat, 
/** @see @lovrabet/cli-framework */
isValidFormat, } from "@lovrabet/cli-framework";
/**
 * A snapshot of the resolved multi-app config at the point the runner's
 * `prepare` hook runs. Stored in the context so commands can inspect which
 * app is active and which apps are defined without re-reading the config.
 *
 * Why this exists: `ctx.config.apps` in `CLIConfig` is the fully typed
 * `Record<string, AppProfile>`, but callers sometimes need to check the raw
 * shape (`Record<string, { appcode?: string }>`) before the profile has been
 * fully validated. `MergedCliSnapshot` serves this "lightly typed config view".
 */
export interface MergedCliSnapshot {
    defaultApp?: string;
    currentApp?: string;
    appCode?: string;
}
/**
 * Extra properties injected into `RuntimeContext` by the runtime runner adapter.
 * These are resolved in `prepare()` and made available to every command without
 * requiring each command to look them up independently.
 *
 * Why `apiDir` is always `""`: apiDir is a研发态 (rabetbase-cli) concept for
 * the Backend Function API directory path. The runtime CLI talks directly to the runtime engine
 * and does not route through a Backend Function, so this field is always empty.
 *
 * Why `accessKey` is optional: some commands may not require auth and can run
 * without it. Making it optional avoids null-checks everywhere.
 */
export interface RuntimeContextExtras {
    /** Resolved app code (from --appcode, env var, or active app profile). */
    appCode: string;
    /**
     * Always empty string in runtime CLI. Present for interface compatibility
     * with rabetbase-cli, which uses session cookies.
     */
    cookie: string;
    /** Resolved runtime API domain (production or daily). */
    apiDomain: string;
    /**
     * Always empty string in runtime CLI. Present for interface compatibility
     * with rabetbase-cli, which uses Backend Function API directories.
     */
    apiDir: string;
    /**
     * AccessKey used for authentication. Optional because not all commands
     * require it (e.g. `init` and `help`).
     */
    accessKey?: string;
    /** The normalized environment name. */
    envName?: "production" | "development" | "daily";
    /** Name of the currently selected app profile (if any). */
    selectedAppName?: string;
    /** Lightly-typed snapshot of the merged config for quick inspection. */
    mergedCli?: MergedCliSnapshot;
}
/**
 * The concrete runtime context type for all Lovrabet Runtime CLI commands.
 * Every command's `validate`, `dryRun`, and `execute` functions receive this type.
 */
export type RuntimeContext = CoreRuntimeContext<RuntimeContextExtras>;
export interface RuntimeUpdateNotice {
    command: string;
    current: string;
    latest: string;
    url: string;
    message: string;
}
export interface RuntimeNotice {
    update?: RuntimeUpdateNotice;
}
export type CommandResultWithNotice<T = any> = CoreCommandResult<T> & {
    _notice?: RuntimeNotice;
};
/**
 * 描述专属写入成功展示允许携带的最小业务主体。
 */
export interface LovrabetWriteSubject {
    kind: string;
    id: string;
    action: string;
}
export type CommandDefinition = CoreCommandDefinition<RuntimeContext> & {
    /**
     * 写入命令面向产品用户的授权说明；缺失时嵌入式运行时兼容回退到命令 description。
     */
    confirmationDescription?: string;
    /**
     * 从命令结果中提取专属写入成功展示所需的最小安全身份；通用事件无需 subject。
     */
    writeEventSubject?: (result: CommandResult) => LovrabetWriteSubject | undefined;
};
