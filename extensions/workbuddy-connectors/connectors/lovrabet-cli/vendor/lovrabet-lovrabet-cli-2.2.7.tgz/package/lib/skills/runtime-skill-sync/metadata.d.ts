import type { LocalSkillFile, RuntimeSkillItem, RuntimeSkillMetadata, RuntimeSkillScope } from "./types.js";
/** Builds the local metadata record used to detect edits and list installed Skills. */
export declare function buildMetadata(skill: RuntimeSkillItem, scope: RuntimeSkillScope, appCode: string, hash: string, pulledAt?: string, files?: LocalSkillFile[], packageBytes?: Buffer): RuntimeSkillMetadata;
/** Requires a non-empty backend skillCode before filesystem operations. */
export declare function requireSkillCode(skill: RuntimeSkillItem): string;
/** Reads local runtime Skill metadata, returning undefined when it is absent. */
export declare function readMetadataIfPresent(path: string): RuntimeSkillMetadata | undefined;
