/**
 * @fileoverview Help text generators backed by the framework's help engine.
 *
 * Why this module: the framework's `createHelpGenerators` needs resolver functions
 * (`getServiceEntry`, `getServiceDefinitions`, `buildAllFlags`) and CLI metadata
 * (`cliBinName`, `cliDisplayName`, `globalFlags`). Rather than calling the factory
 * in `cli.tsx` and passing these dependencies around, we wire everything up once
 * here and export the ready-to-use generators. Callers (registry commands, schema)
 * import from this module without needing to know the wiring details.
 *
 * Design decision: `appPrerequisiteText` is set here as a constant rather than
 * being derived from config. This keeps help text stable regardless of the user's
 * current configuration and avoids edge cases (e.g. no app selected).
 */
import type { CommandDefinition } from "../framework/types.js";
/** Generates help for a single command. */
export declare function generateCommandHelp(def: CommandDefinition): string;
/** Generates help for all commands within a service. */
export declare function generateServiceHelp(service: string): string;
/** Generates the top-level `--help` output. */
export declare function generateFullHelp(): string;
