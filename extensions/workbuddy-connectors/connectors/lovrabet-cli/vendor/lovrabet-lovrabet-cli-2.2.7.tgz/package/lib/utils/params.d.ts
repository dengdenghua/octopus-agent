/**
 * @fileoverview `--params` JSON parsing utilities.
 *
 * Why a dedicated module: `--params` is accepted by several execute commands
 * (data create/update/delete/batchCreate, sql exec, bff exec) as a way to pass
 * request bodies. Each command previously had its own `JSON.parse` + try/catch
 * logic, producing inconsistent error messages. Centralizing here means:
 * - Consistent error messages: all `--params` errors say "Invalid JSON for --params"
 * - Single place to add JSON validation or parameter transformation
 * - Easier to test parsing logic in isolation
 *
 * Design decision: `parseJsonParams` returns `Record<string, any>` (an object),
 * while `parseJsonParamsValue` returns `unknown` (any JSON). The former is used
 * for commands whose params must be an object (filter, update); the latter is for
 * commands that accept arbitrary JSON (batchCreate with array body).
 */
export declare const MAX_DATA_UPDATE_IDS = 1000;
export type DataUpdateId = number | string;
/**
 * Parses `--params` as a JSON object.
 *
 * Why `Record<string, any>` return type: all commands using this function have
 * API bodies that are objects (key-value pairs). Returning a plain object
 * prevents callers from accidentally treating the params as an array.
 *
 * @param paramsStr - Raw `--params` flag value.
 * @returns Parsed object, or `undefined` if the string is empty/undefined.
 * @throws CliError with code `"validation_error"` if the string is not valid JSON.
 */
export declare function parseJsonParams(paramsStr: string | undefined): Record<string, any> | undefined;
/**
 * Parses `--params` as arbitrary JSON (object or array).
 *
 * Why `unknown` return type: `data batchCreate` accepts a JSON array as the
 * request body (not an object). Using `unknown` allows callers to check the
 * shape and handle both cases.
 *
 * @throws CliError with code `"validation_error"` if the string is not valid JSON.
 */
export declare function parseJsonParamsValue(paramsStr: string | undefined): unknown;
/**
 * Normalizes `--params` for batchCreate operations.
 *
 * The Lovrabet batchCreate API accepts either:
 * - A JSON array directly: `[{"name":"a"},{"name":"b"}]`
 * - An object wrapper: `{"items":[{"name":"a"},{"name":"b"}]}`
 *
 * Why normalize the wrapper form: this is a common pattern in Lovrabet Studio's
 * API surface where the wrapper indicates the array's semantic role. Supporting
 * both forms makes the CLI match the Studio UX.
 *
 * @param params - Already-parsed `--params` value (from `parseJsonParamsValue`).
 * @returns The normalized array of record objects.
 * @throws CliError with code `"validation_error"` if the shape is neither form.
 */
export declare function parseBatchCreateItemsFromParams(params: unknown): Record<string, any>[];
/**
 * Validates and normalizes `id` for data update operations.
 *
 * `model.update` already accepts a scalar id or an id array. This helper gives
 * command code a stable id list for validation, dry-run, and batch result
 * metadata.
 */
export declare function parseUpdateIdsFromParams(params: unknown): DataUpdateId[];
export declare function normalizeUpdateParamsForRuntime(params: Record<string, any>, ids: DataUpdateId[]): Record<string, any>;
