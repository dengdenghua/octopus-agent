/**
 * @fileoverview `doctor` command — CLI self-diagnostic tool.
 *
 * Why `hasFormat: false`: the doctor command directly uses `console.log` to
 * emit a human-readable diagnostic report with chalk coloring. It does not
 * use the framework's format pipeline because the output is inherently
 * human-oriented (ASCII art, colored sections). Returning `data` through
 * the pipeline would produce a JSON report with color codes stripped.
 *
 * Design decision: all config layers are checked (global + project) and
 * reported separately. This helps users identify which layer a problem
 * originates from (e.g. a missing project file vs an invalid global file).
 *
 * Why `inspectCliConfigJsonFile` is used for JSON validation: the doctor
 * should surface JSON parse errors from config files, not just say "file not found".
 * This helps users debug corrupt config files quickly.
 *
 * Auth section: shows `ClientAk` mode explicitly and notes that session
 * cookie auth is removed. This is intentional — the runtime CLI only supports
 * AccessKey auth, not the web-session flow.
 */
import type { CommandDefinition } from "../framework/types.js";
export declare const doctorDefinition: CommandDefinition;
