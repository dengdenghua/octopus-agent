/**
 * 本文件是 Lovrabet CLI 的嵌入式运行时入口。
 * 它串联 argv 解析、原生确认、命令执行、结果展示、成功事件生成和全局状态清理。
 */
import type { InvokeLovrabetOptions, InvokeLovrabetResult } from "../runtime/types.js";
export type { InvokeLovrabetOptions, InvokeLovrabetResult, LovrabetConfirmationAdapter, LovrabetConfirmationRequest, LovrabetPresentationAdapter, LovrabetPresentationRequest, LovrabetStructuredMetadata, LovrabetWriteCompletedEvent, } from "../runtime/types.js";
/**
 * 通过与终端 CLI 相同的 registry 和 runner 执行一组 Lovrabet argv。
 *
 * write 命令在副作用发生前调用确认适配器；成功后返回可供 OpenCode 持久化的 metadata。
 * 人工确认不占用进程级执行队列，只有依赖共享认证和 SDK 状态的执行阶段才会串行。
 */
export declare function invokeLovrabet(argv: readonly string[], options: InvokeLovrabetOptions): Promise<InvokeLovrabetResult>;
