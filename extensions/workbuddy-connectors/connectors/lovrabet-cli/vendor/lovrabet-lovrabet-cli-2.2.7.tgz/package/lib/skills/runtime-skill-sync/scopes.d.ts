import type { RuntimeSkillScope } from "./types.js";
/** Normalizes requested scopes, applying the local-list default order. */
export declare function normalizeRuntimeSkillScopes(scopes: RuntimeSkillScope[] | undefined): RuntimeSkillScope[];
/** Checks whether an arbitrary metadata scope is one supported runtime scope. */
export declare function isRuntimeSkillScope(value: unknown): value is RuntimeSkillScope;
