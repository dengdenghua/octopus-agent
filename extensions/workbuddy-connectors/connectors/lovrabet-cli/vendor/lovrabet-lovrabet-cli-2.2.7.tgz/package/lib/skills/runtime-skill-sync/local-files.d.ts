import type { LocalSkillFile, RuntimeSkillFile } from "./types.js";
export interface ScanSkillDirectoryOptions {
    excludedFilePaths?: readonly string[];
}
/** Converts a local file entry into bytes for hashing, packaging, or writes. */
export declare function fileContent(file: LocalSkillFile): Buffer;
/** Decodes a local file entry as UTF-8 text for SKILL.md and metadata logic. */
export declare function fileText(file: LocalSkillFile): string;
/** Normalizes package file entries and preserves deterministic ordering. */
export declare function normalizeLocalFiles(files: LocalSkillFile[] | undefined): LocalSkillFile[];
/** Normalizes remote manifest entries and validates hash and size metadata. */
export declare function normalizeManifestFiles(files: RuntimeSkillFile[] | undefined): RuntimeSkillFile[];
/** Scans a Skill directory into normalized package entries while skipping local-only files. */
export declare function scanSkillDirectory(dir: string, options?: ScanSkillDirectoryOptions): LocalSkillFile[];
/** Sorts SKILL.md first and then keeps the remaining file paths deterministic. */
export declare function compareSkillFiles(a: {
    path: string;
}, b: {
    path: string;
}): number;
/** Normalizes a package path to POSIX form after trimming and safety checks. */
export declare function normalizeSkillRelativePath(path: string): string;
/** Rejects absolute paths, empty path segments, and parent traversal. */
export declare function validateSkillRelativePath(path: string): void;
/** Converts Windows path separators to POSIX separators for package metadata. */
export declare function toPosixPath(path: string): string;
/** Checks whether a value is a lowercase or uppercase SHA-256 hex digest. */
export declare function isSha256Hex(value: unknown): value is string;
