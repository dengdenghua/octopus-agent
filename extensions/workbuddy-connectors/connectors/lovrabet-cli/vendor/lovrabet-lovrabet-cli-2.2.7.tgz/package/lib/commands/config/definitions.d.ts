/**
 * @fileoverview `config` subcommand definitions — list, get, set, delete.
 *
 * Why `hasFormat: false` for most commands: `config get` and `config set`
 * output directly via `console.log` (for script-friendly single-value output),
 * while `config list` with `--format pretty` returns a markdown message.
 * Only `config list --format json` uses the structured `data` path.
 * Keeping this split avoids double-output in scripts.
 *
 * Why `riskLevel` is not settable via `config set`: setting `riskLevel`
 * would allow automated privilege escalation (scripts could raise their own
 * risk level without user consent). Users who need to change it must edit
 * the config file directly.
 *
 * Scope policy: all writes use `policy: "project-or-global-explicit"`.
 * Without `--global`, writing goes to the project if inside a project,
 * otherwise refuses with a helpful error. This prevents accidental global
 * writes from inside a project directory.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const configDefinitions: CommandDefinition[];
