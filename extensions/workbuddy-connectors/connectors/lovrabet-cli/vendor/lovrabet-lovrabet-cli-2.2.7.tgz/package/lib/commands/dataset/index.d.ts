/**
 * @fileoverview `dataset` command group — exports the declarative definition list.
 *
 * Why this module exists: mirrors the `bff/` and `sql/` patterns. The runtime
 * CLI provides `dataset list` (discover) and `dataset detail` (inspect),
 * but not create/update/delete (those are Studio-only operations in the
 * runtime context).
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const datasetDefinitions: CommandDefinition[];
