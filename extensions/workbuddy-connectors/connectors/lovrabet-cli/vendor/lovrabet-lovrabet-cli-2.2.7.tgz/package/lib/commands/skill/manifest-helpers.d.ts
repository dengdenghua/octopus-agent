import type { RuntimeSkillFilesManifest, RuntimeSkillItem } from "../../core/api-client.js";
/** Checks whether a backend files payload points to a stored Skill package. */
export declare function isPackageBackedManifest(files: RuntimeSkillItem["files"]): files is RuntimeSkillFilesManifest;
/** Checks whether a files manifest contains entries beyond the root SKILL.md. */
export declare function isMultiFileManifest(files: RuntimeSkillItem["files"]): files is RuntimeSkillFilesManifest;
