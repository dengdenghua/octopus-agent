/**
 * @fileoverview `bff` command group — exports the declarative definition list.
 *
 * Why this module exists: the framework registry (`registry.ts`) imports
 * `bffDefinitions` directly. The actual command definitions are split into
 * `exec.ts` (run) and `detail.ts` (inspect) to keep each file focused.
 * This index re-exports them as a single array for registration.
 *
 * Why only exec + detail (no list/save): Lovrabet Runtime CLI targets
 * the runtime environment where scripts are managed in the Studio UI.
 * The CLI provides execution and inspection, not script lifecycle management.
 * List/save belong to the development CLI (`rabetbase`).
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const bffDefinitions: CommandDefinition[];
