/**
 * @fileoverview `dataset list` command — discovers datasets by name or code.
 *
 * Why `--name` and `--code` are both optional: users often search by name
 * when they don't remember the exact code. The API handles both cases server-side,
 * so the CLI just passes the filters through without client-side pre-filtering.
 *
 * Why `CODE_FLAG` is reused (with `required: false`) for the `--code` filter:
 * the same 32-char hex pattern applies to dataset codes. Adding a separate
 * `CODECODE_FLAG` would duplicate the pattern. The `required: false` override
 * is correct because this is an optional filter, not a mandatory lookup key.
 *
 * Why `db.allFields.split(",").map(...)` for the fields array: the API returns
 * `allFields` as a comma-separated string, not a JSON array. We split it here
 * so callers always get a consistent array type regardless of API shape.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const datasetList: CommandDefinition;
