/**
 * @fileoverview Maps SDK errors to user-facing CLI errors.
 *
 * Why this mapping layer exists: the `@lovrabet/sdk` throws `LovrabetError` instances
 * whose `message` field contains internal technical details (stack traces, internal
 * codes) unsuitable for end users. The SDK also surfaces a `description` field that
 * contains the human-readable message set by the API team.
 *
 * This function extracts `description` (when available and non-empty) and uses it
 * as the user-facing message, falling back to `message` only when `description`
 * is absent. Rate-limit failures are mapped to the retryable `rate_limited` contract;
 * other SDK failures retain the existing validation mapping.
 *
 * Design decision: non-LovrabetError errors pass through unchanged. This preserves
 * stack traces and error types for unexpected errors, which is better for debugging
 * than wrapping everything in a generic CLI error.
 */
/**
 * Maps any error thrown during command execution to a user-facing CLI error.
 *
 * - Rate-limited `LovrabetError` → retryable `rate_limited` `CliError`
 * - Other `LovrabetError` → validation `CliError` with `description` as the message
 * - Everything else → passed through unchanged (preserves stack trace)
 *
 * @param error - Any error from the execute hook.
 * @returns A `CliError` (for Lovrabet errors) or the original error.
 */
export declare function mapUserFacingExecuteError(error: unknown): unknown;
