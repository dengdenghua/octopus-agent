/**
 * @fileoverview API / user / runtime domain resolution.
 *
 * Why domain resolution is centralized here: the CLI makes HTTP requests to multiple
 * backend services, each with its own domain. Rather than hard-coding URLs or
 * duplicating the env-based selection logic, we expose three getter functions that
 * encapsulate the rule:
 *
 *   - production env → production domains
 *   - daily (staging) env → daily-prefixed domains
 *   - development env → daily-prefixed domains (development uses the same staging backend)
 *
 * Design decision: domains are stored as module-level mutable variables so they can be
 * overridden from the config file (via `initDomains()`). This lets users point the CLI
 * at a custom backend without changing environment variables. The overrides are applied
 * once at startup and used throughout the process.
 */
/**
 * Sets custom domain overrides read from the config file.
 *
 * Why pass an options object instead of three separate parameters: future-proofing.
 * Adding a new domain type (e.g. `authDomain`) only requires adding a field here,
 * not changing every call site. Typed `undefined` fields mean "use the default".
 *
 * @param domains - Partial domain overrides. Unset fields fall through to defaults.
 */
export declare function initDomains(domains?: {
    apiDomain?: string;
    userDomain?: string;
    runtimeDomain?: string;
    skillHubDomain?: string;
}): void;
/**
 * Returns the user-facing domain (used for OAuth, user profile, etc.).
 *
 * Why daily and development both use `user-daily`: there is only one non-production
 * user backend. "Daily" is Lovrabet's staging/integration environment name.
 */
export declare const getUserDomain: () => string;
/**
 * Returns the primary API domain for management operations (datasets, SQL, Backend Function).
 *
 * Why the domain changes based on env: production and staging (daily) have
 * separate infrastructure. Development uses the same staging API — there is no
 * separate dev API in this system.
 */
export declare const getApiDomain: () => string;
/**
 * Returns the runtime engine domain (used by the SDK to execute data operations).
 *
 * Why separate from `getApiDomain`: the runtime engine is a distinct microservice
 * with its own domain. Both management and runtime calls go through the same AK,
 * but they hit different hosts.
 */
export declare const getRuntimeDomain: () => string;
/** Returns the SkillHub domain used by native Skill management APIs. */
export declare const getSkillHubDomain: () => string;
