/**
 * @fileoverview Output format enumeration.
 *
 * These values must stay in sync with the `--format` flag enum in `cli.tsx`
 * and the `OutputFormat` type imported from the framework.
 * This module acts as the canonical declaration — callers should import from
 * here rather than repeating the literal array.
 */
/**
 * Valid values for the `--format` CLI flag and `format` config field.
 * These are re-exported from the framework type `OutputFormat` in `framework/types.ts`.
 */
export declare const OUTPUT_FORMAT_VALUES: readonly ["json", "pretty", "compress"];
