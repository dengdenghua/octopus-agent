export interface SkillValidationIssue {
    level: "error" | "warning";
    ruleId: string;
    file: string;
    section?: string;
    message: string;
    suggestion: string;
}
export interface SkillValidationReport {
    ok: boolean;
    dir: string;
    type?: string;
    errors: SkillValidationIssue[];
    warnings: SkillValidationIssue[];
}
export declare function validateSkillDirectory(dir: string, _options?: {
    strict?: boolean;
    profile?: "push";
}): SkillValidationReport;
export declare function throwIfSkillValidationFailed(report: SkillValidationReport, _strict?: boolean): void;
