/**
 * @fileoverview High-risk operation confirmation prompts.
 *
 * Why this module exists: the framework runner's `confirmHighRisk` hook calls
 * `requireConfirmationPrompt` with lines provided by the adapter. This module
 * generates the confirmation text from the command definition and flags, so the
 * text is consistent across all high-risk commands without each command implementing
 * its own prompt.
 *
 * Design decision: `reconstructCommandArgv` generates a complete command invocation
 * string ending with `--yes`. This is shown to users in non-interactive mode as
 * the exact command they need to run to bypass the confirmation. Without this,
 * users would have to figure out the correct flags themselves.
 */
import type { CommandDefinition } from "../framework/types.js";
import type { ParsedFlags } from "@lovrabet/cli-framework";
/**
 * Builds the lines displayed to the user before a high-risk operation.
 *
 * The first line is always a warning with the command label. Subsequent lines
 * (description, affected records) are included only when available.
 *
 * Why include affected records: for delete/update operations, knowing the specific
 * record(s) being targeted reduces the chance of a catastrophic mistake.
 *
 * @param def           - Command definition (provides description).
 * @param commandLabel  - Full command label, e.g. `"dataset delete"`.
 * @param flags         - Parsed flags (used to extract affected record IDs).
 * @returns Lines to display via `requireConfirmationPrompt`.
 */
export declare function buildConfirmationLines(def: CommandDefinition, commandLabel: string, flags: ParsedFlags): string[];
/**
 * Reconstructs a CLI invocation string from a command definition and parsed flags.
 *
 * Why this is useful: when a high-risk command is blocked in non-interactive mode,
 * the error message includes the exact command to re-run with `--yes`. Generating
 * this automatically is less error-prone than asking users to construct it by hand.
 *
 * The reconstructed command always ends with `--yes` so users can copy-paste it
 * directly to proceed.
 *
 * @param def    - Command definition.
 * @param flags  - Parsed flags to include.
 * @returns Reconstructed CLI invocation, e.g. `lovrabet dataset delete --code abc123 --yes`.
 */
export declare function reconstructCommandArgv(def: CommandDefinition, flags: ParsedFlags): string;
