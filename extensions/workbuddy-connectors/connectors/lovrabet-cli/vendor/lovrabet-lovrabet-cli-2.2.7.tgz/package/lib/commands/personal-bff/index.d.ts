/**
 * @fileoverview `personal-bff` command group — user-owned endpoint scripts.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const personalBffDefinitions: CommandDefinition[];
