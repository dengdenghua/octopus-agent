/**
 * Platform-specific executable helpers for cross-platform CLI execution.
 *
 * On Windows, npm-installed CLIs such as `npm` and `npx` are exposed as `.cmd`
 * wrapper scripts. `spawnSync()` without `shell: true` cannot resolve those
 * wrappers unless the extension is explicit. On Unix-like systems, the plain
 * command name is sufficient.
 */
/** Whether the current runtime is Windows. */
export declare const isWindows: boolean;
/**
 * Resolves the executable name for npm ecosystem tools on the current platform.
 *
 * @param cmd - The base executable name, for example `"npx"` or `"npm"`.
 * @returns The executable name that should be passed to `spawnSync()`.
 */
export declare function resolveNpmBin(cmd: string): string;
