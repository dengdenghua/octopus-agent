/**
 * 本文件定义当前应用下 react_module Artifact 的查询、创建和更新命令。
 * 写入命令从本地文件读取源码，使生成内容可在 sandbox 中审阅，并避免通过命令参数泄露长文本。
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const ALLOWED_REACT_MODULE_IMPORTS_TEXT: string;
/** 校验源码是非空、可嵌入且只使用允许依赖的 React 模块。 */
export declare function validateReactModuleSource(content: string): void;
export declare const artifactDefinitions: CommandDefinition[];
