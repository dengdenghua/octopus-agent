/**
 * @fileoverview Schema payload builder for the `--schema` introspection flag.
 *
 * Why a separate async function: `buildSchemaPayloadBase` from the framework
 * is synchronous, but the Lovrabet CLI registry uses dynamic imports for
 * command modules to keep startup time fast. We wrap the base function here
 * and handle the dynamic import inside `buildSchemaPayload()`, so callers
 * don't need to know about the import strategy.
 *
 * Schema output is used by:
 * - Language servers / IDE integrations that enumerate available commands.
 * - Documentation generators that auto-generate command reference pages.
 * - Scaffolding tools that generate command stubs.
 *
 * Design decision: `gitCommit` is read from generated build metadata so local
 * and published builds expose the same commit source as `lovrabet --version`.
 */
import { type SerializedFlagPattern, type SerializedFlag, type SchemaCommandEntry, type SchemaServiceEntry, type SchemaPayload } from "@lovrabet/cli-framework";
export type { SerializedFlagPattern, SerializedFlag, SchemaCommandEntry, SchemaServiceEntry, SchemaPayload, };
/**
 * Builds the complete schema payload describing all registered commands.
 *
 * Why async: the registry uses `await import()` for command modules to enable
 * code splitting. The synchronous caller (`schema.ts` command) handles this
 * by awaiting here rather than at every call site.
 *
 * @returns A schema payload suitable for JSON serialization and introspection.
 */
export declare function buildSchemaPayload(): Promise<SchemaPayload>;
