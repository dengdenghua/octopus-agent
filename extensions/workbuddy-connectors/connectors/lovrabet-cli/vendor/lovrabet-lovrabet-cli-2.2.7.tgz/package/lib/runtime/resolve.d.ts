/**
 * 本文件负责将原生工具传入的 CLI argv 解析为真实命令定义、参数和规范化 flags。
 * 静态命令与动态 Service Tree 命令都复用终端 CLI 的 registry 和 flag 修正规则。
 */
import type { CommandDefinition } from "../framework/types.js";
export interface ResolvedLovrabetInvocation {
    definition: CommandDefinition;
    rawFlags: Record<string, any>;
    args: string[];
}
/**
 * 解析一次嵌入式 Lovrabet 调用，并返回 runner 可直接消费的命令定义、flags 和位置参数。
 */
export declare function resolveLovrabetInvocation(argv: readonly string[]): Promise<ResolvedLovrabetInvocation>;
