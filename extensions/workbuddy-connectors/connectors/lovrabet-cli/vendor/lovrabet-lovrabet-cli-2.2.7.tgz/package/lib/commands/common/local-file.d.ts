export declare const RUNTIME_UPLOAD_MAX_BYTES: number;
export interface RuntimeUploadFile {
    path: string;
    size: number;
}
export declare function requireRuntimeUploadFile(filePath: string, label: string): RuntimeUploadFile;
