/**
 * Official `skills` CLI integration used by `lovrabet cli-skill install`.
 *
 * The runtime CLI currently only needs the `npx -y skills@latest add <source> -g -y`
 * flow, so this module intentionally keeps the surface area narrow.
 */
import { type ResolveSkillPresenceOptions } from "../skills/skill-presence.js";
/** Source repository consumed by the public `skills` ecosystem. */
export declare const LOVRABET_SKILL_SOURCE: "lovrabet/lovrabet-cli";
/** Internal CodeUp Git source that installs the same global Skill. */
export declare const LOVRABET_SKILL_GIT_SOURCE: "git@codeup.aliyun.com:yuntoo/open/lovrabet-runtime-cli.git";
/** Global Skill directory name produced by installing {@link LOVRABET_SKILL_SOURCE}. */
export declare const LOVRABET_GLOBAL_SKILL_NAME: "lovrabet";
/**
 * Resolves the global Skill name installed by a given source.
 *
 * Known sources (published shorthand and internal CodeUp Git remote) map to the same
 * Skill name. Unknown sources return `undefined`, which skips install-state
 * verification rather than guessing an artifact name.
 *
 * The lookup lives inside the function body (not a top-level const) so obfuscator
 * statement reordering cannot trigger a TDZ error.
 *
 * @param source - Install source passed to `npx skills add`.
 * @returns The global Skill name for known sources, otherwise `undefined`.
 */
export declare function resolveGlobalSkillName(source: string): string | undefined;
/** Skip flag used by tests or offline automation. */
export declare const LOVRABET_SKIP_NPX_SKILLS_ENV: string;
/**
 * Result of invoking the external `skills` installer.
 */
export interface RunNpxSkillsAddResult {
    ok: boolean;
    status: number | null;
    code?: NpxSkillsErrorCode;
    error?: string;
    /** `true` when execution was intentionally skipped via env var. */
    skipped?: boolean;
}
/**
 * Runtime options for the external `skills` installer.
 */
export interface RunNpxSkillsAddOptions {
    /** Child stdio mode. `inherit` for local use, `pipe` for tests/CI. */
    stdio?: "inherit" | "pipe";
    /** Override how global Skill install state is probed (isolated environments or tests). */
    presence?: ResolveSkillPresenceOptions;
    /** Expected installed Skill name for package-local paths that have no source mapping. */
    expectedSkillName?: string;
}
/**
 * Failure classification.
 *
 * Prefers stable OS/Node signals and locally resolvable install state. The only
 * output-derived classification is the installer's `Failed to install N` summary;
 * all other installer text is attached to `error` as diagnostics.
 */
export type NpxSkillsErrorCode = "NPX_NOT_FOUND" | "PERMISSION_DENIED" | "SPAWN_FAILED" | "CHILD_TERMINATED" | "CHILD_EXIT_NONZERO" | "INSTALL_PARTIAL" | "SKILL_NOT_INSTALLED";
/**
 * Returns whether the external `skills` invocation should be skipped.
 *
 * @returns `true` when the product-scoped skip env var is set to `1`.
 */
export declare function shouldSkipNpxSkillsAdd(): boolean;
/**
 * Installs the published CLI Built-in Skill globally through the official `skills` CLI.
 *
 * @param projectRoot - Working directory for the spawned process.
 * @param source - Published skill source.
 * @param options - Execution options.
 * @returns Spawn outcome and optional error summary.
 */
export declare function runNpxSkillsAddGlobal(projectRoot: string, source?: string, options?: RunNpxSkillsAddOptions): RunNpxSkillsAddResult;
