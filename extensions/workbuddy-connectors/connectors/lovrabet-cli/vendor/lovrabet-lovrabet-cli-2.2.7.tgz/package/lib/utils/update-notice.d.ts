export interface UpdateNotice {
    command: string;
    current: string;
    latest: string;
    url: string;
    message: string;
}
export declare function getUpdateNoticeCachePath(): string;
export declare function buildNpmVersionUrl(version: string): string;
export declare function resolveLatestUpdateNotice(): Promise<UpdateNotice | null>;
