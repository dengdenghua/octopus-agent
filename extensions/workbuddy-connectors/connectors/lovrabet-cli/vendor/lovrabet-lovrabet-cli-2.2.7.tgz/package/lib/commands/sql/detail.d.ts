/**
 * @fileoverview `sql detail` command — inspects a custom SQL query by sqlCode.
 *
 * Why `SQLCODE_FLAG` (not `CODE_FLAG`): SQL query codes use the format
 * `xxxxxxxx-xxxxxxxx` (with a hyphen), distinct from dataset 32-char hex codes.
 * `SQLCODE_FLAG` provides the correct regex pattern.
 *
 * Why `getDbName()` is called even when `dbId` is absent: `sql.dbId` may be
 * null for queries that don't target a specific database. We only call
 * `getDbName()` when `dbId` is present to avoid unnecessary API calls.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const sqlDetail: CommandDefinition;
