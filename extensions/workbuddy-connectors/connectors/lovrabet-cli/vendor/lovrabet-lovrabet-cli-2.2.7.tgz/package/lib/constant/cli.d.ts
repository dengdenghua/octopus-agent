/**
 * @fileoverview CLI identity constants and global flag registry.
 *
 * Why a single source of truth for all CLI metadata:
 * - `CLI_BIN_NAME` / `CLI_DISPLAY_NAME` are used in error messages, help text, and
 *   log output — changing the binary name only requires editing this file.
 * - `GLOBAL_FLAGS` feeds both the meow parser config AND the help generator's
 *   GLOBAL OPTIONS block. Previously these were maintained separately and drifted
 *   out of sync (e.g. a flag added to meow but missing from --help).
 *
 * Design decision: pipeline-pass-through flags (id, name, sqlcode, params, etc.)
 * are declared as meow global flags so the parser accepts them on any command,
 * but marked `hidden: true` so they don't clutter the GLOBAL OPTIONS listing.
 * This lets commands like `data getOne --id 123` work without every command
 * definition re-declaring the flag.
 */
export declare const CLI_BIN_NAME: "lovrabet";
export declare const CLI_DISPLAY_NAME: "Lovrabet Runtime CLI";
export declare const NPM_PACKAGE_NAME: "@lovrabet/lovrabet-cli";
/**
 * Descriptor for every top-level CLI flag.
 *
 * `meowKey` is the camelCase key used by meow after it normalizes the flag name.
 * Why camelCase: meow converts `--dry-run` to `dryRun` automatically, so we must
 * match that transformation when reading from `flags`.
 *
 * `hidden` flags are still parsed by meow but excluded from the GLOBAL OPTIONS
 * block — this is intentional so they can be passed through as pipeline flags
 * without polluting the user-facing help.
 */
export interface GlobalFlagDef {
    /** kebab-case name as written in CLI usage (e.g. `"appcode"` for `--appcode`). */
    name: string;
    /**
     * camelCase key in the meow-parsed flags object.
     * meow lowercases and strips dashes, so `--dry-run` becomes `dryRun`.
     */
    meowKey: string;
    /** Value type — booleans need no value, strings and numbers do. */
    type: "string" | "boolean";
    /** Shown in help listings under GLOBAL OPTIONS. */
    description: string;
    /**
     * Short hint appended to the flag name in help (e.g. `"json | pretty | compress"`).
     * Helps users see valid values at a glance without reading full descriptions.
     */
    hint?: string;
    /**
     * When `true`, the flag is excluded from the GLOBAL OPTIONS help block.
     * Why use this: pipeline flags (id, name, params) must be globally recognized
     * by meow so they work on any subcommand, but should not appear as general
     * "options" in the top-level help to avoid confusing users.
     */
    hidden?: boolean;
}
/**
 * All global flags accepted by the CLI.
 *
 * Why split into "visible" and "hidden/pass-through" groups:
 * - Visible flags (first ~11) are genuine top-level options users interact with.
 * - Hidden flags (last ~6) are pipeline passthrough — accepted everywhere but
 *   not advertised, keeping the global help clean.
 *
 * This design replaces the older pattern of each command re-declaring shared
 * flags, which caused stale descriptions and inconsistent types.
 */
export declare const GLOBAL_FLAGS: GlobalFlagDef[];
/**
 * The subset of `GLOBAL_FLAGS` names that represent true top-level pipeline flags.
 * Only these are included in the framework runner's `pipelineFlags` array.
 *
 * Why not just use all non-hidden flags: `--ci` is an alias for `--non-interactive`
 * and should behave identically, but we only need one entry in the pipeline.
 * Similarly, `--app` is a profile selector (not a passthrough key).
 */
export declare const PIPELINE_FLAG_NAMES: Set<string>;
/**
 * Builds the flags configuration object passed to meow.
 *
 * Why this function exists: meow requires a `{ type: "string" | "boolean" }`
 * descriptor per flag. We derive it from `GLOBAL_FLAGS` so the two stay in sync.
 * Previously this mapping was maintained by hand and occasionally drifted.
 */
export declare function buildMeowFlags(): Record<string, {
    type: "string" | "boolean";
}>;
