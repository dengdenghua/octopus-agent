/**
 * 本文件提供无损 JSON 解析，并在 SDK 调用期间临时替换 Response.json。
 * 它会在首次解析前把超出 JavaScript 安全整数范围的整数字面量转成字符串，
 * 同时保留安全整数、小数、布尔值、null 与字符串的原有语义。
 */
/** 解析 JSON，同时把非安全整数保留为十进制字符串。 */
export declare function parseLosslessJson<T = unknown>(text: string): T;
/**
 * 在 @lovrabet/sdk 使用的 Response 边界安装无损解析器。
 * SDK 暂未暴露 parser hook，因此调用方需要在首个响应解析前安装，并在命令结束后恢复。
 */
export declare function installLosslessJsonResponseParser(): () => void;
/** 若无损 Response.json 解析器已安装，则立即恢复原实现。 */
export declare function restoreLosslessJsonResponseParser(): void;
