/**
 * @fileoverview `lovrabet update` self-update command.
 *
 * The runtime CLI intentionally checks npm dist-tags directly and does not use
 * a CDN policy file. The npm package owns its Built-in Skill installation;
 * this command repairs the current package or verifies a newly installed one.
 */
import type { CommandDefinition } from "../framework/types.js";
/**
 * Installs the CLI package globally with npm.
 *
 * @param version - Exact version to install.
 * @param nonInteractive - Whether output should be captured instead of inherited.
 * @returns Command outcome.
 */
export declare function installCliPackage(version: string, nonInteractive: boolean, currentCliPrefix?: string | null): {
    ok: boolean;
    error?: string;
};
/**
 * Resolves the npm prefix that owns the running CLI package.
 *
 * npm global packages live below `prefix/lib/node_modules` on Unix and
 * `prefix/node_modules` on Windows. Deriving this prefix from the installed
 * package keeps an update inside the Node version that provided this CLI.
 */
export declare function resolveCurrentCliNpmPrefix(modulePath?: string, platform?: NodeJS.Platform): string | null;
/** Self-update command definition. */
export declare const updateDefinition: CommandDefinition;
