import { type RuntimeAppRole, type RuntimeMenuRolePermitNode, type RuntimePagePermit, type RuntimePermitRole, type RuntimeResourcePermit } from "../../core/api-client.js";
import type { FlagDef } from "../../framework/types.js";
export declare const MENU_ID_FLAG: FlagDef;
export declare const ROLE_REF_FLAG: FlagDef;
export declare const GRANT_FLAG: FlagDef;
export declare const REVOKE_FLAG: FlagDef;
export declare const PAGE_SLOT_SPECS: readonly [{
    readonly flag: "menu-roles";
    readonly key: "menuPermit";
    readonly allowSelf: false;
}, {
    readonly flag: "create-roles";
    readonly key: "dataCreate";
    readonly allowSelf: false;
}, {
    readonly flag: "update-roles";
    readonly key: "dataUpdate";
    readonly allowSelf: false;
}, {
    readonly flag: "delete-roles";
    readonly key: "dataDelete";
    readonly allowSelf: false;
}, {
    readonly flag: "detail-roles";
    readonly key: "dataDetail";
    readonly allowSelf: false;
}, {
    readonly flag: "export-roles";
    readonly key: "dataExport";
    readonly allowSelf: false;
}, {
    readonly flag: "row-roles";
    readonly key: "dataPermit";
    readonly allowSelf: true;
}];
export declare const PAGE_ROLE_FLAGS: FlagDef[];
export declare function splitRefs(value: string, label: string): string[];
export declare function assertGrantOrRevoke(grant: boolean, revoke: boolean): "grant" | "revoke";
export declare function resolveRuntimePermitRoles(appCode: string, refs: string[], allowSelf: boolean): Promise<RuntimePermitRole[]>;
export declare function assertRuntimePermissionManager(appCode: string): Promise<void>;
export declare function assertRuntimePermitRoleConfigurable(role: RuntimeAppRole): void;
export declare function applyRuntimeRolePermission(current: RuntimePermitRole[] | null | undefined, target: RuntimeAppRole, allRoles: RuntimePermitRole[], operation: "grant" | "revoke"): {
    roles: RuntimePermitRole[] | null;
    changed: boolean;
};
export declare function projectRuntimePagePermit(page: RuntimePagePermit): Record<string, unknown>;
export declare function flattenRuntimeMenuRolePermits(roots: RuntimeMenuRolePermitNode[]): RuntimeMenuRolePermitNode[];
export declare function runtimePermitWriteResult(operation: string, selector: Record<string, unknown>, before: unknown, after: unknown, backend: {
    method: string;
    path: string;
}, warnings?: string[]): Record<string, unknown>;
export declare function menuPermitDto(appCode: string, node: RuntimeMenuRolePermitNode, rolePermit: RuntimePermitRole[] | null): RuntimeResourcePermit;
