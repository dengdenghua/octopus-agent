/**
 * @fileoverview Internal helpers for `app import`.
 *
 * The import path converts an upgraded `.rabetbase.json` into the runtime
 * `.lovrabet.json` shape. Workspace lifecycle is owned by `workspace init/use`.
 * Why atomic writes via `writeConfigFile`: import updates the project config.
 * If the process crashes mid-write, we could leave a corrupt empty file.
 * The atomic write (temp + rename) prevents this.
 */
import type { FlagDef } from "../framework/types.js";
/** Flags for `lovrabet app import`. */
export declare const appImportFlagDefs: FlagDef[];
/** Handles `lovrabet app import`. */
export declare function runAppImport(flags: Record<string, any>): Promise<void>;
