/**
 * @fileoverview Re-exports of the framework flag parsing helpers.
 *
 * Why re-export rather than re-implementing: `createFlagHelpers` from the framework
 * already implements the full two-phase pipeline (parse → validate). The runtime
 * CLI only needs to wire it to `CliErrors` once here; individual commands import
 * `parseFlags` / `validateFlags` from this file rather than each building their own.
 */
export type { ParsedFlags } from "@lovrabet/cli-framework";
/**
 * Phase 1 — converts raw meow flags to typed values according to FlagDef metadata.
 * @see createFlagHelpers in `@lovrabet/cli-framework`
 */
export declare const parseFlags: (defs: import("@lovrabet/cli-framework").FlagDef[], rawFlags: Record<string, any>) => import("@lovrabet/cli-framework").ParsedFlags;
/**
 * Phase 2 — validates typed flags against their definitions, throwing on violation.
 * @see createFlagHelpers in `@lovrabet/cli-framework`
 */
export declare const validateFlags: (defs: import("@lovrabet/cli-framework").FlagDef[], parsed: import("@lovrabet/cli-framework").ParsedFlags, commandLabel: string) => void;
