import type { RuntimeSkillInstallScope, RuntimeSkillInstallTarget, RuntimeSkillInstallTargetOptions } from "./types.js";
/**
 * Resolves where effective runtime Skill links belong.
 *
 * User-level installation remains the default and retains all Agent roots plus
 * app-prefixed link names. Explicit project installs expose unprefixed Skill
 * codes beneath the current project's `.agents/skills`.
 */
export declare function resolveRuntimeSkillInstallTarget(appCode: string, scope?: RuntimeSkillInstallScope, options?: RuntimeSkillInstallTargetOptions): RuntimeSkillInstallTarget;
