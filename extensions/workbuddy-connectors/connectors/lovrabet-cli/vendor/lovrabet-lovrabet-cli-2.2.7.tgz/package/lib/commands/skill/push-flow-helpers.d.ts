import type { RuntimeSkillFilesManifest, RuntimeSkillItem, RuntimeSkillUpsertInput } from "../../core/api-client.js";
import type { RuntimeContext } from "../../framework/types.js";
import type { SkillValidationIssue } from "./validate.js";
/** Resolves the requested push scope while keeping personal as the default. */
export declare function resolvePushScope(ctx: RuntimeContext): "personal" | "company";
/** Returns an optional argument tuple for explicit appCode retarget calls. */
export declare function allowRetargetArgs(allowRetarget: boolean): [] | [{
    allowAppCodeRetarget: true;
}];
/** Lets push consult the remote Skill before treating local metadata cache as authoritative. */
export declare function remoteFirstMetadataOptions(): {
    ignoreInvalidMetadata: true;
    ignoreMetadataAppCodeMismatch: true;
    ignoreMetadataSkillCode: true;
};
/** Treats missing remote metadata as a new Skill publish, ignoring stale local cache fields. */
export declare function remoteMissingPayloadOptions(): {
    ignoreMetadataForPayload: true;
    ignoreMetadataScope: true;
    ignoreMetadataSkillCode: true;
};
/** Builds read options for a missing remote company Skill. */
export declare function remoteMissingCompanyReadOptions(): {
    ignoreMetadataForPayload: true;
    ignoreMetadataScope: true;
    ignoreMetadataSkillCode: true;
    ignoreInvalidMetadata: true;
    ignoreMetadataAppCodeMismatch: true;
    targetScope: "company";
};
/** Builds read options for a missing remote personal Skill. */
export declare function remoteMissingPersonalReadOptions(extra?: object): {
    ignoreMetadataForPayload: true;
    ignoreMetadataScope: true;
    ignoreMetadataSkillCode: true;
    ignoreInvalidMetadata: true;
    ignoreMetadataAppCodeMismatch: true;
};
/** Builds read options for an existing remote personal Skill. */
export declare function remotePersonalReadOptions(allowLocalScopeRecovery: boolean, extra?: object): {
    ignoreMetadataAppCodeMismatch?: true | undefined;
    ignoreMetadataScope?: true | undefined;
    ignoreInvalidMetadata: true;
};
/** Rejects push attempts that target immutable builtin Skills. */
export declare function throwIfBuiltinPushTarget(remote: {
    skillCode?: string;
    scope?: string;
} | undefined): void;
/** Converts a failed SkillHub push validation response into a CLI validation error. */
export declare function throwIfPublishValidationFailed(scope: RuntimeSkillContentScope, skillCode: string, validation: {
    valid: boolean;
    errors: string[];
    warnings: string[];
}): void;
/** Blocks unconfirmed publish warnings for either Skill scope. */
export declare function throwIfUnconfirmedPublishWarnings(scope: RuntimeSkillContentScope, skillCode: string, warnings: string[], confirmWarnings: boolean): void;
/** Builds a user-facing warning after an explicit appCode retarget succeeds. */
export declare function buildRetargetWarning(metadata: {
    appCode?: string;
} | undefined, targetAppCode: string): SkillValidationIssue[];
export type RuntimeSkillContentScope = "personal" | "company";
export type DownloadRuntimeSkillPackage = (scope: RuntimeSkillContentScope, skillCode: string, appCode: string, version?: string) => Promise<Buffer>;
export type VerifyRuntimeSkillBundle = (manifest: RuntimeSkillFilesManifest, packageBytes: Buffer) => unknown;
export type RemoteContentPreflightResult = {
    status: "identical";
    savedSkill: RuntimeSkillItem;
} | {
    status: "different" | "not-applicable";
};
/** Checks whether the current remote package exactly matches the local push package. */
export declare function runRemoteContentPreflight(input: {
    scope: RuntimeSkillContentScope;
    remote: RuntimeSkillItem | undefined;
    publishInput: Pick<RuntimeSkillUpsertInput, "content" | "files">;
    skillCode: string;
    appCode: string;
    downloadRuntimeSkillPackage: DownloadRuntimeSkillPackage;
    verifyRuntimeSkillBundle: VerifyRuntimeSkillBundle;
}): Promise<RemoteContentPreflightResult>;
