/**
 * @fileoverview Re-exports of the framework's response extraction utilities.
 *
 * Why: `extractList` and `extractPaging` are used by API commands (dataset, sql, bff)
 * to normalize heterogeneous API response shapes into a uniform list + paging model.
 * Re-exporting from here keeps the import path short and documents that these
 * utilities are the canonical way to extract data from API responses.
 */
export { extractList, extractPaging } from "@lovrabet/cli-framework";
export type { Paging, ListResponse } from "@lovrabet/cli-framework";
