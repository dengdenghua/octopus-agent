/**
 * @fileoverview Shared constraint validators for command `validate()` hooks.
 *
 * Why a dedicated module: flag constraint logic (exactly-one, mutual exclusion, etc.)
 * was previously duplicated in each command's `validate` function. This caused:
 * - Inconsistent error messages across commands
 * - Easy to forget a constraint and accept invalid flag combinations
 * - Hard to test constraint logic in isolation
 *
 * Centralizing here means:
 * - Constraint logic is defined once and tested once
 * - Error messages are consistent across all commands
 * - Adding a new constraint type only requires editing this file
 *
 * Why these four functions specifically: they cover the most common CLI flag
 * validation patterns (inspired by CLI design literature and tools like
 * `clap`/`click`/` argparse`):
 * - `requireOneOf`: commands that need exactly one identifier (e.g. `--id` OR `--name`)
 * - `requireAnyOf`: commands that need at least one selector
 * - `mutuallyExclusive`: flags that cannot be used together (e.g. `--verbose` + `--quiet`)
 * - `validatePattern`: flag values that must match a specific format
 */
import type { RuntimeContext } from "../../framework/types.js";
/**
 * Validates that exactly one of the named flags is set.
 *
 * Use case: commands like `data getOne` that accept either `--id` OR `--name`
 * but not both and not neither. The error message tells users exactly what
 * went wrong and how to fix it.
 *
 * @throws CliError with code `"validation_error"` if zero or more than one flag is set.
 */
export declare function requireOneOf(ctx: RuntimeContext, names: string[], label: string): void;
/**
 * Validates that at least one of the named flags is set.
 *
 * Use case: commands like `data batchCreate` where the user must provide
 * some identification method (id, name, or filter), even if only one is allowed.
 *
 * @throws CliError with code `"validation_error"` if no flags are set.
 */
export declare function requireAnyOf(ctx: RuntimeContext, names: string[], label: string): void;
/**
 * Validates that at most one of the named flags is set (mutual exclusion).
 *
 * Use case: `--verbose` and `--quiet` should not be used together — they are
 * both output modes and combining them is ambiguous. This constraint prevents
 * the ambiguity rather than defining precedence rules.
 *
 * @throws CliError with code `"validation_error"` if more than one flag is set.
 */
export declare function mutuallyExclusive(ctx: RuntimeContext, names: string[], label: string): void;
/**
 * Validates that a flag's value matches a regex pattern.
 *
 * Use case: validating that a `--code` flag matches the expected format
 * before making an API call that would return an opaque "not found" error.
 * Throwing a validation error gives immediate, actionable feedback.
 *
 * @param ctx   - Runtime context containing the flag value.
 * @param name  - Flag name to validate.
 * @param regex - Pattern the value must match.
 * @param desc  - Human-readable description of the expected format (shown in error).
 *
 * @throws CliError with code `"validation_error"` if the value doesn't match.
 */
export declare function validatePattern(ctx: RuntimeContext, name: string, regex: RegExp, desc: string): void;
