/**
 * @fileoverview Device code authorization flow.
 *
 * Two modes:
 * - Default (V1): interactive polling with spinner, saves AK directly.
 * - --url-only (V2): prints URL to stdout and exits; WorkBuddy polls via `auth status --check`.
 *
 * The temp file `~/.lovrabet/.device-auth` bridges the two commands:
 * `auth device` writes it, `auth status --check` reads it to resolve pending auth.
 */
import type { CommandDefinition } from "../../framework/types.js";
interface DeviceAuthTokenResponse {
    status: "authorization_pending" | "success" | "expired";
    access_key?: string;
}
interface StoredDeviceCode {
    code: string;
    createdAt: string;
    scope: "global" | "project";
}
export declare function generateDeviceCode(): string;
export declare function buildDeviceAuthUrl(userDomain: string, code: string, source?: string): string;
export declare function getDeviceCodePath(): string;
export declare function readStoredDeviceCode(): StoredDeviceCode | null;
export declare function writeStoredDeviceCode(code: string, scope: "global" | "project"): void;
export declare function deleteStoredDeviceCode(): void;
export declare function isStoredDeviceCodeExpired(stored: StoredDeviceCode): boolean;
export declare function fetchDeviceToken(userDomain: string, code: string): Promise<DeviceAuthTokenResponse>;
export declare function pollDeviceToken(userDomain: string, code: string, signal: AbortSignal): Promise<string>;
export declare const authDeviceDefinition: CommandDefinition;
export {};
