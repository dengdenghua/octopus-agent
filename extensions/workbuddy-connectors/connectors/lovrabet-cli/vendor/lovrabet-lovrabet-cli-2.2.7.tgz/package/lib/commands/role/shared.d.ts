import { type RuntimeAppRole, type RuntimeAppRoleType, type RuntimeRoleUsers } from "../../core/api-client.js";
import type { FlagDef, RuntimeContext } from "../../framework/types.js";
export declare const RUNTIME_ROLE_TYPES: RuntimeAppRoleType[];
export declare const ROLE_ID_FLAG: FlagDef;
export declare const ROLE_REF_FLAG: FlagDef;
export declare const USER_ID_FLAG: FlagDef;
export declare const EXPECT_USER_COUNT_FLAG: FlagDef;
export declare function isBuiltinRuntimeRole(roleType: string): boolean;
export declare function assertCustomRuntimeRole(role: RuntimeAppRole, action: string): void;
export declare function projectRuntimeRole(role: RuntimeAppRole): Record<string, unknown>;
export declare function getRuntimeRoleById(appCode: string, roleId: number): Promise<RuntimeAppRole>;
export declare function listAllRuntimeRoles(appCode: string, options?: {
    roleName?: string;
}): Promise<RuntimeAppRole[]>;
export declare function resolveRuntimeRoleRef(appCode: string, ref: string): Promise<RuntimeAppRole>;
export interface RuntimeMemberMutation {
    role: RuntimeAppRole;
    userId: number;
    roleList: RuntimeRoleUsers[];
    before: {
        userIds: number[];
    };
    after: {
        userIds: number[];
    };
    shouldWrite: boolean;
    warnings: string[];
}
export declare function prepareRuntimeMemberMutation(ctx: RuntimeContext, operation: "user-add" | "user-remove"): Promise<RuntimeMemberMutation>;
export declare function runtimeRoleWriteResult(operation: string, selector: Record<string, unknown>, before: unknown, after: unknown, backend: {
    method: string;
    path: string;
}, warnings?: string[]): Record<string, unknown>;
