/**
 * @fileoverview `schema export` command — generates a machine-readable command index.
 *
 * Why this command exists: external tools (IDEs, documentation generators,
 * AI agents) need a structured, stable representation of every command's
 * flags, arguments, risk level, and description. `schema export` produces
 * this as a JSON payload built from the runtime registry.
 *
 * Why it delegates to `buildSchemaPayload`: the actual schema-building logic
 * lives in the framework (`@lovrabet/cli-framework`). This command is the
 * runtime CLI's integration point — it passes the registry to the framework
 * and wraps the result in a `CommandResult`.
 *
 * Why `hasFormat: true`: the schema output can be formatted (e.g. `--format pretty`
 * for human inspection, `--format json` for machine consumption).
 */
import type { CommandDefinition } from "../framework/types.js";
export declare const schemaDefinition: CommandDefinition;
