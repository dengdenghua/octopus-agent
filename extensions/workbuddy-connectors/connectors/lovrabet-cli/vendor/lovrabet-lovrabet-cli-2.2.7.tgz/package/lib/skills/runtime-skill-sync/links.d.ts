import type { GlobalRuntimeSkillLinkResult, LinkRuntimeSkillResult, MaterializedRuntimeSkill, PruneRuntimeSkillResult, RuntimeSkillInstallTarget, RuntimeSkillScope, SkillSyncPathsOptions } from "./types.js";
/** Links the effective runtime Skill version into each agent Skill root. */
export declare function linkEffectiveRuntimeSkills(materialized: MaterializedRuntimeSkill[], target: RuntimeSkillInstallTarget): LinkRuntimeSkillResult[];
/** Removes managed target Skill links that no longer point to active Skill codes. */
export declare function pruneStaleRuntimeSkillLinks(target: RuntimeSkillInstallTarget, activeSkillCodes: Iterable<string>, pruneSkillCodes?: Iterable<string>): PruneRuntimeSkillResult[];
/** Removes stale managed cache directories whose metadata still matches the app. */
export declare function pruneStaleRuntimeSkillCache(input: {
    env: "production" | "development" | "daily";
    accessKey: string;
    appCode: string;
    activeSkillCodes: Iterable<string>;
    pruneSkillCodes?: Iterable<string>;
    scopes?: Array<Extract<RuntimeSkillScope, "personal" | "company">>;
    protectedLinkRoots?: readonly string[];
}, options?: SkillSyncPathsOptions): PruneRuntimeSkillResult[];
/** Copies builtin Skills into the global agent Skill root as real directories. */
export declare function linkGlobalRuntimeSkills(materialized: MaterializedRuntimeSkill[], options?: SkillSyncPathsOptions): GlobalRuntimeSkillLinkResult[];
/** Replaces a builtin global Skill directory with a managed copy. */
export declare function copyManagedSkillDirectory(sourceDir: string, targetDir: string): LinkRuntimeSkillResult;
