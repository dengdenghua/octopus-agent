/**
 * @fileoverview Command-level raw flag validation.
 *
 * `meow` accepts unknown long flags by default. Without a command-level check,
 * an input such as `data filter --where '{...}'` reaches the runner, is omitted
 * by the declarative flag parser, and executes as an unfiltered query. This
 * module rejects flags that are neither global nor declared by the resolved
 * command before authentication or execution begins.
 */
import type { CommandDefinition } from "../framework/types.js";
/** Rejects raw flags that the resolved command cannot consume. */
export declare function assertKnownCommandFlags(def: CommandDefinition, rawFlags: Record<string, unknown>): void;
