export declare const SKILL_TYPES: readonly ["write", "read"];
export type SkillTemplateType = typeof SKILL_TYPES[number];
export interface RenderSkillTemplateOptions {
    skillName: string;
    type: string;
    timestamp?: string;
}
export interface RenderedSkillFile {
    path: string;
    content: string;
}
export interface RenderedSkillTemplate {
    skillName: string;
    type: SkillTemplateType;
    files: RenderedSkillFile[];
}
export declare const DEFAULT_SKILL_TARGET = ".agents/skills";
export declare const SKILL_NAME_PATTERN: RegExp;
export declare const RUNTIME_CONTRACT_FILE = "references/runtime-contract.md";
export declare const OUTPUT_CONTRACT_FILE = "references/output-contract.md";
export declare function validateSkillName(name: string): string;
export declare function normalizeSkillTemplateType(type: string | undefined): SkillTemplateType;
export declare function renderSkillTemplate(options: RenderSkillTemplateOptions): RenderedSkillTemplate;
