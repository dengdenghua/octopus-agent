/**
 * 本文件定义 Lovrabet 嵌入式运行时的公共契约，包括确认、展示、执行结果和写入事件结构。
 * 这些类型构成 CLI runtime subpath 与 Coworker OpenCode 适配层之间的稳定边界。
 */
import type { CommandResult, OutputFormat, Risk } from "../framework/types.js";
export interface LovrabetConfirmationRequest {
    operation: string;
    risk: Extract<Risk, "write" | "high-risk-write">;
    description: string;
    signal?: AbortSignal;
}
export interface LovrabetConfirmationAdapter {
    /** 在写入副作用发生前请求调用方确认；拒绝时应通过抛错终止执行。 */
    confirm(request: LovrabetConfirmationRequest): Promise<void>;
}
export interface LovrabetPresentationRequest {
    result: CommandResult;
    command: string;
    operation: string;
    risk: Risk;
    format: OutputFormat;
    dryRun: boolean;
}
export interface LovrabetPresentationAdapter {
    /** 将结构化命令结果转换为原生工具需要展示的文本。 */
    present(request: LovrabetPresentationRequest): string | Promise<string>;
}
export interface LovrabetWriteCompletedEvent {
    type: "lovrabet.write.completed";
    operation: string;
    risk: Extract<Risk, "write" | "high-risk-write">;
    subject?: {
        kind: string;
        id: string;
        action: string;
    };
}
export interface LovrabetStructuredMetadata {
    lovrabet: {
        schemaVersion: 1;
        event: LovrabetWriteCompletedEvent;
    };
}
export interface InvokeLovrabetOptions {
    confirmation: LovrabetConfirmationAdapter;
    /**
     * 自定义展示失败时，已成功的写入会降级为默认 JSON 输出，避免把已完成副作用误报为执行失败。
     */
    presentation?: LovrabetPresentationAdapter;
    signal?: AbortSignal;
}
export interface InvokeLovrabetResult {
    operation: string;
    risk: Risk;
    mode: "execute" | "dry-run";
    result: CommandResult;
    output: string;
    metadata?: LovrabetStructuredMetadata;
}
