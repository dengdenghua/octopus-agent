import type { RuntimeSkillDiagramSubmission } from "../../core/api-client.js";
export interface RequiredSkillDiagramInput {
    diagram: RuntimeSkillDiagramSubmission;
    sourceFilePath?: string;
}
/** Reads and validates the direct Mermaid payload required by Skill publication. */
export declare function readRequiredSkillDiagram(path: string): Promise<RuntimeSkillDiagramSubmission>;
/** Reads a diagram plus its canonical file path for exact package-scan exclusion. */
export declare function readRequiredSkillDiagramInput(path: string): Promise<RequiredSkillDiagramInput>;
/** Canonicalizes line endings and validates the source with Mermaid's official parser. */
export declare function validateAndCanonicalizeMermaid(source: string): Promise<string>;
