/**
 * @fileoverview CLI version helpers.
 *
 * `getCliVersion()` returns the semantic version only. Keep it free of display
 * metadata because update checks, notices, and schema consumers compare this
 * value as a package version.
 */
/**
 * Returns the semantic CLI package version.
 *
 * @returns The generated `VERSION` value (e.g. `"1.2.3"`).
 */
export declare function getCliVersion(): string;
export declare function getCliGitCommit(): string;
/**
 * Returns the human-facing CLI version shown by `lovrabet --version`.
 */
export declare function getCliVersionDisplay(): string;
