import type { CommandDefinition } from "../../framework/types.js";
export declare const roleList: CommandDefinition;
