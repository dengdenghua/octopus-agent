import type { LocalSkillFile } from "./types.js";
export interface ExtractedZipFile {
    path: string;
    bytes: Buffer;
}
/** Creates a deterministic stored zip archive for normalized Skill files. */
export declare function createDeterministicZipPackage(files: LocalSkillFile[]): Buffer;
/** Parses a zip package through fflate while preserving runtime Skill path safety checks. */
export declare function parseZipPackage(packageBytes: Buffer): ExtractedZipFile[];
