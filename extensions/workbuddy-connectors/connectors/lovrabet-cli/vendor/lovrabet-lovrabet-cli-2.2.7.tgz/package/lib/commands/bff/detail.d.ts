/**
 * @fileoverview `bff detail` command — inspects one known endpoint by function name.
 *
 * Runtime callers identify Backend Functions by appCode + functionName. Platform IDs and raw
 * source metadata are intentionally not accepted or returned by this command.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const bffDetail: CommandDefinition;
