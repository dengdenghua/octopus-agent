/**
 * @fileoverview Static welcome page rendered via Ink.
 *
 * Why an Ink component: the CLI uses Ink (React for CLIs) for the entry point.
 * Even though the help text is generated statically, rendering it through Ink
 * keeps the rendering pipeline uniform and allows the same component model
 * to be used for interactive prompts elsewhere.
 *
 * Why `useEffect` with immediate `exit()`: Ink components must render something
 * and call `exit()` to terminate the React tree. Without the effect, the
 * component would hang waiting for state updates. The exit is immediate
 * (first render) so this is effectively a static component.
 *
 * Why `--help` text is NOT rendered here: `generateFullHelp()` is expensive
 * (reads all registry definitions, builds formatted strings). We generate it
 * once as a string and pass it to meow as the help text. Only the bare
 * welcome page is rendered via Ink.
 */
/**
 * Static welcome page — shows the CLI name and a hint to use `--help`.
 *
 * Renders immediately and exits on the first frame, allowing `cli.tsx`
 * to await `waitUntilExit()` and proceed normally.
 */
export declare function Help(): import("react/jsx-runtime").JSX.Element;
