/**
 * @fileoverview Declarative command registry — the central registration hub.
 *
 * All commands in Lovrabet Runtime CLI are declared as `CommandDefinition` objects
 * and registered in this file. The registry is consumed by:
 * - The framework runner (`runCommand`) to dispatch commands
 * - The help generator to list available commands
 * - The schema exporter to build the machine-readable command index
 *
 * Why a declarative approach: compared to the legacy switch-based approach
 * (one big `switch (command)` in a single handler file), declarative registration:
 * - Enables `buildSchemaPayload()` — the schema exporter iterates the registry
 * - Makes `--help` for a service easy to generate (enumerate all defs in the group)
 * - Makes testing simpler — each command definition is independently importable
 * - Reduces merge conflicts in the registry file
 *
 * Design decision: services are registered in a specific order. The order in
 * `serviceRegistry` determines the order of services in `--help` output.
 * `registerService()` is called at module load time (top-level), so the registry
 * is populated before any command runs.
 */
import type { CommandDefinition } from "../framework/types.js";
/**
 * A service entry used for help generation and schema export.
 *
 * `isSingleCommand` is `true` when a service has only one command and the
 * service name IS the command name (e.g. `lovrabet doctor`). In this case,
 * `lovrabet doctor --help` shows the command help directly rather than the
 * service listing with subcommands.
 */
export interface ServiceEntry {
    service: string;
    label: string;
    commands: {
        command: string;
        description: string;
        tag?: string;
    }[];
    defaultCommand?: string;
    /** `true` when the service has no subcommands and `service === command`. */
    isSingleCommand?: boolean;
}
/** The ordered list of service entries — drives `--help` output order. */
export declare const serviceRegistry: ServiceEntry[];
/** Map of `"service:command"` → `CommandDefinition`. */
export declare const definitions: Map<string, CommandDefinition>;
/** Map of `service` → array of `CommandDefinition` for that service. */
export declare const serviceGroups: Map<string, CommandDefinition[]>;
export interface RemovedCommand {
    command: string;
    message: string;
    hint: string;
}
/** Looks up a command definition by service and command name. */
export declare function findDefinition(service: string, command: string): CommandDefinition | undefined;
/** Returns a migration error for commands that were removed from discovery and execution. */
export declare function resolveRemovedCommand(service: string | undefined, command: string | undefined): RemovedCommand | undefined;
/** Returns `true` if `name` is a known service name. */
export declare function isKnownService(name: string): boolean;
/** Returns the service entry for a service name, or undefined. */
export declare function getServiceEntry(name: string): ServiceEntry | undefined;
/** Returns all registered command definitions. */
export declare function getAllDefinitions(): CommandDefinition[];
