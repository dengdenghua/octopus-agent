/**
 * @fileoverview `cli-skill` command definitions.
 *
 * CLI Built-in Skill is the Skill package required by the Lovrabet CLI runtime
 * itself. It is separate from business Skills managed by `lovrabet skill`.
 */
import type { CommandDefinition } from "../../framework/types.js";
/** Declarative definitions for the `cli-skill` service. */
export declare const cliSkillDefinitions: CommandDefinition[];
