/**
 * @fileoverview `app` subcommand definitions — list, pull, import.
 *
 * Why a flat array of command objects: Lovrabet Runtime CLI uses the declarative
 * `CommandDefinition[]` registry pattern (not a switch-based handler). Each command
 * is a self-contained `CommandDefinition` that the framework runner dispatches.
 *
 * Commands:
 * - list/pull: discover remote apps (cached) — read operations
 * - import: migrate from `.rabetbase.json` — write operation
 *
 * Why there is no `app add` / `app remove`: the runtime CLI does not manage
 * platform app records locally. The remote app directory remains the source of
 * truth for platform apps, while `.lovrabet.json` may define local aliases under
 * `apps.<alias>.appcode` for operator-friendly names.
 *
 * Workspace binding is intentionally owned by `workspace init/use`, not this
 * service. Keeping one owner prevents duplicate command semantics in help and
 * machine-readable schema output.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const appDefinitions: CommandDefinition[];
