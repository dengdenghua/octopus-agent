/**
 * @fileoverview Interactive prompt helpers for `auth` commands.
 *
 * Why a dedicated module: `auth/login` prompts for an AccessKey when not
 * provided via flag, and both Ctrl+C and empty-input need careful handling.
 * Sharing the prompt infrastructure here avoids duplicating the safe rl
 * boilerplate across auth commands.
 *
 * Why `AbortPrompt` as a named class (not just a `throw "cancelled"` string):
 * `isAbortPrompt()` can distinguish a user-initiated cancel from other errors
 * by checking `err.name === "AbortPrompt"`, rather than string matching on
 * the error message. This is more robust against future message changes.
 *
 * Why `Promise.race()` with `abortPromise` in every prompt: this ensures
 * Ctrl+C is always detected regardless of whether the user types input.
 * Without the race, the readline interface would swallow the SIGINT and the
 * process would hang.
 */
/**
 * Prompts the user for an AccessKey using stdin.
 *
 * @param defaultVal - Pre-filled value shown in the prompt (returned if input is empty)
 * @returns The user's input, trimmed; or `defaultVal` if the user pressed Enter without typing
 * @throws `AbortPrompt` (via `Promise.race`) if the user presses Ctrl+C
 */
export declare function promptAccessKey(defaultVal?: string): Promise<string>;
/**
 * Checks whether an error originated from a user-initiated prompt cancellation.
 *
 * @param err - Any thrown value
 * @returns `true` if `err` is an `AbortPrompt` thrown by `promptAccessKey`
 */
export declare function isAbortPrompt(err: unknown): boolean;
