import type { RuntimeSkillFile, RuntimeSkillFilesManifest, RuntimeSkillItem, RuntimeSkillUpsertInput } from "../../core/api-client.js";
export type RuntimeSkillScope = "personal" | "company" | "builtin";
export interface SkillSyncPathsOptions {
    homeDir?: string;
    agentsSkillsDir?: string;
    claudeSkillsDir?: string;
    workbuddySkillsDir?: string;
}
export type RuntimeSkillInstallScope = "project" | "global";
export interface RuntimeSkillInstallTargetOptions extends SkillSyncPathsOptions {
    /** Project directory that owns `.agents/skills`; defaults to the current working directory. */
    cwd?: string;
}
/**
 * Resolved installation target for effective runtime Skill links.
 *
 * Callers choose only project or global scope. Root selection, link naming, and
 * managed-cache ownership remain implementation details of runtime-skill-sync.
 */
export interface RuntimeSkillInstallTarget {
    scope: RuntimeSkillInstallScope;
    appCode: string;
    skillRoots: readonly string[];
    managedRoot: string;
}
export interface SkillSyncPaths {
    homeDir: string;
    cacheRoot: string;
    managedRoot: string;
    agentsSkillsDir: string;
    claudeSkillsDir: string;
    workbuddySkillsDir?: string;
}
export interface MaterializedRuntimeSkill {
    skill: RuntimeSkillItem;
    scope: RuntimeSkillScope;
    dir: string;
    skillMdPath: string;
    metadataPath: string;
    contentHash: string;
    changed: boolean;
}
export interface LocalRuntimeSkillListInput {
    env: "production" | "development" | "daily";
    accessKey: string;
    appCode: string;
    scopes?: RuntimeSkillScope[];
    code?: string;
}
export interface LocalRuntimeSkillItem extends RuntimeSkillMetadata {
    scope: RuntimeSkillScope;
    source: "local";
    dir: string;
    cacheDir?: string;
    skillMdPath: string;
    metadataPath: string;
    linkedPaths: string[];
}
export interface RuntimeSkillMetadata {
    schemaVersion: 1 | 2;
    id?: number;
    appCode: string;
    skillCode: string;
    skillName?: string;
    description?: string;
    example?: string;
    scope: string;
    readonly: boolean;
    tenantCode?: string;
    userId?: number | string;
    version?: string;
    status?: string;
    tags: string[];
    hasUpstreamUpdate?: boolean;
    forkedFromSkillId?: number;
    forkedFromVersion?: string;
    sourceSessionId?: string;
    contentHash: string;
    fileHashes?: Record<string, string>;
    treeHash?: string;
    ossPath?: string;
    zipSha256?: string;
    zipSize?: number;
    files?: Array<{
        path: string;
        hash: string;
        size: number;
    }>;
    pulledAt: string;
}
export interface LinkRuntimeSkillResult {
    path: string;
    target: string;
    action: "created" | "updated" | "unchanged";
}
export interface GlobalRuntimeSkillLinkResult {
    path: string;
    target: string;
    action: "created" | "updated" | "unchanged";
    contentHash: string;
}
export interface PruneRuntimeSkillResult {
    path: string;
    action: "removed" | "skipped";
    reason?: string;
}
export interface PushDirectoryPayload {
    skillCode: string;
    input: RuntimeSkillUpsertInput;
    metadata?: RuntimeSkillMetadata;
    frontmatterDisplayName?: string;
}
export interface LocalSkillFile {
    path: string;
    content?: string;
    bytes?: Buffer;
}
export interface BuiltSkillPackage {
    manifest: RuntimeSkillFilesManifest;
    packageBytes: Buffer;
    packageBase64: string;
}
export type { RuntimeSkillFile, RuntimeSkillFilesManifest, RuntimeSkillItem };
