export type BuiltinSkillState = "missing" | "current" | "version_mismatch" | "content_mismatch" | "unverifiable";
export type BuiltinSkillInstallCode = "SOURCE_INVALID" | "INSTALL_FAILED" | "VERIFY_FAILED";
export interface BuiltinSkillOptions {
    packageRoot?: string;
    home?: string;
    stdio?: "inherit" | "pipe";
}
export interface BuiltinSkillStatus {
    state: BuiltinSkillState;
    packageVersion: string;
    skillVersion?: string;
    installedPath?: string;
    digest?: string;
    reason?: string;
    repairCommand: string;
}
export interface BuiltinSkillInstallResult {
    ok: boolean;
    code?: BuiltinSkillInstallCode;
    packageVersion: string;
    skillVersion: string;
    installedPath?: string;
    changed: boolean;
    repairCommand: string;
    error?: string;
}
export interface InstalledBuiltinSkillVersionStatus {
    state: "current" | "missing" | "version_mismatch" | "unverifiable";
    expectedVersion: string;
    skillVersion?: string;
    installedPath?: string;
    reason?: string;
    repairCommand: string;
}
export declare function inspectInstalledBuiltinSkillVersion(expectedVersion: string, options?: Pick<BuiltinSkillOptions, "home">): InstalledBuiltinSkillVersionStatus;
export declare function inspectBuiltinSkill(options?: BuiltinSkillOptions): BuiltinSkillStatus;
export declare function installBuiltinSkill(options?: BuiltinSkillOptions): BuiltinSkillInstallResult;
