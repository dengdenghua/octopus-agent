/**
 * @fileoverview Shared command flag definitions used across multiple services.
 *
 * Why a centralized module: pattern validation (e.g. 32-char hex for dataset codes)
 * is error-prone to implement repeatedly. Centralizing these definitions means:
 * - Pattern and description are defined once and reused everywhere
 * - Commands that reference `CODE_FLAG` automatically get the correct regex
 * - Changes to the pattern (e.g. changing from 32 to 36 chars) propagate everywhere
 *
 * Design decision: these are the shared flags only. Command-specific flags
 * (e.g. `--env` for `config set`, `--file` for `app import`) are defined
 * in their respective command modules to keep the shared module stable.
 */
import type { FlagDef } from "../../framework/types.js";
/**
 * Dataset `--code` flag: accepts only a 32-character lowercase hex string (UUID format).
 *
 * Why this specific pattern: Lovrabet dataset codes are generated as SHA-256 hashes
 * of internal identifiers, producing exactly 64 hex characters. For user brevity,
 * the API surface uses only the first 32 characters (matching the prefix convention
 * used in Lovrabet Studio). Enforcing the pattern at the CLI layer gives immediate
 * feedback rather than an opaque API error for mistyped codes.
 */
export declare const CODE_FLAG: FlagDef;
/**
 * SQL/Backend Function `--sqlcode` flag: accepts the `xxxxxxxx-xxxxxxxx` format used by Lovrabet APIs.
 *
 * Why the hyphen separator: the `xxxxxxxx-xxxxxxxx` format (8-8, hex) matches the
 * standard GUID/UUID representation already used in Lovrabet Studio and the API docs.
 * Requiring the hyphen in the CLI forces users to copy the code exactly as shown
 * in the UI, reducing "wrong format" errors.
 */
export declare const SQLCODE_FLAG: FlagDef;
/** `--verbose`: when set, commands return the full raw API response instead of a summary. */
export declare const VERBOSE_FLAG: FlagDef;
/** `--params`: JSON string passed as the request body to execute commands. */
export declare const PARAMS_FLAG: FlagDef;
/** `--name`: resource name for lookup (used by `data getOne` and similar commands). */
export declare const NAME_FLAG: FlagDef;
/** `--id`: numeric resource ID (used by `data getOne`, `data delete`, etc.). */
export declare const ID_FLAG: FlagDef;
