/**
 * @fileoverview Structured logger for Lovrabet Runtime CLI.
 *
 * Why Winston instead of console.log: Winston provides structured logging with
 * severity levels, timestamps, and file transport. This is essential for:
 * - `lovrabet logs` — the logs command reads the log file and displays entries
 * - Observability — structured JSON logs are easier to parse in log aggregation systems
 * - Debugging — log files capture command history with timestamps and durations
 *
 * Design decision: all log entries are written as JSON objects to `.lovrabet-runtime.log`
 * in the project directory. JSON format makes them easy to query with `jq` and
 * parse programmatically. Plain text would be easier to read but harder to query.
 *
 * Why `silent: false` even with file-only transport: Winston's `silent` option
 * suppresses ALL output including errors during logger initialization. We keep
 * `silent: false` so initialization errors surface to the user rather than
 * silently failing to log.
 */
import winston from "winston";
/** A single structured log entry written to the log file. */
export interface LogEntry {
    timestamp: string;
    level: "info" | "success" | "error" | "warn";
    command: string;
    rawCommand?: string;
    message: string;
    duration?: number;
    details?: any;
}
declare class Logger {
    private winstonLogger;
    private logFilePath;
    private currentRawCommand;
    constructor();
    /** Sets the raw command string for the current invocation (used in all subsequent log entries). */
    setRawCommand(rawCommand: string): void;
    /** Initializes or reconfigures the Winston logger to write to a specific project directory. */
    setLogPath(projectPath: string): void;
    private initWinstonLogger;
    /** Logs an informational entry. */
    info(command: string, message: string, details?: any): void;
    /**
     * Logs a successful operation entry.
     * "Success" is logged at info level but with a custom level name
     * so `lovrabet logs --level success` can filter for successful operations.
     */
    success(command: string, message: string, duration?: number, details?: any): void;
    /** Logs an error entry. */
    error(command: string, message: string, details?: any): void;
    /** Logs a warning entry. */
    warn(command: string, message: string, details?: any): void;
    /**
     * Executes an async task and logs its start, completion (with duration),
     * or failure (with duration and error).
     *
     * Why `logTask` exists: this is a common pattern (start → success/fail → report duration).
     * Wrapping it in a utility avoids repeating the timing and logging boilerplate
     * in every command that wants structured timing information.
     */
    logTask<T>(command: string, taskName: string, task: () => Promise<T>): Promise<T>;
    /**
     * Reads all log entries from the current log file.
     * Returns an empty array if the file doesn't exist or can't be read.
     */
    readLogs(): LogEntry[];
    /** Clears the log file by truncating it to empty. */
    clearLogs(): void;
    /** Exposes the underlying Winston logger instance (for advanced use). */
    getWinstonInstance(): winston.Logger;
}
/** Singleton logger instance used throughout the CLI. */
export declare const logger: Logger;
export {};
