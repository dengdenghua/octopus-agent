/**
 * @fileoverview SDK client for runtime operations (data, SQL, Backend Function execution).
 *
 * Why a separate SDK client: the `@lovrabet/sdk` encapsulates the runtime engine's
 * API surface. Unlike the raw `fetch`-based management API (`api-client.ts`),
 * the SDK handles:
 * - Client lifecycle (creation, initialization)
 * - Per-operation routing (data operations vs. SQL vs. Backend Function)
 * - SDK-specific conventions (model keys, parameter extraction)
 *
 * Why the SDK is initialized in `prepare` and stored as a module-level variable:
 * creating the SDK client involves network setup and type registration. Storing
 * it globally avoids passing it through every function call. The `finalize` hook
 * clears it to prevent cross-command contamination.
 *
 * Design decision: `executeData` uses dynamic model key lookup
 * (`dataset_${code}`) rather than requiring pre-registered models. This matches
 * the Lovrabet SDK's dynamic model convention and avoids a registration step
 * in `prepare`.
 */
import type { AuthMode } from "../constant/auth-mode.js";
/** Options for initializing the SDK client. */
export interface SdkClientOptions {
    appCode: string;
    env: "production" | "development" | "daily";
    accessKey?: string;
    authMode?: AuthMode;
}
/**
 * Initializes the global SDK client for subsequent runtime operations.
 *
 * Why `initSdkClient` is idempotent: `prepare` is called for every command, and
 * commands may share the same app/env/AK combination. Calling `createClient`
 * multiple times with the same params is wasteful. The module-level `_client`
 * variable ensures only one client instance exists at a time.
 */
export declare function initSdkClient(opts: SdkClientOptions): void;
/** Clears the SDK client and restores process-wide patches installed for it. */
export declare function clearSdkClient(): void;
/**
 * Executes a data operation on a dataset via the SDK.
 *
 * Why model access by key (`dataset_${datasetCode}`): Lovrabet's SDK uses
 * a dynamic model registry where each dataset is accessible as `models.dataset_<code>`.
 * This avoids requiring the SDK to know all dataset codes upfront.
 *
 * Parameter extraction conventions:
 * - `filter(params)` — params passed directly
 * - `getOne(id | {id})` — extract `id` from params
 * - `update(id, data)` — extract `id`, pass rest as data
 * - `delete(id)` — extract `id` from params
 * - `batchCreate(items[])` — normalize params (array or `{ items: [...] }`)
 * - `aggregate(params)` — params passed after normalizing deprecated `aggregate[].field` to `column`
 *
 * These conventions match the Lovrabet API's request body structure and
 * were derived from the SDK's internal expectations.
 */
export declare function executeData(datasetCode: string, operation: string, params?: Record<string, any> | unknown[]): Promise<any>;
/** Executes a stored SQL query via the SDK. */
export declare function executeSdkSql(sqlCode: string, params?: Record<string, string | number>): Promise<any>;
/** Executes a Backend Function script via the SDK. */
export declare function executeSdkBff(functionName: string, params?: Record<string, any>): Promise<any>;
