import type { LocalRuntimeSkillItem, LocalRuntimeSkillListInput, RuntimeSkillInstallTarget, SkillSyncPathsOptions } from "./types.js";
/** Lists locally cached and linked runtime Skills for one app context. */
export declare function listLocalRuntimeSkills(input: LocalRuntimeSkillListInput, target: RuntimeSkillInstallTarget, options?: SkillSyncPathsOptions): LocalRuntimeSkillItem[];
