import { type NormalizedServiceTree, type NormalizedServiceTreeCommand } from "@lovrabet/cli-framework";
import type { CommandDefinition } from "../../framework/types.js";
import type { ServiceEntry } from "../../commands/registry.js";
export interface DynamicServiceResolution {
    definition: CommandDefinition;
    args: string[];
    flags: Record<string, any>;
    tree: NormalizedServiceTree;
    command: NormalizedServiceTreeCommand;
}
export declare function resolveDynamicServiceCommand(input: string[], flags: Record<string, any>): DynamicServiceResolution | undefined;
export declare function generateDynamicServiceHelp(serviceCode: string): string | undefined;
export declare function listDynamicServiceEntries(): ServiceEntry[];
export declare function getDynamicServiceEntry(serviceCode: string): ServiceEntry | undefined;
export declare function listDynamicServiceDefinitions(serviceCode?: string): CommandDefinition[];
export declare function getDynamicServiceDefinitions(serviceCode: string): CommandDefinition[] | undefined;
export declare function findDynamicServiceDefinition(serviceCode: string, commandName: string): CommandDefinition | undefined;
export declare function buildDynamicCommandDefinition(tree: NormalizedServiceTree, command: NormalizedServiceTreeCommand): CommandDefinition;
