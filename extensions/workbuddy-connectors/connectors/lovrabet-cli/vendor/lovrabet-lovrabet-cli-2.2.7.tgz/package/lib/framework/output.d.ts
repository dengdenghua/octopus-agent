import type { CommandResultWithNotice, OutputFormat, Risk } from "../framework/types.js";
interface OutputOptions {
    command: string;
    risk: Risk;
    format: OutputFormat;
    dryRun?: boolean;
    jqFilter?: string;
}
export declare function formatOutput<T>(result: CommandResultWithNotice<T>, options: OutputOptions): void;
export {};
