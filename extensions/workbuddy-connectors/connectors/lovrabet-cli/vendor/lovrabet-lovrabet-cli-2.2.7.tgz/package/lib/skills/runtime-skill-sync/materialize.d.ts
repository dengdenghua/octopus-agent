import type { MaterializedRuntimeSkill, RuntimeSkillItem, RuntimeSkillScope, SkillSyncPathsOptions } from "./types.js";
/** Materializes one downloaded runtime Skill package into the managed cache. */
export declare function materializeRuntimeSkill(skill: RuntimeSkillItem, scope: RuntimeSkillScope, options: {
    env: "production" | "development" | "daily";
    accessKey: string;
    appCode: string;
    pulledAt?: string;
    paths?: SkillSyncPathsOptions;
    force?: boolean;
    packageBytes?: Buffer;
}): MaterializedRuntimeSkill;
/** Reuses an intact immutable remote version without downloading its package again. */
export declare function reuseMaterializedRuntimeSkill(skill: RuntimeSkillItem, scope: RuntimeSkillScope, options: {
    env: "production" | "development" | "daily";
    accessKey: string;
    appCode: string;
    paths?: SkillSyncPathsOptions;
}): MaterializedRuntimeSkill | undefined;
