import type { BuiltSkillPackage, LocalSkillFile, RuntimeSkillFile, RuntimeSkillFilesManifest } from "./types.js";
/** Builds a deterministic zip package and matching manifest for local pushes. */
export declare function buildSkillPackage(files: LocalSkillFile[]): BuiltSkillPackage;
/** Verifies a package against a manifest including zip-level byte evidence. */
export declare function verifyRuntimeSkillPackage(manifest: RuntimeSkillFilesManifest, packageBytes: Buffer): LocalSkillFile[];
/** Verifies bundle entries when SkillHub may have rebuilt the zip container. */
export declare function verifyRuntimeSkillBundle(manifest: RuntimeSkillFilesManifest, packageBytes: Buffer): LocalSkillFile[];
/** Normalizes a package manifest and returns undefined when it is absent. */
export declare function tryNormalizePackageManifest(manifest: RuntimeSkillFilesManifest | undefined): RuntimeSkillFilesManifest | undefined;
/** Requires package bytes for install. */
export declare function requirePackageBytes(skillCode: string, packageBytes: Buffer | undefined): Buffer;
/** Extracts a downloaded install package without consulting legacy content fields. */
export declare function extractDownloadedPackage(packageBytes: Buffer): LocalSkillFile[];
/** Converts local package files into manifest entries with hashes and sizes. */
export declare function localFilesToManifestFiles(files: LocalSkillFile[]): RuntimeSkillFile[];
