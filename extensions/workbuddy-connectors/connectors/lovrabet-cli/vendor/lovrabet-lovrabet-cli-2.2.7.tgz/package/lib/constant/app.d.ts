/**
 * @fileoverview Application domain constants.
 *
 * These values mirror platform app publish statuses used by the runtime app
 * directory. Keep business rules in command helpers, and keep raw status values
 * here as the shared source of truth.
 */
export declare const APP_PUBLISH_STATUS: {
    readonly Published: "PUBLISHED";
    readonly Unpublished: "UNPUBLISH";
};
export type AppPublishStatus = (typeof APP_PUBLISH_STATUS)[keyof typeof APP_PUBLISH_STATUS];
export declare const RUNTIME_ACCESSIBLE_APP_STATUS: "PUBLISHED";
