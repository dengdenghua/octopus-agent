/**
 * @fileoverview `sql` command group — exports the declarative definition list.
 *
 * Mirrors the `bff/` pattern: runtime CLI provides SQL execution and inspection
 * (not list/save, which belong to the development CLI). See `bff/index.ts`
 * for the rationale.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const sqlDefinitions: CommandDefinition[];
