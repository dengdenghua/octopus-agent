/**
 * @fileoverview `config` subcommand shared utilities — re-exports and helpers.
 *
 * Why this module: `config/definitions.ts` and `auth/index.tsx` both need
 * the same config policy helpers (`resolveConfigScope`, `toScopeFlags`, etc.)
 * and the same config key classification functions from `config-policy.ts`.
 * Re-exporting them here provides a stable namespace (`@/commands/config/shared`)
 * that won't break if the internal layout of `config-policy.ts` changes.
 *
 * Note: `resolveConfigScope` is re-exported as `resolveWriteScope` because the
 * policy module uses "scope" terminology internally, while config commands
 * think in terms of "where to write". The semantics are identical.
 */
import { CLI_BIN_NAME } from "../../constant/cli.js";
export { CLI_BIN_NAME };
export { readScopedConfig, writeScopedConfig } from "../../context.js";
export { resolveConfigScope as resolveWriteScope, TOP_LEVEL_CONFIG_KEYS as TOP_LEVEL_KEYS, CONFIG_ENUM_VALUES as ENUM_KEYS, getConfigCommandKeyDescription, getTopLevelConfigKeyList, getTopLevelConfigKeySummary, isTopLevelConfigKey, toScopeFlags, } from "../../commands/common/config-policy.js";
