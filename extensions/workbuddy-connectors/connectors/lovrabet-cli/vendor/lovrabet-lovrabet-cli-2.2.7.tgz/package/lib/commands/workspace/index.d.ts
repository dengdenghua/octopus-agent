/**
 * @fileoverview Workspace commands — bind the current working directory to a
 * Lovrabet app context.
 *
 * WorkBuddy-style tools have an explicit working directory. These commands make
 * that directory's `.lovrabet.json` the place where app intent lives, without
 * storing credentials.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const workspaceDefinitions: CommandDefinition[];
