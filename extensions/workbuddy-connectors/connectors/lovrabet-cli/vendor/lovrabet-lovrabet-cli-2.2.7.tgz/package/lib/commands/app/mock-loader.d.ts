/**
 * @fileoverview Mock data loader for app list — reads fixtures for offline development.
 *
 * Why a separate module: mock data is loaded in `remote-source.ts` when
 * the product-scoped `APP_LIST_SOURCE=mock` env var is set. Isolating this to its own module
 * makes it easy to verify which data sources are in play and to add new
 * fixture files without touching the real API client.
 *
 * Design decision: module-level caching (`_cached`) — once a mock file is
 * loaded, it stays in memory for the lifetime of the process. This avoids
 * repeated filesystem reads during rapid command invocations.
 */
import type { RemoteAppItem } from "../../core/api-client.js";
/**
 * The full API response shape returned by the app-list endpoint.
 * Mirrors `getMyApps()` response structure so callers see identical types.
 */
export interface AppListResponse {
    success: boolean;
    msg: string;
    errorMsg: string;
    errorCode: string;
    data: {
        tableData: RemoteAppItem[];
        tableColumns: unknown[];
    };
    params: unknown;
}
/**
 * Returns the cached mock app list response (lazy-loaded once per process).
 *
 * @returns The full `AppListResponse` from the fixture file.
 */
export declare function getMockAppList(): AppListResponse;
/**
 * Returns just the app items from the mock fixture, matching `getMyApps()` return type.
 *
 * @returns `RemoteAppItem[]` from the mock fixture.
 * @throws Error with `Mock API error:` prefix if the fixture indicates a failure.
 */
export declare function getMockRemoteAppItems(): RemoteAppItem[];
