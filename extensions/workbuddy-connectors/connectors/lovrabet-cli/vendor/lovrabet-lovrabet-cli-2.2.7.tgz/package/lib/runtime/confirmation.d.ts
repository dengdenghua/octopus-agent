/**
 * 本文件把命令声明的确认契约收敛为稳定、脱敏且有长度上限的嵌入式确认请求。
 */
import type { CommandDefinition } from "../framework/types.js";
import type { LovrabetConfirmationRequest } from "../runtime/types.js";
/**
 * 使用命令确认文案生成最终确认请求。
 */
export declare function buildLovrabetConfirmationRequest(definition: CommandDefinition, operation: string, signal?: AbortSignal): LovrabetConfirmationRequest;
