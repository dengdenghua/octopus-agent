/**
 * @fileoverview Error factory singleton for Lovrabet Runtime CLI.
 *
 * Wraps the framework error factory with CLI-specific hint messages.
 * All errors thrown by command implementations must go through this factory
 * so the top-level handler can format them consistently.
 *
 * Why: Throwing raw `new CliError` scattered across commands makes it impossible
 * to change hint messages or error codes without a global search. Centralizing
 * through `CliErrors` keeps the contract in one place.
 */
import { CliError } from "@lovrabet/cli-framework";
export { CliError };
export declare const CliErrors: {
    rateLimited: (message: string, hint?: string) => CliError;
    authRequired(hint?: string): CliError;
    configMissing(hint?: string): CliError;
    notInProject(): CliError;
    apiError(message: string, hint?: string): CliError;
    networkError(message: string): CliError;
    unknownCommand(cmd: string): CliError;
    flagMissing(flagName: string, hint?: string): CliError;
    validation(message: string, hint?: string): CliError;
    cancelled(message?: string): CliError;
};
