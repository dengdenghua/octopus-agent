/**
 * @fileoverview Runtime environment values and helpers.
 *
 * Why a dedicated module: the runtime environment string (`production` / `development` /
 * `daily`) is one of the most frequently evaluated values in the CLI — it controls
 * API domain selection, SDK initialization, and SDK client creation. Keeping it
 * isolated lets us add normalization (e.g. `"online"` → `"production"`) in one place
 * rather than patching each call site.
 *
 * Design decision: environment is stored as a module-level mutable variable (`env`)
 * initialized once at startup. This is simpler than threading `env` through every
 * function, and is safe because the CLI is single-threaded and the environment
 * never changes during a single invocation.
 */
/**
 * The three valid runtime environment values.
 * These must match the environment names accepted by the @lovrabet/sdk client.
 */
export declare const RUNTIME_ENV_VALUES: readonly ["production", "development", "daily"];
/**
 * Normalizes a user-supplied environment string to the canonical form.
 *
 * Why normalize `"online"` to `"production"`: older `.lovrabet.json` and
 * `.rabetbase.json` files used `"online"` before the team standardized on
 * `"production"`. Normalizing at the boundary prevents this legacy value from
 * reaching downstream code that only knows the canonical set.
 *
 * @param e - Any string (including legacy aliases).
 * @returns `"production"`, `"development"`, or `"daily"`.
 */
export declare function normalizeEnv(e: string): string;
/** Checks whether the normalized environment is production (or the legacy `"online"` alias). */
export declare function isProduction(e: string): boolean;
/** Checks whether the normalized environment is `daily`. */
export declare function isDaily(e: string): boolean;
/**
 * Checks whether the normalized environment is development.
 *
 * Why `"dev"` as a fallback: some developers use `"dev"` locally (mirroring the
 * `@lovrabet/sdk` convention). We accept it as an alias for `"development"` so
 * local configs don't need to be changed when migrating.
 */
export declare function isDev(e: string): boolean;
/** Returns the current effective environment. */
export declare function getEnv(): string;
/**
 * Updates the effective environment.
 * Called once during `initGlobalEnvironment()` before any domain or SDK usage.
 *
 * Why not just read the environment variable everywhere: env values may come from
 * the config file rather than the environment variable, and
 * the config is authoritative for the current invocation.
 *
 * @param _env - Environment value (already normalized if from config).
 */
export declare function initEnv(_env: string): void;
