/**
 * @fileoverview Stable external URLs referenced by the CLI.
 *
 * Why centralize URLs here: user-facing links can appear in prompts, help text,
 * and diagnostics. Keeping them in one module prevents drift when the same URL
 * is reused across multiple commands.
 */
/**
 * Self-service page where users can create an AccessKey.
 *
 * Why this stays production-scoped: AccessKey creation is managed in the main
 * user center rather than the runtime environment-specific backends.
 */
export declare const USER_ACCESS_KEY_CREATE_URL: string;
