/**
 * @fileoverview `sql exec` command — executes a custom SQL query by sqlCode.
 *
 * Why `risk: "read"`: custom SQL queries can be destructive (DROP, TRUNCATE),
 * but the runtime CLI cannot statically determine what a query does from its
 * `sqlCode`. Using `"read"` avoids `--yes` prompts while the Studio-level
 * permissions govern actual write access. Scripts that perform writes are
 * expected to be permission-controlled at the platform level.
 *
 * Why `execSuccess` check: the Lovrabet SQL API returns `execSuccess: false`
 * on query failure even when the HTTP status is 200. We surface this as an
 * `ok: false` response so callers can distinguish success from failure in
 * scripts without inspecting the data shape.
 *
 * Why returning `execResult` directly when it's not an array: the Lovrabet
 * SQL API can return a single object (e.g. `SELECT 1` returns `{ "": 1 }`).
 * We normalize this to always return a `rows` array, falling back to `[]`
 * when the response is neither.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const sqlExec: CommandDefinition;
