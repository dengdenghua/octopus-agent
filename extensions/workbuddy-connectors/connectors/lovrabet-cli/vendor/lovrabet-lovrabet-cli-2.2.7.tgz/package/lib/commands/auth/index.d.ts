/**
 * @fileoverview `auth` subcommand definitions — login, init, logout, status.
 *
 * Why all three commands use `ClientAk` mode: Lovrabet Runtime CLI is a
 * developer-facing tool that operates in the runtime environment (production /
 * development / daily). It uses AccessKey authentication exclusively, not
 * the session cookie flow used by the web-oriented `rabetbase` CLI.
 *
 * Why `--project` is a flag rather than the default for login/logout:
 * Auth credentials are typically shared across projects (one developer works
 * on multiple projects). Writing to global by default means one `auth login`
 * suffices for all projects. `--project` is opt-in for project-isolated creds.
 *
 * Why `resolveAuthScopeFlags` uses `policy: "global-default"`: auth credentials
 * should default to global, while workspace binding always targets the current directory.
 * Project-specific auth is an edge case handled by `--project`.
 *
 * Design decision: `auth status` reads the product-scoped access key env var
 * (not through the config layer) to make the priority order explicit in the
 * output: env var > config file. This helps users debug credential issues.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const authDefinitions: CommandDefinition[];
