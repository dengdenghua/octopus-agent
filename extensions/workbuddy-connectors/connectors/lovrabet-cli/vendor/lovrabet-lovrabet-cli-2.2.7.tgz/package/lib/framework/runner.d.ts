/**
 * 本文件实现 Lovrabet Runtime CLI 对通用命令执行框架的适配。
 * 它负责认证与应用解析、SDK 初始化、风险确认、错误映射、结果输出和全局状态清理，
 * 同时为终端 CLI 与嵌入式 OpenCode 调用提供同一条执行内核。
 *
 * Architecture overview:
 * The framework (`@lovrabet/cli-framework`) owns the generic orchestration loop:
 *   parseFlags → validateFlags → validateArgs → riskPolicy → prepare →
 *   buildRuntimeContext → validate → dryRun → confirmHighRisk → execute → formatOutput
 *
 * This file implements the `RunnerAdapter` interface with Lovrabet Runtime-specific logic:
 * - `prepare`: resolves AccessKey auth, initializes the SDK client
 * - `confirmHighRisk`: interactive or non-interactive confirmation
 * - `riskPolicy`: logs violations and throws a cancelled error (not validation,
 *   because cancelling is not a user error — it is the expected response to "no")
 * - `finalize`: clears the SDK client and active AccessKey from module state
 *
 * Why `riskPolicy.createError` returns `CliErrors.cancelled()`: in Lovrabet CLI's
 * error taxonomy, a blocked high-risk operation in non-interactive mode is a
 * "cancelled" outcome (user can proceed by adding --yes). We use exit code 0
 * (`cancelled`) rather than exit code 1 (`validation_error`) so automated scripts
 * can distinguish "blocked by policy" from "input is wrong".
 *
 * Design decision: `accessKey` is stored in a module-level variable in `api-client.ts`
 * rather than threaded through the context. This simplifies the adapter's `prepare`
 * function and avoids prop-drilling AK through every function. The `finalize`
 * hook clears it after each command to prevent AK leakage across commands in
 * long-running processes.
 */
import type { CommandDefinition, OutputFormat, MergedCliSnapshot, RuntimeContextExtras } from "../framework/types.js";
import type { Risk, RunnerAdapter } from "@lovrabet/cli-framework";
import type { CLIConfig } from "../context.js";
import { type AuthMode } from "../constant/auth-mode.js";
/**
 * Environment values passed into the runner by the CLI entry point.
 *
 * These are the raw values before any dependency resolution — the adapter's
 * `prepare` hook will resolve `accessKey`, initialize the SDK, and populate
 * the extras object.
 */
export interface PipelineEnv {
    /** Raw parsed flags from meow (may include PreParse corrections). */
    rawFlags: Record<string, any>;
    /**
     * App code resolved so far — may be undefined if not yet available.
     * `prepare` will validate this is set for commands that need it.
     */
    appCode: string | undefined;
    /** Source used to resolve `appCode`, used to revalidate explicit `--app`. */
    appCodeSource?: CLIConfig["appCodeSource"];
    /** Runtime API domain (production or daily). */
    apiDomain: string;
    /** `true` when running in CI or when `--non-interactive` was supplied. */
    isNonInteractive: boolean;
    /** Default format from the config file (falls through to --format). */
    defaultFormat?: OutputFormat;
    /** Default page size from the config file. */
    defaultPageSize?: number;
    /** Verbose mode flag from the config file. */
    defaultVerbose?: boolean;
    /** User-configured risk ceiling from the config file. */
    riskLevel?: Risk;
    /** AccessKey resolved from config (may be undefined for public commands). */
    accessKey?: string;
    /** Normalized environment name. */
    env?: "production" | "development" | "daily";
    /** Positional arguments after the subcommand name. */
    args?: string[];
    /** Snapshot of the merged multi-app config. */
    mergedCli?: MergedCliSnapshot;
}
/**
 * 根据当前调用环境选择认证模式。
 * 当前只支持 client-ak；保留函数边界便于未来集中扩展其他认证路由。
 */
export declare function resolveAuthMode(env: PipelineEnv): AuthMode;
/**
 * 根据已加载配置和原始 flags 构造完整 PipelineEnv。
 * appCode 按显式配置、产品环境变量、配置文件的顺序解析，确保调用方获得统一运行环境。
 */
export declare function createPipelineEnv(config: CLIConfig, flags: Record<string, any>): PipelineEnv;
/**
 * 嵌入式调用方可覆盖输出和高风险确认；终端 CLI 使用默认行为。
 */
export interface LovrabetRunnerAdapterOptions {
    formatOutput?: RunnerAdapter<PipelineEnv, RuntimeContextExtras>["formatOutput"];
    confirmHighRisk?: RunnerAdapter<PipelineEnv, RuntimeContextExtras>["confirmHighRisk"];
}
/**
 * 为终端 CLI 或嵌入式调用方创建 runner adapter。
 * 工厂通过进程内扩展点允许嵌入式调用捕获输出并接管确认，同时不修改通用框架。
 */
export declare function createLovrabetRunnerAdapter(options?: LovrabetRunnerAdapterOptions): RunnerAdapter<PipelineEnv, RuntimeContextExtras>;
/**
 * 清理进程级 SDK 和认证状态。
 * 嵌入式调用还会在外层 finally 调用它，以覆盖 dry-run 提前返回及校验或确认失败的路径。
 */
export declare function finalizeLovrabetRuntimeState(): Promise<void>;
/**
 * 执行一个已声明命令；终端默认使用标准 adapter，嵌入式调用可传入自定义 adapter。
 */
export declare function runCommand(def: CommandDefinition, env: PipelineEnv, adapter?: RunnerAdapter<PipelineEnv, RuntimeContextExtras>): Promise<void>;
