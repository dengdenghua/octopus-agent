import { type BuiltinSkillInstallResult, type BuiltinSkillOptions } from "./skills/builtin-skill.js";
export declare function runPostinstall(options?: BuiltinSkillOptions): Promise<BuiltinSkillInstallResult>;
