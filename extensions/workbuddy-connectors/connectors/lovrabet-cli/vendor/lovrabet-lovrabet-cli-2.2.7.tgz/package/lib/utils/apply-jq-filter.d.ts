/**
 * @fileoverview jq filter integration — wires the framework's jq helper to Lovrabet's error factory.
 *
 * This module exists solely to create a jq filter function bound to `CliErrors`.
 * The actual jq logic (binary resolution, exec, error handling) lives in the
 * framework package. We re-export it here so commands can import from the
 * runtime's utils rather than reaching into the framework.
 *
 * Why not import `applyJqFilter` directly from the framework: commands in the
 * runtime CLI import from `@/utils/apply-jq-filter` rather than from the
 * framework package. This module bridges the two by creating the bound function
 * using the runtime's `CliErrors`.
 */
/**
 * A jq filter function pre-bound to Lovrabet's error factory.
 *
 * Usage:
 * ```ts
 * import { applyJqFilter } from "../utils/apply-jq-filter";
 * const out = applyJqFilter(jsonInput, ".[].name");
 * ```
 *
 * @see createJqFilter in `@lovrabet/cli-framework` for full documentation.
 */
export declare const applyJqFilter: (jsonInput: string, expr: string) => string;
