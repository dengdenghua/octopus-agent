/**
 * @fileoverview `data` command definitions — Instant API operations on dataset records.
 *
 * Why a spec-driven factory (`makeDataCommand`): all seven operations
 * (filter, getOne, create, batchCreate, update, delete, aggregate) share
 * the same structure: `CommandDefinition` with a `validate` hook and an
 * `execute` body. Only the operation name, risk level, params requirement,
 * and help text differ. A spec table eliminates duplication while keeping
 * each operation's behavior explicit and auditable.
 *
 * Why `riskLevelOrder` is NOT enforced for `data` operations: the risk level
 * is set per-operation (`read` for filter/getOne/aggregate, `write` for
 * create/update, `high-risk-write` for delete). However, the framework's
 * risk-level confirmation is bypassed here because:
 * 1. `data delete` already requires `--yes` in non-interactive mode via
 *    the pipeline's risk confirmation step (based on `risk: "high-risk-write"`)
 * 2. Write operations (create/update) are common and non-destructive
 *
 * Why `dryRun` is only attached for non-read operations: dry-run only makes
 * sense for mutating operations. Read operations have no side effects to preview.
 *
 * Design decision: `batchCreate` accepts both a plain array (`[...]`) and
 * a wrapped object (`{items: [...]}`) via `parseBatchCreateItemsFromParams`.
 * This matches the flexibility of the Lovrabet Studio UI.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const dataDefinitions: CommandDefinition[];
