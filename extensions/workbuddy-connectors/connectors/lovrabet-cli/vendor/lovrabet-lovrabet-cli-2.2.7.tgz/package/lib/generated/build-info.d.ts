export declare const VERSION = "2.2.7";
export declare const GIT_TAG = "v2.2.7";
export declare const GIT_COMMIT = "f7f4434";
export declare const BUILD_TIME = "2026-08-20T12:39:08.398Z";
