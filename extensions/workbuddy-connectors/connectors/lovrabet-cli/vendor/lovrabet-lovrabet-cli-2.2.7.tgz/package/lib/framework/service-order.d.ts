export interface OrderedServiceEntry {
    service: string;
}
export declare function insertDynamicServicesAfterServiceTree<T extends OrderedServiceEntry>(staticServices: readonly T[], dynamicServices: readonly T[]): T[];
