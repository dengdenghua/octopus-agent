/**
 * @fileoverview `kb` command group — personal knowledge base and visible search.
 *
 * Phase one intentionally exposes file-based create/update and read/search
 * workflows only. Delete exists in the backend but is not registered here.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const kbDefinitions: CommandDefinition[];
