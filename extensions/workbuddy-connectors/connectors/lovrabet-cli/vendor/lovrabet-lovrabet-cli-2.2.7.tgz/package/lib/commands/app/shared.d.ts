/**
 * @fileoverview Shared projection helper for `app list`.
 *
 * Design decision: `enrichAppListItemsWithMergedSelection` is placed here rather
 * than in `cache.ts` because it operates on the merged CLI snapshot from the
 * pipeline, not on the raw cache. This keeps cache.ts focused on cache I/O only.
 */
import type { MergedCliSnapshot } from "../../framework/types.js";
/**
 * Marks which app in the list is "current" based on the merged CLI snapshot.
 *
 * Why this is a mutation: the list items are objects passed by reference from
 * the caller (`app list`). Mutating them in-place is simpler and faster than
 * reconstructing a new array. The caller has no use for the unmarked list anyway.
 *
 * Current is determined by:
 * - If a named app is selected (`currentApp` or `defaultApp`), the matching named item wins
 * - If only `appCode` is set (no named selection), the item with the matching code wins
 *
 * @param items       - List items from the remote API response
 * @param merged      - Merged CLI snapshot from the pipeline context
 */
export declare function enrichAppListItemsWithMergedSelection(items: Record<string, unknown>[], merged: MergedCliSnapshot | undefined): void;
