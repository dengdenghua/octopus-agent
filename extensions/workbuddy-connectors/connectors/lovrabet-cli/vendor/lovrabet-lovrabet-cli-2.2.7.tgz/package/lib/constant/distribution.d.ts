/**
 * @fileoverview Public distribution constants.
 *
 * Values are derived from `product.ts`, which is the single customization
 * surface for downstream forks.
 */
/** Published npm package name used by `lovrabet update`. */
export declare const LOVRABET_NPM_PACKAGE_NAME: "@lovrabet/lovrabet-cli";
/** Published CLI Built-in Skill source consumed by `npx skills add`. */
export declare const LOVRABET_SKILL_SOURCE: "lovrabet/lovrabet-cli";
/** Npm registry base URL used only for dist-tag resolution. */
export declare const NPM_REGISTRY_BASE_URL: "https://registry.npmjs.org";
