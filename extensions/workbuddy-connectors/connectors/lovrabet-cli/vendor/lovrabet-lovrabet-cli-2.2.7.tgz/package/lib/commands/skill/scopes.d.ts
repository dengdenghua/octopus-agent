import type { RuntimeSkillScope } from "../../skills/runtime-skill-sync.js";
export type SyncRuntimeScope = Extract<RuntimeSkillScope, "personal" | "company">;
export type SkillListScope = "all" | "personal" | "company";
/** Normalizes the install scope flag into the runtime scopes to sync. */
export declare function normalizeSyncScopes(value: string): SyncRuntimeScope[];
/** Normalizes the list scope flag into a supported list scope. */
export declare function normalizeListScope(value: string): SkillListScope;
/** Checks whether a list response should include one target scope. */
export declare function shouldListScope(scope: SkillListScope, target: "personal" | "company"): boolean;
/** Converts a local list scope into runtime Skill cache scopes. */
export declare function listScopeToRuntimeScopes(scope: SkillListScope): RuntimeSkillScope[];
/** Converts the list scope into the API scope parameter. */
export declare function listScopeToRemoteScope(scope: SkillListScope): "personal" | "company" | "all";
