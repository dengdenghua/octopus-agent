/**
 * @fileoverview `bff exec` command — executes a Backend Function script by function name.
 *
 * Why `risk: "read"`: Backend Function script execution is a runtime query. Whether the
 * script reads or writes data is determined by the script itself; the CLI
 * cannot know ahead of time. Using `"read"` avoids prompting for `--yes`
 * on every invocation. If the script performs writes, its Studio definition
 * governs those actions.
 *
 * Why `risk: "read"` rather than `"write"`: scripts that only read are the
 * common case. Requiring `--yes` for all executions would be too intrusive.
 * Scripts that perform high-risk operations are controlled at the Studio
 * permission level, not at the CLI invocation level.
 *
 * Design decision: timing is reported back to the user (`elapsed` in ms).
 * This helps developers tune performance without requiring verbose flags.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const bffExec: CommandDefinition;
