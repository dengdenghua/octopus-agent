/**
 * @fileoverview Runtime app eligibility helpers.
 *
 * The platform app directory can return apps that are visible to the current AK
 * but not published yet. Runtime CLI commands must only treat published apps as
 * AI-accessible business data targets.
 */
import type { RemoteAppItem } from "../../commands/app/remote-source.js";
type AppPublishStatusLike = Pick<RemoteAppItem, "appPublishStatus">;
export declare function normalizeAppPublishStatus(status: unknown): string | null;
export declare function isRuntimeAccessibleApp(item: AppPublishStatusLike): boolean;
export declare function filterRuntimeAccessibleApps<T extends AppPublishStatusLike>(items: T[]): T[];
export declare function findAppByName(items: RemoteAppItem[], name: string): RemoteAppItem | undefined;
export declare function findAppByCode(items: RemoteAppItem[], appCode: string): RemoteAppItem | undefined;
export declare function runtimeInaccessibleAppError(item: RemoteAppItem, selector: string): import("../../errors.js").CliError;
export {};
