export declare const METADATA_FILE = "lovrabet.skill.json";
export declare const SKILL_FILE = "SKILL.md";
export declare const IGNORED_FILE_NAMES: Set<string>;
export declare const IGNORED_DIR_NAMES: Set<string>;
