import type { RuntimeSkillScope, SkillSyncPaths, SkillSyncPathsOptions } from "./types.js";
/** Resolves all local roots involved in runtime Skill cache and link sync. */
export declare function resolveSkillSyncPaths(options?: SkillSyncPathsOptions): SkillSyncPaths;
/** Returns all user-level agent Skill roots that should receive runtime Skill links. */
export declare function runtimeAgentSkillRoots(paths: SkillSyncPaths): string[];
/** Returns the access-key partitioned runtime Skill cache root. */
export declare function getRuntimeSkillCacheRoot(env: "production" | "development" | "daily", accessKey: string, options?: SkillSyncPathsOptions): string;
/** Returns the managed cache directory for one app, scope, and skill code. */
export declare function getRuntimeSkillDir(env: "production" | "development" | "daily", accessKey: string, appCode: string, scope: RuntimeSkillScope, skillCode: string, options?: SkillSyncPathsOptions): string;
/** Validates a user or backend value before using it as one path segment. */
export declare function safePathSegment(value: string, label?: string): string;
