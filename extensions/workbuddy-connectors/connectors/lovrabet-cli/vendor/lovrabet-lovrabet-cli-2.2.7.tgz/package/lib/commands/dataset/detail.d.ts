/**
 * @fileoverview `dataset detail` command — inspects a dataset's fields, relations, and operations.
 *
 * Why normalization functions: the Lovrabet API returns inconsistent shapes
 * across dataset versions (v1 vs v2) and between different API versions.
 * Normalizing here gives callers a stable, documented output shape regardless
 * of which API version responded.
 *
 * Key normalizations performed:
 * - `normalizeField`: v1 stores fields in `data.properties` with `extend` JSON;
 *   v2 stores them in `data.fields` with direct properties. This function
 *   abstracts the version difference.
 * - `normalizeOperationEntry`: API returns operation configs with nested
 *   JSON strings for `requestBody`/`responseBody`. This function parses them.
 * - `summarizeDbtable`: picks a curated subset of db fields for display.
 *
 * Why `stats` is included in the output: callers (e.g. automated tests)
 * benefit from knowing how many fields and operations a dataset has without
 * having to count them from the arrays themselves.
 *
 * Design decision: `extendParsed` is included when present (v1 datasets store
 * arbitrary metadata in `detail.extend`). This preserves debug information
 * without cluttering the default output for v2 datasets.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const datasetDetail: CommandDefinition;
