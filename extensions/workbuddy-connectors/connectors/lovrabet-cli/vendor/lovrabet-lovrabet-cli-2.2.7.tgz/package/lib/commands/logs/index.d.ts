/**
 * @fileoverview `logs` command definition — show command history.
 *
 * Why a separate logger module: Lovrabet Runtime CLI uses Winston to write
 * structured JSON logs to `.lovrabet-runtime.log`. The `logs` command provides
 * a human-readable view of this file (formatted output with icons, timestamps)
 * as a read-only diagnostic view.
 *
 * Why `printLogs` is a standalone function: it formats the raw log entries
 * into a human-readable report. Keeping it separate from the command definition
 * makes it easier to test the formatting logic independently.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare const logsDefinitions: CommandDefinition[];
