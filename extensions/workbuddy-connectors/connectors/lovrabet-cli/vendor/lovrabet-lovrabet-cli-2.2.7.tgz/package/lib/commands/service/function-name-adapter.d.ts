import type { NormalizedServiceTree, ServiceTreeManifest, ServiceTreeValidationIssue } from "@lovrabet/cli-framework";
interface LegacyFrameworkAdaptation {
    manifest: ServiceTreeManifest;
    errors: ServiceTreeValidationIssue[];
}
/**
 * Keeps functionName as the runtime CLI contract while adapting to the current
 * cli-framework release, whose Service Tree model still calls this field scriptName.
 */
export declare function adaptServiceTreeManifestForLegacyFramework(input: unknown): LegacyFrameworkAdaptation;
export declare function toPublicServiceTreeTarget(target: Record<string, unknown>): Record<string, unknown>;
export declare function toPublicNormalizedServiceTree(tree: NormalizedServiceTree): Record<string, unknown>;
export {};
