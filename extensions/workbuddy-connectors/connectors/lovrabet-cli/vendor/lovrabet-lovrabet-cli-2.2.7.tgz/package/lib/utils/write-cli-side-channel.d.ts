/**
 * 声明式命令中「旁路」输出：进度、路径列表、交互前提示等。
 * 写入 stderr，避免与 stdout 上的 JSON/compress 信封混在一起；
 * 语义上不是错误（与 console.error 区分），仅供人机可读侧道信息。
 */
export declare function writeCliSideChannelLine(line: string): void;
