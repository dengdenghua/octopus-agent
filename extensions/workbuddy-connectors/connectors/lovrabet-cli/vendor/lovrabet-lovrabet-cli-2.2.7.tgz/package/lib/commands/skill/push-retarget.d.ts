import type { RuntimeSkillItem, RuntimeSkillUpsertInput } from "../../core/api-client.js";
import type { RuntimeSkillMetadata } from "../../skills/runtime-skill-sync.js";
import type { SkillValidationIssue } from "./validate.js";
/** Keeps target-app remote metadata as the baseline when explicit appCode retarget updates an existing Skill. */
export declare function withRetargetExistingMetadata(input: RuntimeSkillUpsertInput, existing: RuntimeSkillItem, options?: {
    preferInputSkillName?: boolean;
}): RuntimeSkillUpsertInput;
/** Builds the user-facing warning emitted after an explicit appCode retarget succeeds. */
export declare function buildRetargetWarning(metadata: RuntimeSkillMetadata | undefined, targetAppCode: string): SkillValidationIssue[];
