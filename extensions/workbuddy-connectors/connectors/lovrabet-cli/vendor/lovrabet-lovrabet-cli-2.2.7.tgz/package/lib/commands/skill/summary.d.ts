import type { RuntimeSkillItem } from "../../core/api-client.js";
import type { LocalRuntimeSkillItem } from "../../skills/runtime-skill-sync.js";
/** Converts a remote runtime Skill item into command output shape. */
export declare function summarizeRuntimeSkill(item: RuntimeSkillItem): Record<string, unknown>;
/** Converts a locally managed runtime Skill item into command output shape. */
export declare function summarizeLocalRuntimeSkill(item: LocalRuntimeSkillItem): Record<string, unknown>;
