import type { NotificationChannelType } from "../../core/api-client.js";
import type { RuntimeContext } from "../../framework/types.js";
export declare const NOTIFICATION_CHANNEL_TYPES: NotificationChannelType[];
export declare function readNotificationChannelType(ctx: RuntimeContext): NotificationChannelType;
export declare function projectNotificationListConfig(item: unknown, index: number): {
    id: string | number | null;
    configCode: string;
    configName: string;
    channelType: string;
    description: string | null;
    createTime: string | null;
    updateTime: string | null;
};
