/**
 * @fileoverview Environment (env) constants.
 *
 * Why a dedicated module: the `env` value flows through the entire CLI pipeline —
 * config resolution, API domain selection, SDK initialization, and output formatting.
 * Centralizing valid values here prevents `isProduction()` / `isDaily()` / `isDev()`
 * from diverging in their interpretation of what constitutes each environment.
 *
 * Design decision: `"online"` is accepted and silently normalized to `"production"`.
 * This is a backward-compatibility bridge for older config files that used `online`
 * before the team standardized on `"production"`. The normalization happens at read
 * time so the rest of the codebase only sees the canonical values.
 */
import { RUNTIME_ENV_VALUES } from "../constant/env.js";
import type { OutputFormat, Risk } from "../framework/types.js";
/**
 * Default name for a newly created app profile when no name is provided.
 * `"main"` was chosen over `default` or `primary` because it is unambiguous in
 * multi-app configs and short enough to keep the config JSON tidy.
 */
export declare const DEFAULT_APP_PROFILE_NAME = "main";
/**
 * Baseline defaults for a new or minimally-configured CLI.
 *
 * Why `riskLevel: "write"` instead of `"read"`: Lovrabet Runtime CLI is primarily
 * a data manipulation tool — the most common use cases (sql exec, data create/update/delete)
 * require write access. Setting the default to `"write"` avoids forcing users to
 * configure the risk ceiling before performing routine operations.
 *
 * Why `format: "compress"`: CLI output is most often piped to `jq` or parsed by
 * scripts. Single-line JSON (compress) is the most machine-friendly default.
 * Interactive users can opt into `pretty` or pass `--format pretty` explicitly.
 */
export declare const DEFAULT_CONFIG_VALUES: {
    env: (typeof RUNTIME_ENV_VALUES)[number];
    format: OutputFormat;
    locale: string;
    riskLevel: Risk;
};
/**
 * Alias for `DEFAULT_CONFIG_VALUES.format` — used by `build-all-flags.ts` to set
 * the default for the `--format` flag. Kept as a separate export so callers don't
 * accidentally couple to other defaults.
 */
export declare const DEFAULT_COMMAND_OUTPUT_FORMAT: OutputFormat;
