/**
 * @fileoverview Configuration field schema — the single source of truth for all
 * configurable keys in `.lovrabet.json`.
 *
 * Why a schema module: previously, config key validation, enum lists, defaults, and
 * flag definitions were scattered across `config/definitions.ts`, `init.ts`, and
 * `buildConfig()`. Adding a new config key required editing three files. Centralizing
 * everything here means:
 * - A new key needs one entry in `CONFIG_FIELD_SCHEMAS`
 * - `getConfigEnumValues()`, `getConfigDefaultValue()`, `getTopLevelConfigKeyList()` etc.
 *   all derive from the same data — no drift
 * - Help text for `config get/set` commands can iterate over this schema directly
 *
 * Design decision: runtime CLI keeps platform app discovery remote/cache-based,
 * but local configs may define `apps.<alias>.appcode` as stable operator aliases.
 * `config set` targets scalar top-level fields plus the explicit
 * `apps.<alias>.appcode` local-alias path.
 */
import { RUNTIME_ENV_VALUES } from "../constant/env.js";
export type RuntimeEnv = (typeof RUNTIME_ENV_VALUES)[number];
/** All configuration field names recognized by the runtime CLI. */
type ConfigFieldName = "env" | "format" | "pageSize" | "apiDomain" | "userDomain" | "runtimeDomain" | "skillHubDomain" | "accessKey" | "riskLevel" | "locale";
/**
 * Schema for a single configuration field.
 *
 * Why `cliSettableTopLevel` and `cliSettableAppProfile` are separate from
 * `topLevel` and `appProfile`: the first pair indicates whether the CLI
 * commands (`config set`) can modify the field. Some fields exist in the config
 * file for other reasons (e.g. imported from `.rabetbase.json`) but the runtime
 * CLI should not expose them as settable.
 */
interface ConfigFieldSchema {
    description?: string;
    /** Can appear at the root of the config file. */
    topLevel?: boolean;
    /** CLI `config set` can write this at the top level. */
    cliSettableTopLevel?: boolean;
    /** Permitted values (used for enum validation and --help hints). */
    enumValues?: readonly string[];
    /** Default value when absent from the config. */
    defaultValue?: string | number | boolean;
    /** Can be imported from `.rabetbase.json`. */
    importable?: boolean;
    /**
     * When true, the field is present only for compatibility with older configs.
     * It is shown in `config list` but the runtime CLI does not act on it.
     */
    legacyCompatOnly?: boolean;
}
/**
 * Schema definitions for every recognized configuration field.
 *
 * All CLI-settable fields are top-level. This keeps the runtime config aligned
 * with the current architecture: platform app list is remote/cache-based, and
 * local config stores user intent such as `defaultApp`, local app aliases,
 * `appcode`, auth, environment, output, and safety preferences.
 */
export declare const CONFIG_FIELD_SCHEMAS: Record<ConfigFieldName, ConfigFieldSchema>;
/** Set of top-level CLI-settable keys. */
export declare const TOP_LEVEL_CONFIG_KEYS: Set<string>;
/** Map of field name → permitted enum values (only for fields with `enumValues`). */
export declare const CONFIG_ENUM_VALUES: Record<string, string[]>;
/** All fields that can be imported from `.rabetbase.json`. */
export declare const IMPORTABLE_RUNTIME_CONFIG_KEYS: ConfigFieldName[];
/** @returns The schema for a given field name, or undefined if unrecognized. */
export declare function getConfigFieldSchema(key: string): ConfigFieldSchema | undefined;
/** @returns The enum values for a field (only present for fields with `enumValues`). */
export declare function getConfigEnumValues(key: string): readonly string[] | undefined;
/** @returns The default value for a field, or undefined if none is declared. */
export declare function getConfigDefaultValue(key: string): string | number | boolean | undefined;
/** @returns true if the key is a recognized top-level config field. */
export declare function isTopLevelConfigKey(key: string): boolean;
/**
 * @returns true if the field exists only for backward compatibility.
 * Legacy fields are readable but not acted upon by the runtime CLI.
 */
export declare function isLegacyCompatConfigKey(key: string): boolean;
/** @returns All recognized top-level config keys as an array. */
export declare function getTopLevelConfigKeyList(): string[];
/** Formats a list of config keys as a comma-separated string for use in help text. */
export declare function formatConfigKeyList(keys: Iterable<string>): string;
/** Human-readable summary of all top-level keys for use in `config set --help`. */
export declare function getTopLevelConfigKeySummary(): string;
/**
 * Description text shown in `config set` and `config delete` help.
 * Tells users which keys are valid at top level and for local app aliases.
 */
export declare function getConfigCommandKeyDescription(): string;
/**
 * Maps flag names (as written in CLI flags) to the internal config key name.
 *
 * Why this exists: users naturally write `--accesskey` (camelCase) or `--pagesize`
 * rather than `--accessKey` and `--pageSize`. This map normalizes both forms to
 * the canonical config key name before writing to the JSON.
 *
 * Design decision: snake_case forms (`accesskey`, `pagesize`) are also included
 * as aliases because AI-generated commands frequently use snake_case flag names.
 */
/**
 * Builds the field map for `app list`'s pretty output.
 * Shows each app's effective configuration alongside its name and appcode.
 *
 * Why null rather than undefined: the pretty formatter distinguishes "not set"
 * (shown as `null`) from "inherits from top level" (shown differently in doctor).
 * Using `null` explicitly communicates the intentional absence of a value.
 */
export declare function buildAppProfileListFields(fallbackEnv: string): Record<string, unknown>;
export {};
