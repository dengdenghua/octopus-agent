/**
 * @fileoverview `api-doc` command group — stable runtime API discovery docs.
 *
 * Ownership note: this is a compact CLI mirror of RuntimeAgent's
 * capability-owned `src/runtime-agent/api-doc` registry. Keep the command
 * surface typed and read-only; do not add a generic fetch command here.
 */
import type { CommandDefinition } from "../../framework/types.js";
export interface RuntimeApiDocEntry {
    code: string;
    category: string;
    method: "GET" | "POST" | "PUT" | "DELETE";
    path: string;
    summary: string;
    whenToUse: string;
}
export interface RuntimeApiDocDetail extends RuntimeApiDocEntry {
    title: string;
    pathParams: Array<{
        name: string;
        description: string;
    }>;
    queryParams: Array<{
        name: string;
        description: string;
    }>;
    bodySchema: string;
    responseHighlights: string[];
    examples: string[];
    notes: string[];
    markdown: string;
}
export declare function listApiDocEntries(filters?: {
    category?: string;
    keyword?: string;
}): RuntimeApiDocEntry[];
export declare function getApiDocDetail(code: string): RuntimeApiDocDetail;
export declare const apiDocDefinitions: CommandDefinition[];
