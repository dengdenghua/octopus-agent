/**
 * @fileoverview Authentication mode constants.
 *
 * Why a dedicated module: Lovrabet Runtime CLI only supports `client-ak` (AccessKey)
 * authentication. Defining `AUTH_MODE.ClientAk` as a typed constant ensures:
 * 1. Every place that checks or sets the auth mode compares against the same string.
 * 2. If a new auth mode is added in the future, callers using `AUTH_MODE.ClientAk`
 *    will continue to compile correctly, and only new call sites need updating.
 * 3. `AuthMode` as a type alias makes it easy to narrow and validate values.
 */
/**
 * Auth mode supported by Lovrabet Runtime CLI.
 *
 * Why not a union type inlined everywhere: if auth modes expand (e.g. `"user-session"`),
 * we only add one entry here. Call sites using `AUTH_MODE.ClientAk` are already
 * written to be swapped out if needed.
 */
export declare const AUTH_MODE: {
    /**
     * Client AccessKey authentication. The AK is passed as the `X-User-AK` header
     * in every API request. No session cookie or OAuth token is used.
     */
    readonly ClientAk: "client-ak";
};
/** Narrows a raw value to the known auth mode type. */
export type AuthMode = (typeof AUTH_MODE)[keyof typeof AUTH_MODE];
/** Type guard — returns `true` if the value is a recognized auth mode. */
export declare function isAuthMode(v: unknown): v is AuthMode;
