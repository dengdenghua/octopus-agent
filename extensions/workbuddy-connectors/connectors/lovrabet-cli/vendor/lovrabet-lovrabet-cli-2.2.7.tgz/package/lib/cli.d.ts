#!/usr/bin/env node
/**
 * @fileoverview CLI entry point — parses input and dispatches to the framework runner.
 *
 * Why a top-level IIFE is avoided: `async function main()` is called via
 * `void main().catch(handleError)`. This pattern is equivalent to a top-level
 * `await` but avoids Node's "unhandled promise rejection in top-level await"
 * behavior when the process is long-lived (interactive prompts).
 *
 * Why `isUserCancellation` checks `ExitPromptError` by name (not import):
 * `@inquirer/prompts` throws `ExitPromptError` during Ctrl+C. Checking by
 * `err.name` avoids a hard import-time dependency on the inquirer package
 * version in this file. The error boundary handles it generically.
 *
 * PreParse phase: `correctFlags` is called before command dispatch to fix
 * common AI-agent input mistakes (kebab-case flags, sticky values like
 * `--limit100`). Corrections are printed to stderr so they don't pollute
 * structured output. PreParse failures are silent (best-effort).
 *
 */
export {};
