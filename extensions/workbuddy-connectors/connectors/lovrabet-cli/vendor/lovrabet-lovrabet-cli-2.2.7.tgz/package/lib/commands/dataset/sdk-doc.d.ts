/**
 * @fileoverview `dataset sdk-doc` command — fetch dataset SDK usage markdown.
 */
import type { CommandDefinition } from "../../framework/types.js";
export declare function formatDatasetSdkMarkdown(markdown: string | undefined): string;
export declare const datasetSdkDoc: CommandDefinition;
