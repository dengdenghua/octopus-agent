import type { CommandDefinition } from "../../framework/types.js";
export declare const roleUserAdd: CommandDefinition;
