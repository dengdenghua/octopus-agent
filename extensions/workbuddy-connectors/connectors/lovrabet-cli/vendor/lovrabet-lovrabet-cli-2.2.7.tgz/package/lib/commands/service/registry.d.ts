import { type NormalizedServiceTree, type ServiceTreeManifest, type ServiceTreeValidationReport } from "@lovrabet/cli-framework";
export declare const SERVICE_REGISTRY_SCHEMA_VERSION = 1;
export declare const SERVICE_REGISTRY_FILE_NAME = "service.json";
export interface ServiceSourceInfo {
    type: "file";
    path: string;
    hash: string;
}
export interface LocalServiceEntry {
    serviceCode: string;
    version: string;
    importedAt: string;
    source: ServiceSourceInfo;
    manifest: ServiceTreeManifest;
    normalizedManifest: NormalizedServiceTree;
}
export interface LocalServiceRegistry {
    schemaVersion: 1;
    updatedAt?: string;
    services: LocalServiceEntry[];
}
export interface ServiceRegistryOptions {
    homeDir?: string;
    now?: () => Date;
}
export interface LoadServiceManifestResult {
    filePath: string;
    hash: string;
    kind: "manifest" | "registry";
    manifest: ServiceTreeManifest;
    report: ServiceTreeValidationReport;
    normalizedManifest?: NormalizedServiceTree;
    manifests: LoadedServiceManifest[];
}
export interface LoadedServiceManifest {
    manifest: ServiceTreeManifest;
    report: ServiceTreeValidationReport;
    normalizedManifest?: NormalizedServiceTree;
    sourceHash: string;
    registryIndex?: number;
    registryServiceCode?: string;
}
export interface ImportServiceResult {
    registryPath: string;
    entry: LocalServiceEntry;
    replaced: boolean;
    entries: LocalServiceEntry[];
    imported: number;
    updated: number;
    serviceCount: number;
}
export interface ExportServiceResult {
    registryPath: string;
    filePath: string;
    entry: LocalServiceEntry;
}
export interface RemoveServiceResult {
    registryPath: string;
    entry: LocalServiceEntry;
    serviceCount: number;
}
export interface ServiceRegistrySummaryCommand {
    path: string;
    description?: string;
    risk: string;
    targetKind?: string;
    targetCommand?: string;
}
export interface ServiceRegistrySummaryService {
    serviceCode: string;
    name?: string;
    description?: string;
    version: string;
    importedAt: string;
    source: ServiceSourceInfo;
    commandCount: number;
    commands: ServiceRegistrySummaryCommand[];
}
export interface ServiceRegistryInspection {
    registryPath: string;
    exists: boolean;
    status: "missing" | "empty" | "ok" | "invalid";
    schemaVersion?: number;
    updatedAt?: string;
    serviceCount: number;
    commandCount: number;
    services: ServiceRegistrySummaryService[];
    message?: string;
}
export declare function getServiceRegistryPath(options?: ServiceRegistryOptions): string;
export declare function emptyServiceRegistry(): LocalServiceRegistry;
export declare function readServiceRegistry(options?: ServiceRegistryOptions): LocalServiceRegistry;
export declare function writeServiceRegistry(registry: LocalServiceRegistry, options?: ServiceRegistryOptions): string;
export declare function loadServiceManifestFromFile(filePath: string): LoadServiceManifestResult;
export declare function importServiceManifest(filePath: string, options?: ServiceRegistryOptions): ImportServiceResult;
export declare function exportServiceManifest(serviceCode: string, filePath: string, options?: ServiceRegistryOptions): ExportServiceResult;
export declare function removeServiceManifest(serviceCode: string, options?: ServiceRegistryOptions): RemoveServiceResult;
export declare function listLocalServices(options?: ServiceRegistryOptions): LocalServiceEntry[];
export declare function getLocalServiceEntry(serviceCode: string, options?: ServiceRegistryOptions): LocalServiceEntry | undefined;
export declare function listLocalServiceTrees(options?: ServiceRegistryOptions): NormalizedServiceTree[];
export declare function inspectServiceRegistry(options?: ServiceRegistryOptions): ServiceRegistryInspection;
export declare function formatValidationFailure(report: ServiceTreeValidationReport): string;
