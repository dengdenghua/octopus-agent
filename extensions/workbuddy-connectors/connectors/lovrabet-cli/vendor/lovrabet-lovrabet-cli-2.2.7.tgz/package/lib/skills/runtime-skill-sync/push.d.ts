import type { PushDirectoryPayload, RuntimeSkillItem, RuntimeSkillMetadata, RuntimeSkillScope } from "./types.js";
export interface PushDirectoryIdentity {
    dir: string;
    skillCode: string;
    metadata?: RuntimeSkillMetadata;
}
export interface PushDirectoryIdentityOptions {
    allowAppCodeRetarget?: boolean;
    ignoreInvalidMetadata?: boolean;
    ignoreMetadataAppCodeMismatch?: boolean;
    ignoreMetadataSkillCode?: boolean;
}
interface ReadPushDirectoryOptions extends PushDirectoryIdentityOptions {
    excludedFilePaths?: readonly string[];
    ignoreMetadataForPayload?: boolean;
    ignoreMetadataScope?: boolean;
    targetScope?: Extract<RuntimeSkillScope, "personal" | "company">;
}
/** Resolves a local push directory and its target skillCode without enforcing scope. */
export declare function resolvePushDirectoryIdentity(dir: string, appCode: string, options?: PushDirectoryIdentityOptions): PushDirectoryIdentity;
/** Reads a local Skill directory and prepares the upsert payload for push. */
export declare function readPushDirectory(dir: string, appCode: string, options?: ReadPushDirectoryOptions): PushDirectoryPayload;
/** Refreshes local metadata from a remote Skill before deciding whether push can update it. */
export declare function refreshPushDirectoryMetadataFromRemote(dir: string, remote: RuntimeSkillItem, appCode: string, options?: {
    refreshedAt?: string;
}): void;
/** Records backend save evidence back into a pushed local Skill directory. */
export declare function recordPushedRuntimeSkill(dir: string, saved: RuntimeSkillItem, appCode: string, options?: {
    scope?: RuntimeSkillScope;
    pushedAt?: string;
}): void;
/** Derives the runtime skillCode from a directory name, dropping app prefix if present. */
export declare function deriveSkillCodeFromDirectory(dir: string, appCode: string): string;
export {};
