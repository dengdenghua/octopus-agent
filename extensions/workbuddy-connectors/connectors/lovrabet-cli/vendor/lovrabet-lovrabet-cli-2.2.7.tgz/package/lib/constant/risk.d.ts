/**
 * @fileoverview Risk level enumeration.
 *
 * These values are the legal values for the `riskLevel` config field and must
 * match the `Risk` type from `@lovrabet/cli-framework`. This module is the
 * canonical declaration site so callers don't scatter the literal values.
 *
 * Why `as const` makes a difference: using `as const` creates a `readonly`
 * tuple type for `RISK_LEVEL_VALUES`, which TypeScript uses to infer the exact
 * type `readonly ["read", "write", "high-risk-write"]`. Any downstream code
 * that types a field as `(typeof RISK_LEVEL_VALUES)[number]` gets the precise
 * union type rather than `string`.
 */
export declare const RISK_LEVEL_VALUES: readonly ["read", "write", "high-risk-write"];
