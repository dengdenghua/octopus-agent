#!/usr/bin/env node
import { existsSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const entry = join(root, "lib", "postinstall.js");

if (!existsSync(entry)) {
  if (existsSync(join(root, "src", "postinstall.ts"))) {
    console.log("Skipping Lovrabet Built-in Skill postinstall in an unbuilt source checkout.");
  } else {
    console.error("[BUILTIN_SKILL_INSTALL_SOURCE_MISSING] Missing lib/postinstall.js");
    process.exitCode = 1;
  }
} else {
  try {
    const { runPostinstall } = await import(pathToFileURL(entry).href);
    await runPostinstall();
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = 1;
  }
}
