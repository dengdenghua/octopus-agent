#!/usr/bin/env node
// zsxq-cli entry point — locates the platform-specific binary in the
// installed optionalDependency sub-package and spawns it directly.
"use strict";

const { spawnSync } = require("child_process");
const path = require("path");

const PLATFORM_MAP = {
  "darwin-arm64": "@zsxq/cli-darwin-arm64",
  "darwin-x64":   "@zsxq/cli-darwin-x64",
  "linux-x64":    "@zsxq/cli-linux-x64",
  "linux-arm64":  "@zsxq/cli-linux-arm64",
  "win32-x64":    "@zsxq/cli-win32-x64",
  "win32-arm64":  "@zsxq/cli-win32-arm64",
};

const platform = `${process.platform}-${process.arch}`;
const pkgName = PLATFORM_MAP[platform];

if (!pkgName) {
  process.stderr.write(
    `[zsxq-cli] Unsupported platform: ${platform}\n` +
    `[zsxq-cli] Supported: ${Object.keys(PLATFORM_MAP).join(", ")}\n`
  );
  process.exit(1);
}

const binName = process.platform === "win32" ? "zsxq-cli.exe" : "zsxq-cli";

let bin;
try {
  const pkgJson = require.resolve(`${pkgName}/package.json`);
  bin = path.join(path.dirname(pkgJson), "bin", binName);
} catch {
  process.stderr.write(
    `[zsxq-cli] Platform package ${pkgName} is not installed.\n` +
    `[zsxq-cli] If you used --no-optional or --ignore-scripts, retry with:\n` +
    `[zsxq-cli]   npm install ${pkgName}\n`
  );
  process.exit(1);
}

const result = spawnSync(bin, process.argv.slice(2), { stdio: "inherit" });
if (result.error) {
  process.stderr.write(`[zsxq-cli] Failed to launch binary: ${result.error.message}\n`);
  process.exit(1);
}
process.exit(result.status ?? 1);
