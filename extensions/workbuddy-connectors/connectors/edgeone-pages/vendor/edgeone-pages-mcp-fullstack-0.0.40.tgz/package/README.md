# EdgeOne Makers MCP

An MCP service for deploying full-stack projects to EdgeOne Makers and obtaining publicly accessible URLs.

## Requirements

- Node.js 18 or higher

## MCP Configuration

```jsonc
// Tencent Cloud International (Default)
{
  "mcpServers": {
    "edgeone-makers-mcp-server": {
      "timeout": 600,
      "command": "npx",
      "args": ["@edgeone/makers-mcp@latest"],
      "env": {
        // Optional. 
        // If provided, skips the browser login flow.
        // How to obtain your API token: 
        // https://pages.edgeone.ai/document/api-token
        "EDGEONE_PAGES_API_TOKEN": "",
        // Optional.
        // If provided, uses this as the project name instead of auto-generating.
        "EDGEONE_PAGES_PROJECT_NAME": ""
      }
    }
  }
}

// Tencent Cloud China
{
  "mcpServers": {
    "edgeone-makers-mcp-server": {
      "timeout": 600,
      "command": "npx",
      "args": ["@edgeone/makers-mcp@latest", "--region", "china"],
      "env": {
        "EDGEONE_PAGES_API_TOKEN": "",
        "EDGEONE_PAGES_PROJECT_NAME": ""
      }
    }
  }
}
```

## How It Works

1. **Authentication**: Uses `EDGEONE_PAGES_API_TOKEN` if provided, otherwise opens browser for OAuth login (one-time).
2. **Project Name**: Automatically resolved — no user interaction needed:
   - Uses `EDGEONE_PAGES_PROJECT_NAME` env var if set
   - Reuses cached project name for the same workspace
   - Otherwise auto-generates from the workspace directory name
3. **Deployment**: Uploads and deploys, returns the live URL.

## Quick HTML Preview

For quickly deploying a single HTML page for preview, use the Streaming HTTP MCP Server (no local installation required):

```json
{
  "mcpServers": {
    "edgeone-makers-mcp-server": {
      "url": "https://mcp-on-edge.edgeone.site/mcp-server"
    }
  }
}
```

Source code: https://github.com/TencentEdgeOne/self-hosted-pages-mcp

## License

MIT
