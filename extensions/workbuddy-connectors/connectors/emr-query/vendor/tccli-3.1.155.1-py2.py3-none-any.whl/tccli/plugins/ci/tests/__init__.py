# Tests for CI plugin
