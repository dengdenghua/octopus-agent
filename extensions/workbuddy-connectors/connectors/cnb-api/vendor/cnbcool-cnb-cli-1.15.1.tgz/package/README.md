# CNB Skills

CNB 平台技能集合，支持多种主流 Agent，通过 `npx skills` 一键安装。

## 快速开始

```bash
# 推荐：全局安装所有 Skills，对所有 Agent 生效
npx skills add https://cnb.cool/cnb/skills/cnb-skill.git -g -y
```

安装后所有 CNB Skills 即可在任意 Agent 中使用。

## 支持的 Agent

| Agent | `--agent` |
| --- | --- |
| CodeBuddy | `codebuddy` |
| Claude Code | `claude-code` |
| Codex | `codex` |
| Cursor | `cursor` |
| Gemini CLI | `gemini-cli` |
| OpenCode | `opencode` |
| Qwen Code | `qwen-code` |
| Windsurf | `windsurf` |

## 更多安装方式

### 安装到指定 Agent

```bash
# 安装到 CodeBuddy（不指定 --agent 时会自动检测并提示选择）
npx skills add https://cnb.cool/cnb/skills/cnb-skill.git --agent codebuddy -y

# 同时安装到多个 Agent
npx skills add https://cnb.cool/cnb/skills/cnb-skill.git --agent codebuddy --agent claude-code -y

# 安装到所有支持的 Agent
npx skills add https://cnb.cool/cnb/skills/cnb-skill.git --agent '*' -y
```

### 只安装指定的 Skill

```bash
# 查看仓库中可安装的 Skill
npx skills add https://cnb.cool/cnb/skills/cnb-skill.git --list

# 安装指定 Skill
npx skills add https://cnb.cool/cnb/skills/cnb-skill.git --skill cnb-api --agent codebuddy -y
```

---

## 前置依赖

使用 `npx skills` 需要安装 cnb-cli：

```bash
# macOS / Linux
curl -fsSL https://cnb.cool/cnb/skills/cnb-skill/-/git/raw/main/install.sh | sh

# Windows PowerShell
irm https://cnb.cool/cnb/skills/cnb-skill/-/git/raw/main/install.ps1 | iex

# npm
npm install @cnbcool/cnb-cli -g
```

> 也可前往 [Releases](https://cnb.cool/cnb/skills/cnb-skill/-/releases) 手动下载。

## AI 安装提示词

将以下内容发送给 Agent 即可自动安装；按需替换 `--agent` 参数：

```
npm install @cnbcool/cnb-cli -g
npm install skills -g
npx skills add https://cnb.cool/cnb/skills/cnb-skill.git --agent codebuddy -y --copy
```

## 环境变量

| 变量 | 说明 | 必填 |
| --- | --- | --- |
| `CNB_TOKEN` | 访问凭证 | 是 |
| `CNB_API_ENDPOINT` | API 端点，如 `https://api.cnb.cool` | 是 |
| `CNB_BRANCH` | 默认分支 | 否 |

## cnb git-credential

`cnb git-credential` 可作为 Git Credential Helper，为 HTTPS 操作自动提供 CNB 访问凭据。

### 1. 登录

```bash
cnb login
```

### 2. 配置 Git

```bash
git config --global credential.https://cnb.cool.helper ""
git config --global credential.https://cnb.cool.helper "!cnb git-credential"
git config --global credential.https://cnb.cool.useHttpPath true
```

### 3. 使用 HTTPS 操作

```bash
git clone https://cnb.cool/<org>/<repo>.git
cd <repo>
git pull
git push
```

> 凭据来源优先级：CodeBuddy 环境 token → `CNB_TOKEN` 环境变量 → `~/.cnb/token` 登录凭据。
