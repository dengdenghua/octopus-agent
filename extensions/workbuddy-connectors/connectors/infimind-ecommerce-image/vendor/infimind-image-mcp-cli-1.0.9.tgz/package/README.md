# Ecommerce MCP CLI

MCP (Model Context Protocol) CLI 工具，用于将 Ecommerce Generator 服务连接到 Claude Desktop 等 AI 客户端。

## 安装

### 全局安装（推荐）

```bash
npm install -g @infimind/image-mcp-cli
# 或
pnpm add -g @infimind/image-mcp-cli
# 或
yarn global add @infimind/image-mcp-cli
```

### 使用 npx（无需安装）

```bash
npx -y @infimind/image-mcp-cli@1.0.6
```

## 使用方法

### 1. 获取 MCP Token

在 Ecommerce Generator 网站的"MCP Token"页面创建一个 Token。

### 2. 设置环境变量

```bash
export MCP_TOKEN=your-token-here
export API_URL=http://localhost:3000  # 可选，默认为 http://localhost:3000
```

### 3. 启动服务

```bash
ecommerce-mcp
```

### 4. 配置 Claude Desktop

在 Claude Desktop 配置文件中添加：

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "ecommerce-generator": {
      "command": "npx",
      "args": ["-y", "@infimind/image-mcp-cli@1.0.6"],
      "env": {
        "MCP_TOKEN": "your-token-here",
        "API_URL": "http://localhost:3000"
      }
    }
  }
}
```

### 5. 重启 Claude Desktop

配置完成后，重启 Claude Desktop 即可使用 MCP 服务。

## 环境变量

| 变量名 | 必需 | 默认值 | 说明 |
|--------|------|--------|------|
| `MCP_TOKEN` | 是 | - | MCP 认证 Token（从网站获取） |
| `API_URL` | 否 | `http://localhost:3000` | Ecommerce Generator API 地址 |
| `DEBUG` | 否 | - | 启用调试日志 |

## MCP Tools

当前支持的 MCP Tools：

| Tool 名称 | 描述 | 参数 |
|-----------|------|------|
| `get_user_credits` | 获取用户积分余额 | 无 |
| `get_user_products` | 获取用户产品列表 | `limit` (可选，默认 10) |
| `get_user_tasks` | 获取用户任务列表 | `status`、`taskId`、`taskType`、`limit`（均可选） |
| `create_smart_refine_task` | 创建智能精修任务 | 图片、提示词及生成参数 |
| `create_detail_page_task` | 创建商品详情页任务 | 商品图、类目、风格或参考图及生成参数 |
| `create_koc_collage_task` | 创建 KOC 种草拼图任务 | 商品图、商品名及拼图参数 |
| `prepare_koc_collage_task` | 生成 KOC 候选方案 | 商品图、商品名及候选数量 |
| `submit_koc_collage_task` | 提交选定的 KOC 候选方案 | `taskId`、`selectedPlanIndexes` |

## 开发

### 构建

```bash
npm run build
# 或
pnpm build
```

### 本地测试

```bash
# 开发模式（监听文件变化）
npm run dev

# 直接运行
MCP_TOKEN=test-token node dist/cli.js
```

### 发布到 npm

```bash
# 1. 更新版本号
npm version patch  # 或 minor, major

# 2. 构建
npm run build

# 3. 发布
npm publish
```

## 故障排查

### Token 无效

- 检查 `MCP_TOKEN` 环境变量是否正确设置
- 确认 Token 未被撤销或过期

### 连接失败

- 检查 `API_URL` 是否指向正确的服务地址
- 确认 Ecommerce Generator 服务正在运行

### Tools 不工作

- 确认用户有足够的权限访问相关数据
- 启用调试日志：`DEBUG=1 ecommerce-mcp`

## 许可证

MIT
