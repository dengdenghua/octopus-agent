# @ioacloud/ioacloud-cli

Command-line helper for authenticating with Tencent iOA. Login is intentionally limited to the **device code flow** — the same OAuth device-authorization pattern used by `tcb login --flow device` and other CLIs that need to work on headless machines or remote shells.

The CLI talks to a real device-authorization server ([ioa-ai-mcp-auth](https://github.com/YOUR-USERNAME/ioa-ai-mcp-auth)). During development the server issues **STUB credentials** (see status below), so the flow itself is end-to-end but the returned `secretId/secretKey` cannot sign real API calls yet.

## Install

```bash
npm install -g @ioacloud/ioacloud-cli
```

## Login (device code flow)

```bash
# Default: talk to a local ioa-ai-mcp-auth on http://127.0.0.1:8787
ioacloud-cli login

# Point at a different device-authorization server
ioacloud-cli login --auth-endpoint http://auth.internal.example.com

# Or set it via env
IOA_AUTH_ENDPOINT=http://auth.internal.example.com ioacloud-cli login

# Extras
ioacloud-cli login --api-endpoint ioa.test.tencentcloudapi.com  # iOA API host used to sign subsequent
                                                           # requests. Default: prod. NOT persisted
                                                           # to credentials.json — pass the same
                                                           # flag / IOA_API_ENDPOINT to @ioacloud/ioacloud-mcp
                                                           # for later invocations.
ioacloud-cli login --region ""                                  # iOA region (usually empty)
ioacloud-cli login --yes                                        # overwrite existing credentials without prompt

# Legacy alias (deprecated): `--endpoint` still works but prints a stderr
# warning; switch to `--auth-endpoint` for parity with @ioacloud/ioacloud-mcp.
```

## Other commands

```bash
ioacloud-cli whoami                    # Show masked identity summary
ioacloud-cli whoami --json             # Same, but structured JSON

ioacloud-cli status                    # Health check: login state + credential expiry roll-up
ioacloud-cli status --json             # Same, but structured JSON

ioacloud-cli logout [--yes]            # Remove ~/.ioa/credentials.json (asks for confirmation unless --yes)

ioacloud-cli config get <key>          # Print a single field: endpoint | region | secretId | authMethod

ioacloud-cli --version                 # Print CLI version
ioacloud-cli --help                    # Print help
```

### `ioacloud-cli status`

Prints a compact health check that answers *"can I use iOA right now?"* — it inspects `~/.ioa/credentials.json` and the `TENCENTCLOUD_SECRET_ID` / `TENCENTCLOUD_SECRET_KEY` env pair, then rolls the result up into a single `overall` verdict:

| `overall` | Meaning | Exit code |
|---|---|---|
| `ok` | Env creds present, or STS creds have ≥ 10 min of life left | `0` |
| `warn` | STS creds expire in < 10 min, or the file has no `expiredTime` field | `0` |
| `expired` | STS `expiredTime` has already passed → run `ioacloud-cli login` | `1` |
| `missing` | Neither file nor env creds → run `ioacloud-cli login` | `1` |

Because `missing` / `expired` return a non-zero exit code, `status` composes cleanly with `login`:

```bash
ioacloud-cli status --json >/dev/null || ioacloud-cli login --yes
```

The JSON payload also includes `refreshToken.expiry` and `refreshToken.familyExpiry`, so scripts can detect the "STS lapsed but refresh still valid" case without re-parsing prose.

## Global flags

| Flag | Meaning |
|---|---|
| `--yes` (or `--force`) | Skip confirmations (overwrite existing credentials, silent logout, etc.) |
| `--json` | Emit JSON instead of prose (for `login` summary / `whoami`) |
| `--verbose` | Print debug info to stderr |

## Credentials precedence

`@ioacloud/ioacloud-mcp` (and any downstream `@ioacloud/*` tool built on `@ioacloud/ioacloud-shared`) resolves credentials in this order:

1. Environment variables:
   - `TENCENTCLOUD_SECRET_ID` / `TENCENTCLOUD_SECRET_KEY`
   - `TENCENTCLOUD_SESSION_TOKEN` (optional, for STS)
   - `IOA_API_ENDPOINT` （iOA API host；无 legacy alias，请使用此名）
   - `IOA_REGION`
2. `~/.ioa/credentials.json` written by `ioacloud-cli login` (mode `0600`)
3. Neither → error with actionable hint

`IOA_AUTH_ENDPOINT` is a *login-time* variable (which authorization server `ioacloud-cli login` should call). It does **not** override runtime credentials.

## Already-logged-in behavior

Running `ioacloud-cli login` when credentials already exist prints:

```
您已登录 (secretId=…, authMethod=…)，无需再次登录！
如需切换账号，请先 `ioacloud-cli logout` 或加 --yes / --force 覆盖当前凭据。
```

Pass `--yes` (or `--force`) to overwrite.

## Wire protocol

The device flow request/response format is aligned with `@cloudbase/toolbox`:

- `POST <endpoint>/qcloud-tcb/v1/oauth/device/code` — issue `device_code` / `user_code`
- `POST <endpoint>/qcloud-tcb/v1/oauth/token` — poll for the outcome
- Body carries a `device_info: { mac, os, hash }` payload (same shape used by `@cloudbase/toolbox` for device fingerprinting; see `src/deviceFlow.ts`)
- Both endpoints return `{ code, reqId, result }`; `code === "NORMAL"` means success

## Status

The authorization server (`ioa-ai-mcp-auth`) currently issues **STUB credentials** — the `secretId` starts with `MOCK_DEVICE_` and the credentials file carries `mock: true`. This lets `@ioacloud/ioacloud-mcp` exercise the full credential pipeline before iOA finalizes its credential-issuance backend.

- `@ioacloud/ioacloud-mcp` detects `mock: true` at startup and prints a warning
- Real iOA API calls will fail (as expected — you can't spoof a real signature)
- Once real issuance ships on the server side, only the server changes; the CLI wire format and command surface stay the same

## License

MIT
